# School Comparison and Shortlisting App - Dialog Map

## Purpose

Model the system as a state machine of user-interface states. In accordance with Fox420, each node represents a visible UI state and each labelled transition represents an event, user action, condition, or system response that changes what the user sees.

## Status and evidence

- **Model status:** Proposed from the SRS, data dictionary, use-case model, and the existing school discovery flow.
- **UI verification status:** Unverified. The supplied PDFs do not contain the Lab 1 screen mockups, routes, or frame links.
- **Primary actor:** Registered user, typically a parent, guardian, or student.
- **System scope used here:** Primary, Secondary, and Junior College schools, following the detailed use-case model and data dictionary.
- **Successful system-level outcome:** A user can manage a student profile, discover and compare schools, maintain a profile-specific shortlist, and track applications without reaching a dead end.

## Modelling conventions

- IDs beginning with `DM-` are stable dialog-state identifiers.
- A state is a distinct visible UI condition, not merely a page. Loading, empty, validation-error, confirmation, and saved states are separate where they change available actions or feedback.
- Edge labels use `event [guard] / visible result` where helpful.
- Background school-data synchronisation is shown only when it produces visible UI feedback.
- Domain state, such as an application's status, is distinguished from the UI state that displays or edits it.

## 1. System-level dialog map

```mermaid
stateDiagram-v2
    [*] --> DM_01
    state "DM-01 Welcome / authentication choice" as DM_01
    state "DM-10 Personalised home" as DM_10
    state "DM-20 Student profiles" as DM_20
    state "DM-30 School discovery" as DM_30
    state "DM-40 Comparison workspace" as DM_40
    state "DM-50 Shortlist" as DM_50
    state "DM-60 Applications" as DM_60
    state "DM-70 Notification settings" as DM_70
    state "DM-80 Session expired" as DM_80
    state "DM-90 Signed out" as DM_90

    DM_01 --> DM_10: loginSuccess / show active student context
    DM_10 --> DM_20: profilesClick
    DM_10 --> DM_30: findSchoolsClick [active profile exists]
    DM_10 --> DM_20: findSchoolsClick [no profile] / prompt profile creation
    DM_10 --> DM_40: compareClick [2..5 schools selected]
    DM_10 --> DM_50: shortlistClick [active profile exists]
    DM_10 --> DM_60: applicationsClick [active profile exists]
    DM_10 --> DM_70: notificationSettingsClick

    DM_20 --> DM_10: backOrProfileSelected / update active profile
    DM_20 --> DM_30: saveProfileAndFindSchools
    DM_30 --> DM_40: compareClick [2..5 schools selected]
    DM_30 --> DM_50: shortlistClick
    DM_30 --> DM_10: homeClick
    DM_40 --> DM_30: backToResults / preserve criteria and selection
    DM_40 --> DM_50: viewShortlistClick
    DM_50 --> DM_30: discoverMoreClick
    DM_50 --> DM_40: compareClick [2..5 schools selected]
    DM_50 --> DM_60: createOrViewApplication
    DM_60 --> DM_50: backToShortlist
    DM_70 --> DM_10: saveOrBack

    DM_10 --> DM_80: inactivityTimeout
    DM_20 --> DM_80: inactivityTimeout
    DM_30 --> DM_80: inactivityTimeout
    DM_40 --> DM_80: inactivityTimeout
    DM_50 --> DM_80: inactivityTimeout
    DM_60 --> DM_80: inactivityTimeout
    DM_70 --> DM_80: inactivityTimeout
    DM_80 --> DM_10: reauthenticateSuccess / restore safe context
    DM_80 --> DM_01: cancelOrAuthenticationFails

    DM_10 --> DM_90: logoutClick
    DM_20 --> DM_90: logoutClick
    DM_30 --> DM_90: logoutClick
    DM_40 --> DM_90: logoutClick
    DM_50 --> DM_90: logoutClick
    DM_60 --> DM_90: logoutClick
    DM_70 --> DM_90: logoutClick
    DM_90 --> DM_01: continue
```

## 2. Authentication dialog map

```mermaid
stateDiagram-v2
    [*] --> DM_01
    state "DM-01 Welcome / authentication choice" as DM_01
    state "DM-02 Registration form" as DM_02
    state "DM-03 Registration validation error" as DM_03
    state "DM-04 Registration success" as DM_04
    state "DM-05 Login form" as DM_05
    state "DM-06 Login authentication error" as DM_06
    state "DM-07 Account locked" as DM_07
    state "DM-08 Login in progress" as DM_08
    state "DM-10 Personalised home" as DM_10

    DM_01 --> DM_02: registerClick
    DM_01 --> DM_05: loginClick
    DM_02 --> DM_08: submitRegistration [fields locally valid]
    DM_02 --> DM_03: submitRegistration [missing or malformed fields]
    DM_03 --> DM_02: editInput / retain valid values
    DM_08 --> DM_03: registrationRejected [duplicate email or server validation]
    DM_08 --> DM_04: registrationAccepted
    DM_04 --> DM_05: continueToLogin
    DM_05 --> DM_08: submitCredentials
    DM_08 --> DM_06: credentialsRejected [failed attempts < 5]
    DM_06 --> DM_05: retry / retain email only
    DM_08 --> DM_07: credentialsRejected [failed attempts = 5]
    DM_07 --> DM_05: cooldownElapsed / enable login
    DM_08 --> DM_10: credentialsAccepted
    DM_02 --> DM_01: cancel
    DM_05 --> DM_01: back
```

**Refinement:** The requirements do not say that registration authenticates the new account. The map therefore shows a separate login step after successful registration. If the Lab 1 mockup goes directly to Home, the requirement should be amended to specify automatic authentication.

## 3. Student-profile dialog map

```mermaid
stateDiagram-v2
    [*] --> DM_20
    state "DM-20 Student profile list" as DM_20
    state "DM-21 Empty profile state" as DM_21
    state "DM-22 Create profile form" as DM_22
    state "DM-23 Edit profile form" as DM_23
    state "DM-24 Profile validation error" as DM_24
    state "DM-25 Saving profile" as DM_25
    state "DM-26 Profile saved" as DM_26
    state "DM-27 Remove profile confirmation" as DM_27
    state "DM-28 Profile removal blocked" as DM_28

    DM_20 --> DM_21: profilesLoaded [none exist]
    DM_20 --> DM_23: editClick
    DM_20 --> DM_22: addProfileClick
    DM_21 --> DM_22: createProfileClick
    DM_22 --> DM_24: saveClick [education level missing or values invalid]
    DM_23 --> DM_24: saveClick [values invalid]
    DM_24 --> DM_22: correctInput [creating]
    DM_24 --> DM_23: correctInput [editing]
    DM_22 --> DM_25: saveClick [valid]
    DM_23 --> DM_25: saveClick [valid]
    DM_25 --> DM_26: saveSucceeded / make profile active
    DM_25 --> DM_24: saveFailed / retain all input
    DM_26 --> DM_20: continue
    DM_20 --> DM_27: removeClick
    DM_27 --> DM_20: cancel
    DM_27 --> DM_28: confirm [dependent shortlist or applications require handling]
    DM_27 --> DM_20: confirm [safe to remove] / remove profile
    DM_28 --> DM_20: acknowledge
```

**Refinement:** Removal needs an explicit dependency rule. The current requirements allow profile removal but do not define what happens to its shortlist and applications. The safe default is to block removal while dependent records exist, or offer an explicit archival workflow rather than cascade-delete silently.

## 4. School discovery, details, and comparison dialog map

```mermaid
stateDiagram-v2
    [*] --> DM_30
    state "DM-30 Search and filter form" as DM_30
    state "DM-31 Search loading" as DM_31
    state "DM-32 Search results" as DM_32
    state "DM-33 No matching results" as DM_33
    state "DM-34 Search failure" as DM_34
    state "DM-35 School details loading" as DM_35
    state "DM-36 School details" as DM_36
    state "DM-37 Details with unavailable data" as DM_37
    state "DM-38 Shortlist save in progress" as DM_38
    state "DM-39 School saved to active shortlist" as DM_39
    state "DM-40 Comparison selection: 0-1 schools" as DM_40
    state "DM-41 Comparison selection: 2-5 schools" as DM_41
    state "DM-42 Comparison loading" as DM_42
    state "DM-43 Comparison ready" as DM_43
    state "DM-44 Comparison with unavailable criteria" as DM_44
    state "DM-45 Comparison limit reached" as DM_45

    DM_30 --> DM_31: searchOrApplyFilters
    DM_31 --> DM_32: resultsReceived [count > 0]
    DM_31 --> DM_33: resultsReceived [count = 0]
    DM_31 --> DM_34: requestFailed [no usable cached data]
    DM_33 --> DM_30: editOrClearCriteria / retain existing criteria
    DM_34 --> DM_31: retry
    DM_34 --> DM_30: editCriteria
    DM_32 --> DM_30: editFilters
    DM_32 --> DM_35: schoolClick
    DM_35 --> DM_36: detailsReceived [complete]
    DM_35 --> DM_37: detailsReceived [some fields unavailable]
    DM_35 --> DM_34: requestFailed
    DM_36 --> DM_32: back / restore results and scroll position
    DM_37 --> DM_32: back / restore results and scroll position
    DM_36 --> DM_38: addToShortlist [not already saved]
    DM_37 --> DM_38: addToShortlist [not already saved]
    DM_38 --> DM_39: saveSucceeded / identify active student
    DM_38 --> DM_36: saveFailed / preserve selected school and allow retry
    DM_39 --> DM_36: continue

    DM_32 --> DM_40: comparisonMode [selectedCount < 2]
    DM_40 --> DM_41: selectSchool [selectedCount becomes 2]
    DM_41 --> DM_40: deselectSchool [selectedCount becomes 1]
    DM_41 --> DM_45: selectSchool [selectedCount already 5]
    DM_45 --> DM_41: acknowledgeOrDeselect
    DM_41 --> DM_42: compareClick
    DM_42 --> DM_43: comparisonReady [all criteria available]
    DM_42 --> DM_44: comparisonReady [one or more criteria unavailable]
    DM_43 --> DM_32: back / retain selected schools
    DM_44 --> DM_32: back / retain selected schools
```

**Visible global variant:** When the external school-data or traffic service is unavailable but cached data exists, `DM-32`, `DM-36`, `DM-37`, `DM-43`, and `DM-44` should remain usable with a non-blocking "using data last updated at ..." banner. This implements the SRS reliability requirement without inventing a dead-end error page.

## 5. Shortlist and application dialog map

```mermaid
stateDiagram-v2
    [*] --> DM_50
    state "DM-50 Profile shortlist" as DM_50
    state "DM-51 Empty shortlist" as DM_51
    state "DM-52 Remove school confirmation" as DM_52
    state "DM-53 Shortlist update failure" as DM_53
    state "DM-60 Application list" as DM_60
    state "DM-61 Empty application state" as DM_61
    state "DM-62 Create application form" as DM_62
    state "DM-63 Application validation error" as DM_63
    state "DM-64 Saving application" as DM_64
    state "DM-65 Application detail" as DM_65
    state "DM-66 Edit application" as DM_66
    state "DM-67 Status-change confirmation" as DM_67
    state "DM-68 Application saved" as DM_68
    state "DM-69 Upcoming-deadline reminder" as DM_69

    DM_50 --> DM_51: shortlistLoaded [empty]
    DM_51 --> DM_50: schoolAdded
    DM_50 --> DM_52: removeSchoolClick
    DM_52 --> DM_50: cancel
    DM_52 --> DM_50: confirm / remove and save
    DM_52 --> DM_53: saveFailed / keep school visible
    DM_53 --> DM_52: retry
    DM_50 --> DM_62: createApplication [none exists]
    DM_50 --> DM_65: viewApplication [record exists]

    DM_60 --> DM_61: applicationsLoaded [empty]
    DM_60 --> DM_65: applicationClick
    DM_61 --> DM_62: createApplicationClick
    DM_62 --> DM_63: saveClick [invalid or required association missing]
    DM_63 --> DM_62: correctInput / retain entered values
    DM_62 --> DM_64: saveClick [valid]
    DM_64 --> DM_68: saveSucceeded
    DM_64 --> DM_63: saveFailed
    DM_68 --> DM_65: continue
    DM_65 --> DM_66: editClick
    DM_66 --> DM_67: changeStatusClick [transition allowed]
    DM_66 --> DM_63: saveClick [invalid]
    DM_67 --> DM_64: confirm
    DM_67 --> DM_66: cancel
    DM_69 --> DM_65: openReminder
    DM_69 --> DM_60: dismiss
```

### Application status shown within `DM-65 Application detail`

```mermaid
stateDiagram-v2
    [*] --> Draft
    Draft --> Submitted: submitApplication
    Submitted --> UnderReview: markUnderReview
    UnderReview --> Offered: recordOffer
    UnderReview --> Rejected: recordRejection
    Offered --> Accepted: acceptOffer
```

**Refinement:** The data dictionary supplies the status sequence, but the requirements do not define who is authorised to make each change, whether users can correct an accidental change, or whether withdrawal and expiry are valid states. Until those rules are specified, the UI should not present an unrestricted status dropdown.

## 6. UI state catalogue and requirement trace

| Dialog states | UI area | Key visible behavior | Requirement/use case trace | Mockup reference | Status |
| --- | --- | --- | --- | --- | --- |
| DM-01-DM-10 | Welcome, registration, login | Choice of authentication path; field validation; retry; lockout countdown; successful access | UC01, UC02; FR 1.1-2.5; NFR 3.5.1 | Unmapped | Proposed |
| DM-20-DM-28 | Student profiles | Empty, create, edit, validation, save, active selection, and protected removal states | UC03; FR 3.1-3.7 | Unmapped | Proposed |
| DM-30-DM-34 | Search and filters | Criteria entry, loading, results, recoverable empty state, and failure | UC04, UC05; FR 4.1-5.4; NFR 3.3.1 | Unmapped | Proposed |
| DM-35-DM-39 | School details and save | Loading, available/unavailable details, shortlist persistence, student-specific confirmation | UC06, UC08; FR 6.1-6.5, 8.1-8.4; NFR 3.3.2 | Unmapped | Proposed |
| DM-40-DM-45 | Compare selection and results | Disabled/enabled comparison, 5-school cap, loading, unavailable criteria | UC07; FR 7.1-7.8; NFR 3.3.3 | Unmapped | Proposed |
| DM-50-DM-53 | Shortlist | Profile-specific list, empty state, remove confirmation, recoverable failure | UC08; FR 8.1-8.4 | Unmapped | Proposed |
| DM-60-DM-69 | Applications and reminders | Empty/list/detail/create/edit/save states, guarded status changes, reminder deep link | UC09-UC11; FR 9.1-11.5 | Unmapped | Proposed |
| DM-70 | Notification settings | Opt in/out with observable saved preference | UC11; FR 11.2-11.5; `notificationOptIn` | Unmapped | Proposed |
| DM-80 | Session expired | Explain timeout, reauthenticate, and safely restore context | NFR 3.5.2 | Unmapped | Proposed |
| Cached-data variants | Results, details, comparison | Continue with last synchronised school and historical distance data; show freshness | UC12; FR 12.1-12.5; NFR 3.2.2 | Unmapped | Proposed |

## 7. Deficiencies revealed and UI refinements

1. **No supplied mockup-to-state trace.** Screen names, controls, back behavior, and routes cannot be verified. Add frame IDs or screenshots to the catalogue before treating the map as implemented behavior.
2. **Active student context is easy to lose.** Show the active student persistently on Home, Search, Details, Compare, Shortlist, and Applications. Every save confirmation should name that student.
3. **Registration destination is ambiguous.** Decide whether registration signs the user in automatically. This map uses a separate login because no automatic-login requirement exists.
4. **Profile deletion has undefined consequences.** Specify archive, reassignment, or blocked deletion when the profile owns a shortlist or applications.
5. **Comparison selection lacks UI rules.** Show a running count, disable Compare below two selections, cap selection at five, and explain why a sixth cannot be selected.
6. **Search context could be lost.** Back from Details or Compare should restore criteria, results, selection, and scroll position.
7. **Unavailable and stale data need different treatment.** Use "Not available" for a missing field and a dated stale-data banner when cached records are being used.
8. **Application status editing is underspecified.** Use explicit valid actions rather than a free-form status picker, and define correction, withdrawal, expiry, and audit-history rules.
9. **Session timeout recovery is unspecified.** After reauthentication, restore non-sensitive search context and unsaved form input where policy permits; never silently submit an interrupted action.
10. **Notification settings have no stated navigation entry.** Add a discoverable settings path and show the consequence of disabling reminders.
11. **Scope conflicts across documents.** The SRS mission mentions university, grades, recommendations, and real-time traffic, while the detailed use-case model limits the release to Primary through Junior College and excludes academic results. The UI must follow one explicit release scope.
12. **System feedback states are incomplete.** Add loading, persistence failure, retry, and retained-input behavior to prevent apparently unresponsive controls or destructive retries.

## 8. Conceptual-model feedback from the dynamic model

Studying the UI states reveals additional model responsibilities that should be reconciled with the class model:

| Conceptual addition or clarification | Attributes / operations suggested by the dialog map | Relationship or reason |
| --- | --- | --- |
| `Session` | `lastActivityAt`, `expiresAt`, `reauthenticate()`, `end()` | Needed for the 30-minute timeout and safe resumption behavior |
| `ShortlistEntry` | `addedAt`, optional `notes`, `add()`, `remove()` | Makes the School-Shortlist many-to-many relationship and per-school actions explicit |
| `ApplicationStatusHistory` | `fromStatus`, `toStatus`, `changedAt`, `changedBy`, `recordTransition()` | Supports guarded transitions and an audit trail instead of overwriting status blindly |
| `Application` | clarify `canTransitionTo(status)` and missing statuses such as withdrawn/expired | The UI requires transition rules before enabling actions |
| `DataSyncStatus` | `lastSuccessfulSyncAt`, `source`, `failureReason`, `isStale` | Drives the cached-data banner and distinguishes missing data from stale data |
| `ComparisonSelection` (transient) | `selectedSchoolIDs`, `addSchool()`, `removeSchool()`, `canCompare()` | Enforces the 2-5 selection guard and preserves selection across navigation |
| `NotificationPreference` or expanded `User` fields | channel, locale, enabled, lead time | `notificationOptIn` alone does not specify how or when reminders appear |
| `StudentProfile` deletion policy | `archive()` or `hasDependents()` | Prevents loss of Shortlist and Application records |

These are design findings, not confirmed requirements. They should be accepted or rejected during the next conceptual-model revision.

## 9. Walkthrough checks

1. **New user:** Welcome -> Register -> correct a duplicate-email error -> Login -> create profile -> Home; each successful transition has a visible result.
2. **Login lockout:** Fail login five consecutive times -> locked state shows remaining time -> login becomes available after cooldown.
3. **First profile:** Attempt Find Schools without a profile -> profile creation is prompted -> valid save activates the profile -> search opens.
4. **Recoverable search:** Apply filters -> no results -> edit one criterion -> results appear within the required response window without rebuilding all criteria.
5. **Preserved discovery context:** Open a school -> return -> original filters, results, comparison selections, and scroll position remain.
6. **Correct shortlist ownership:** Save a school -> confirmation names the active student -> the school appears only in that profile's shortlist.
7. **Comparison guards:** One selected school keeps Compare unavailable -> two enable it -> five are accepted -> a sixth produces an explanatory state.
8. **Missing versus stale data:** A missing CCA field is marked unavailable; an external-source outage keeps cached results usable with a dated freshness notice.
9. **Protected removal:** Try to remove a profile with applications -> system prevents silent data loss and explains the resolution path.
10. **Application lifecycle:** Create a draft -> submit -> mark under review -> record offered or rejected -> accept an offer; invalid jumps are unavailable.
11. **Reminder:** Open an upcoming-deadline reminder -> land on the corresponding application's detail state; dismissing it returns to the application list.
12. **Session expiry:** Remain inactive for 30 minutes during a search or form edit -> session-expired state appears -> reauthenticate -> safe context is restored without an unintended submit.

## 10. Next design pass

Attach or export the Lab 1 mockups, then annotate each screen and modal with its `DM-` state ID. Compare every clickable control against the outgoing transitions above. Any control without a destination, state without an exit, or transition without visible feedback is a UI-flow defect to resolve in the mockup and this map together.
