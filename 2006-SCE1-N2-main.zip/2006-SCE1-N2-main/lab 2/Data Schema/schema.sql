CREATE EXTENSION IF NOT EXISTS citext;
CREATE EXTENSION IF NOT EXISTS postgis;   -- geography type, ST_Distance

-- Enums
CREATE TYPE education_level    AS ENUM ('Primary','Secondary','JuniorCollege');
CREATE TYPE school_type        AS ENUM ('Primary','Secondary','JuniorCollege','MixedLevels');
CREATE TYPE cca_category       AS ENUM ('Sports','PerformingArts','UniformedGroup','ClubSociety');
CREATE TYPE application_status AS ENUM ('Draft','Submitted','UnderReview','Offered','Rejected','Accepted');
CREATE TYPE sync_status        AS ENUM ('Success','Failed','Partial');

-- Account and profile
CREATE TABLE user_account (
  user_id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name                  varchar(100) NOT NULL,
  email                 citext       NOT NULL UNIQUE,              -- FR 1.4
  password_hash         text         NOT NULL,
  failed_login_count    smallint     NOT NULL DEFAULT 0 CHECK (failed_login_count >= 0),
  locked_until          timestamptz,                               -- NFR 3.5.1
  preferred_postal_code char(6),
  home_location         geography(Point, 4326),                    -- geocoded from postal code
  notification_opt_in   boolean      NOT NULL DEFAULT true,        -- FR 11.2
  created_at            timestamptz  NOT NULL DEFAULT now()
);

CREATE TABLE student_profile (
  student_id    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       uuid NOT NULL REFERENCES user_account ON DELETE CASCADE,
  name          varchar(100),
  current_level education_level NOT NULL,                          -- FR 3.4
  current_year  smallint NOT NULL CHECK (current_year BETWEEN 1 AND 6),
  created_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ON student_profile (user_id);

-- School catalogue
CREATE TABLE school (
  school_id      uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  moe_code       varchar(20) UNIQUE,
  name           varchar(150) NOT NULL UNIQUE,                     -- sync upsert key
  type           school_type  NOT NULL,
  address        text         NOT NULL,
  postal_code    char(6),
  location       geography(Point, 4326),
  website        text,
  description    text,
  is_active      boolean     NOT NULL DEFAULT true,
  last_synced_at timestamptz
);
CREATE INDEX ON school USING gist (location);
CREATE INDEX ON school (type);

CREATE TABLE subject (
  subject_id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subject_name         varchar(150) NOT NULL,
  level                education_level NOT NULL,
  is_special_programme boolean NOT NULL DEFAULT false,
  UNIQUE (subject_name, level)
);

CREATE TABLE cca (
  cca_id   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cca_name varchar(150) NOT NULL,
  category cca_category NOT NULL,
  UNIQUE (cca_name, category)
);

CREATE TABLE school_subject (
  school_id  uuid REFERENCES school  ON DELETE CASCADE,
  subject_id uuid REFERENCES subject ON DELETE CASCADE,
  PRIMARY KEY (school_id, subject_id)
);
CREATE INDEX ON school_subject (subject_id);                       -- filter by subject (FR 5.1)

CREATE TABLE school_cca (
  school_id         uuid REFERENCES school ON DELETE CASCADE,
  cca_id            uuid REFERENCES cca    ON DELETE CASCADE,
  achievement_level text,
  PRIMARY KEY (school_id, cca_id)
);
CREATE INDEX ON school_cca (cca_id);

CREATE TABLE affiliation (
  affiliation_id       uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  feeder_school_id     uuid NOT NULL REFERENCES school ON DELETE CASCADE,
  receiving_school_id  uuid NOT NULL REFERENCES school ON DELETE CASCADE,
  priority_description text,
  UNIQUE (feeder_school_id, receiving_school_id),
  CHECK (feeder_school_id <> receiving_school_id)
);
CREATE INDEX ON affiliation (receiving_school_id);

CREATE TABLE school_sync_log (
  sync_id         bigserial PRIMARY KEY,
  dataset         varchar(50) NOT NULL,
  started_at      timestamptz NOT NULL DEFAULT now(),
  finished_at     timestamptz,
  status          sync_status NOT NULL,
  records_updated integer NOT NULL DEFAULT 0,
  error_message   text                                             -- FR 12.5
);

-- Student preferences (need subject/cca to exist first)
CREATE TABLE student_preferred_subject (
  student_id uuid REFERENCES student_profile ON DELETE CASCADE,
  subject_id uuid REFERENCES subject         ON DELETE CASCADE,
  PRIMARY KEY (student_id, subject_id)
);
CREATE TABLE student_preferred_cca (
  student_id uuid REFERENCES student_profile ON DELETE CASCADE,
  cca_id     uuid REFERENCES cca             ON DELETE CASCADE,
  PRIMARY KEY (student_id, cca_id)
);

-- Shortlist and application
CREATE TABLE shortlist (
  shortlist_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id   uuid NOT NULL REFERENCES student_profile ON DELETE CASCADE,
  name         varchar(100) NOT NULL DEFAULT 'My shortlist',
  date_created date NOT NULL DEFAULT current_date,
  notes        text
);
CREATE INDEX ON shortlist (student_id);

CREATE TABLE shortlist_entry (
  entry_id     uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  shortlist_id uuid NOT NULL REFERENCES shortlist ON DELETE CASCADE,
  school_id    uuid NOT NULL REFERENCES school    ON DELETE RESTRICT,
  date_added   date NOT NULL DEFAULT current_date,
  rank         smallint CHECK (rank > 0),
  UNIQUE (shortlist_id, school_id)                                 -- no duplicate school
);

CREATE TABLE application (
  application_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id     uuid NOT NULL REFERENCES student_profile ON DELETE CASCADE,
  school_id      uuid NOT NULL REFERENCES school          ON DELETE RESTRICT,
  status         application_status NOT NULL DEFAULT 'Draft',
  date_submitted date,
  deadline       date,                                             -- UC13; null = no reminder
  notes          text,                                             -- FR 9.3
  updated_at     timestamptz NOT NULL DEFAULT now(),
  UNIQUE (student_id, school_id),                                  -- FR 10.5
  CHECK (status = 'Draft' OR date_submitted IS NOT NULL)
);
CREATE INDEX ON application (deadline) WHERE deadline IS NOT NULL; -- FR 11.1 scan

CREATE TABLE deadline_reminder (
  reminder_id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id      uuid NOT NULL REFERENCES application ON DELETE CASCADE,
  remind_for_deadline date NOT NULL,
  channel             varchar(20) NOT NULL DEFAULT 'email',
  sent_at             timestamptz NOT NULL DEFAULT now(),
  UNIQUE (application_id, remind_for_deadline)                     -- never remind twice
);

CREATE TABLE comparison_criterion (
  criterion_id   smallint PRIMARY KEY,
  criterion_name varchar(50) NOT NULL UNIQUE
);
INSERT INTO comparison_criterion VALUES
  (1,'Distance'),(2,'Subject Match'),(3,'CCA Match'),(4,'Affiliation');
