"""Flask CLI commands: the only way to write the school catalogue (ARC-02 §3.9.1, §4.1 server-only entry points)."""
import click
from flask import Flask
from flask.cli import with_appcontext

from app.control import ReminderController, SchoolDataSyncController
from app.errors import DomainError


@click.command("sync-schools")
@with_appcontext
def sync_schools_command() -> None:
    """`flask sync-schools`: run one UC12 sync now and print the sync log status."""
    try:
        log = SchoolDataSyncController().synchronise_school_data()
    except DomainError as error:
        # e.g. ExternalServiceError when data.gov.sg is down; exits with status 1.
        raise click.ClickException(error.message) from error
    click.echo(f"School sync {log.status.value}: {log.records_updated} records updated.")
    if log.error_message:
        click.echo(f"Error: {log.error_message}", err=True)


@click.command("check-deadlines")
@with_appcontext
def check_deadlines_command() -> None:
    """`flask check-deadlines`: run the UC11 deadline check now and print how many reminders were created."""
    try:
        created = ReminderController().check_deadlines()
    except DomainError as error:
        raise click.ClickException(error.message) from error
    click.echo(f"Deadline check done: {created} reminders created.")


def register_cli(app: Flask) -> None:
    """Add both commands to app.cli.

    Inputs: the Flask app.
    Output: none.
    """
    app.cli.add_command(sync_schools_command)
    app.cli.add_command(check_deadlines_command)
