"""Background jobs and server-only CLI commands (UC11, UC12; ARC-02 §3.7.4, §3.7.5)."""
