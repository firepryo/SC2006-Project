"""APScheduler jobs. They call the same controllers as the routes (ARC-02 §3.5)."""
from collections.abc import Callable

from flask import Flask

from app.control import ReminderController, SchoolDataSyncController
from app.extensions import db, scheduler

DEADLINE_CHECK_JOB_ID = "check_deadlines"  # UC11: daily 08:00 Asia/Singapore
SCHOOL_SYNC_JOB_ID = "sync_school_data"  # UC12: weekly, Sunday 03:00 Asia/Singapore


def register_jobs(app: Flask) -> None:
    """Add both jobs to extensions.scheduler and start it, only when SCHEDULER_ENABLED is true.

    Inputs: the Flask app (each job runs inside app.app_context()).
    Output: none.
    Errors: none; a job that fails logs the error and runs again at its next time (UC11 alt flow 2).
    """
    if not app.config.get("SCHEDULER_ENABLED"):
        return

    def run_in_app(job_name: str, work: Callable[[], object]) -> Callable[[], None]:
        def job() -> None:
            with app.app_context():
                try:
                    work()
                except Exception:
                    db.session.rollback()
                    app.logger.exception("Scheduled job %s failed; it will run again at its next time.", job_name)

        return job

    # The scheduler's timezone (Asia/Singapore) is set in extensions.py, so these hours are Singapore time.
    scheduler.add_job(
        run_in_app(DEADLINE_CHECK_JOB_ID, lambda: ReminderController().check_deadlines()),
        trigger="cron",
        hour=8,
        minute=0,
        id=DEADLINE_CHECK_JOB_ID,
        replace_existing=True,
    )
    scheduler.add_job(
        run_in_app(SCHOOL_SYNC_JOB_ID, lambda: SchoolDataSyncController().synchronise_school_data()),
        trigger="cron",
        day_of_week="sun",
        hour=3,
        minute=0,
        id=SCHOOL_SYNC_JOB_ID,
        replace_existing=True,
    )
    # create_app() can run more than once in one process (tests, the CLI); start the scheduler only once.
    if not scheduler.running:
        scheduler.start()
