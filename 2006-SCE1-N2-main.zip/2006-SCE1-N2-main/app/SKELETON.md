# SKELETON

Two documents are built into this folder. Each has its own section and its own HANDOFF.md.

**Layout change (2026-10-26, user request).** The old `App/` folder and its inner `App/app/` package were merged into one package folder, `app/`, at the repository root. `create_app()` moved from `app/__init__.py` to `app/app.py`; `__init__.py` is now empty apart from a docstring. Login is JWT (ARC-02 §3.9.2); the Flask-Login set-up from DATA-01 F1 was replaced. Run everything from the repository root:

- Dev server: `python -m app.run`
- Flask CLI: `flask --app "app.app:create_app()" <command>`
- Gunicorn: `gunicorn "app.app:create_app()"`

Running `python run.py` from inside `app/` does not work: there, `import app` finds `app.py` instead of the package. The trees below show the current layout.

---

# SKELETON: DATA-01 Data Schema

Document used: `Official Technical Documentation/02-Data-Schema/DATA-01-Data-Schema.md`, v1.0 (Approved, 2026-10-23).
Stack: Flask-SQLAlchemy (SQLAlchemy 2 typed models), Flask-Migrate (Alembic, ADR-005), GeoAlchemy2 for `geography`, psycopg 3, PostgreSQL with `citext` and `postgis`.

## File tree

```
app/
  app.py                     create_app(): settings (DATABASE_URL, JWT, API keys; loads app/.env), config checks, db, migrate and jwt wiring
  .env                       local secrets, git-ignored (copy .env.example)
  .env.example               committed template of the variables
  requirements.txt
  extensions.py              db (SQLAlchemy), migrate (Migrate), jwt (JWTManager), scheduler
  models/
    __init__.py              imports every model so db.metadata has all 16 tables
    enums.py                 the 5 enums (§3.2)
    account.py               user_account, student_profile, student_preferred_subject, student_preferred_cca
    school.py                school, subject, cca, school_subject, school_cca, affiliation, school_sync_log
    application.py           shortlist, shortlist_entry, application, deadline_reminder, comparison_criterion
  migrations/                Alembic (F2): env.py, versions/b44eb0ca9710_initial_schema.py
```

The models are declarations only (tables, columns, constraints, indexes, delete rules) and are complete in the skeleton. They contain no logic.

## Features in build order

### F1 App wiring (needed to host the models; DATA-01 §3.7)
- [x] `app/app.py` `create_app()`: load Config, `db.init_app`, `migrate.init_app`, `jwt.init_app`, import `app.models`. Flask CLI: `flask --app "app.app:create_app()" ...` (renamed from `app()` on 2026-10-26)

### F2 First migration and seed rows (DATA-01 §3.6, §3.7, ADR-005); depends on F1
Unblocked 2026-11-06: local PostGIS from `app/docker-compose.yml`. Migrations live in `app/migrations/` (`migrate.init_app(..., directory=...)` in `app.py`), whatever folder the command runs from.

- [x] `flask db init`; configure `migrations/env.py` for GeoAlchemy2 (`geoalchemy2.alembic_helpers` writer and render_item; `include_object` skips tables not in the models, so the image's postgis_topology / tiger tables and `spatial_ref_sys` are never dropped) (2026-11-06)
- [x] First revision `b44eb0ca9710_initial_schema.py`: `CREATE EXTENSION citext`, `CREATE EXTENSION postgis`, the 5 enum types (created once, explicitly), all 16 tables and indexes (§3.6) (2026-11-06)
- [x] Seed `comparison_criterion`: 1 Distance, 2 Subject Match, 3 CCA Match, 4 Affiliation (§3.6) (2026-11-06)
- [x] Seed the 21 dataset subjects: 7 names × 3 levels (§3.6) (2026-11-06)
- [x] `downgrade()` drops everything the revision created, except `postgis`: the Docker image installs it before the migration, with two extensions depending on it (2026-11-06)
- [x] Applied to the local PostGIS database: upgrade, downgrade to base, upgrade again; `flask db check` reports no drift; catalogue check against §3.6 (16 tables, 5 enums, 6 CHECKs, 10 indexes incl. GiST and partial, 17 FKs with §3.5 delete rules, seed rows) (2026-11-06)

Commands, from the repository root: `flask --app "app.app:create_app()" db upgrade` (apply), `db downgrade base` (undo), `db migrate -m "<change>"` then review the file (new change), `db check` (models vs database).

## Skeleton check (2026-10-23)

- `python -m compileall App` (now `app`): OK.
- DDL generated from `db.metadata` with the PostgreSQL dialect: 16 tables; every column, type, NOT NULL, default, CHECK, UNIQUE, FK delete rule, the GiST index on `school.location` and the partial index on `application.deadline` match §3.6. Index names differ (SQLAlchemy names them, e.g. `ix_school_zone`; §3.6 leaves naming to PostgreSQL).

## Open questions

1. **Local database.** F2 needs PostgreSQL with PostGIS. OPS-01 (dev environment) is not written. Is Postgres + PostGIS installed, or should it run in Docker?
2. **GeoAlchemy2.** DATA-01 does not name a library for `geography(Point, 4326)`; GeoAlchemy2 is the standard one for SQLAlchemy. OK to keep?
3. **App layout.** Answered by ARC-02 §3.12 (2026-10-25); flattened into one `app/` package on 2026-10-26 (see "Layout change" at the top).
4. **Python version / Windows policy.** Checked on Python 3.15. Windows Application Control blocked SQLAlchemy's compiled `.pyd` when loaded from the Temp folder; installing with `DISABLE_SQLALCHEMY_CEXT=1 pip install --no-binary sqlalchemy sqlalchemy` worked. Psycopg's binary DLL may be blocked the same way when connecting.

---

# SKELETON: ARC-02 System Architecture

Document used: `Official Technical Documentation/01-App-Architecture/ARC-02-System-Architecture.md`, v0.1 (Draft, 2026-10-25). Built from the Draft at the user's request for the Lab 3 skeleton deliverable (AGENT.md rule 1).
Stack (ARC-02 §3.6): Flask 3 + Flask-JWT-Extended + marshmallow + APScheduler + requests on the back end; React 18 + TypeScript + Vite + React Router + react-i18next on the front end.

## File tree

```
app/
  run.py                              start-up script: create_app() and run (python -m app.run)
  requirements.txt                    + Flask-JWT-Extended, marshmallow, APScheduler, requests, gunicorn
  __init__.py                         package marker only
  app.py                              create_app(): settings (JWT, API keys, scheduler; §3.8, §3.9.2),
                                      db, migrate, jwt; rest of the wiring [TODO]  (§3.10)
  extensions.py                     + jwt (JWTManager), scheduler (BackgroundScheduler)
  errors.py                         DomainError + 6 subclasses; register_error_handlers [stub]   (§5)
  models/                           «entity» (DATA-01, unchanged)
  control/                          «control» one file per class-diagram controller     (§3.4)
    access_control.py               require_profile_owner, require_application_owner    (§3.9.3)
    comparison_criteria.py          Strategy: Distance / SubjectMatch / CcaMatch / Affiliation (§3.10)
    registration_controller.py      RegistrationController          M1 UC01, UC07a
    login_controller.py             LoginController                 M1 UC02
    notification_preference_controller.py  NotificationPreferenceController  M1 UC14
    student_profile_controller.py   StudentProfileController        M2 UC03
    school_search_controller.py     SchoolSearchController          M3 UC04, UC05
    school_details_controller.py    SchoolDetailsController         M3 UC06
    school_comparison_controller.py SchoolComparisonController      M4 UC07 (Facade)
    shortlist_controller.py         ShortlistController             M5 UC08
    application_controller.py       ApplicationController           M6 UC09
    application_status_controller.py ApplicationStatusController    M6 UC10 (State table)
    application_deadline_controller.py ApplicationDeadlineController M6 UC13
    reminder_controller.py          ReminderController              M7 UC11
    school_data_sync_controller.py  SchoolDataSyncController        M8 UC12
  boundary/                         «boundary» API blueprints, mounted under /api      (§4.1)
                                    flask_smorest.Blueprint; one MethodView class per URL with @<bp>.route
                                    above it; jwt_required() in the class's `decorators`
    __init__.py                     BLUEPRINTS, register_blueprints  [stub]
    schemas.py                      marshmallow schemas: 13 request (@<bp>.arguments), 16 response (@<bp>.response)
    auth_routes.py                  5 routes   M1
    profile_routes.py               5 routes   M2
    reference_routes.py             3 routes   M2, M8 (subjects, ccas, data-freshness)
    school_routes.py                3 routes   M3, M4
    shortlist_routes.py             3 routes   M5
    application_routes.py           7 routes   M6
    notification_routes.py          4 routes   M1, M7
  gateway/                          «boundary» external systems                         (§3.10 Gateway)
    external_school_data_gateway.py ExternalSchoolDataGateway (data.gov.sg)
    onemap_gateway.py               OneMapGateway (geocoding, ADR-003)
  jobs/
    scheduler.py                    register_jobs: daily UC11, weekly UC12  [stub]
    cli.py                          flask sync-schools, flask check-deadlines  [stub]
  frontend/                           React + TypeScript SPA                              (§3.12)
    package.json, tsconfig.json, vite.config.ts, index.html
    src/
      main.tsx                        router + context providers
      App.tsx                         routes, one per dialog-map area
      i18n.ts                         react-i18next set-up (NFR 3.1.3)
      api/types.ts                    response shapes (DATA-01 names)
      api/client.ts                   one typed function per §4.1 endpoint  [stub]
      context/ActiveStudentContext.tsx        active student (dialog map §7 item 2)
      context/ComparisonSelectionContext.tsx  2–5 selected schools (dialog map §8)  [stub]
      pages/                          «boundary» one component per UI class (12) + HomeUI (DM-10)
```

## Features in build order

Every function below is a stub (`raise NotImplementedError` / `throw new Error("Not implemented")`) with a `TODO(<source>)`.

### F3 Wiring and cross-cutting (§3.3, §3.9, §5); together with DATA-01 F1
- [x] `app/app.py` `create_app()`: JWT cookie refresh (`refresh_jwt_cookie` after_request; skipped when the route set or cleared the cookie, e.g. logout), blueprints, error handlers, CLI, jobs (2026-11-06)
- [x] `errors.register_error_handlers()`: DomainError, HTTPException (replaces flask-smorest's body; its 422 becomes 400 `validation_failed` with field errors in `details`), unhandled Exception (500 `internal_error`), JWT expired (401 `session_expired`), missing/invalid/CSRF (401 `unauthorised`) (2026-11-06)
- [x] `boundary.register_blueprints()`: `api.init_app` (flask-smorest) and every blueprint under `/api`; called from `create_app()` (2026-10-26)
- [x] `jobs.cli.register_cli()`; `jobs.scheduler.register_jobs()`: `flask sync-schools`, `flask check-deadlines`; cron jobs daily 08:00 and Sunday 03:00 SGT when `SCHEDULER_ENABLED` (2026-11-06)
- [x] `access_control.require_profile_owner()`, `require_application_owner()`, plus `current_user_id()` for routes (JWT identity is `str(user_id)`, set at login) (2026-11-06)
- [ ] `frontend/src/api/client.ts` `request()` (frontend out of scope for the backend team)

### F4 M1 Accounts (UC01, UC02, UC07a, UC14); depends on F3, DATA-01 F2
- [ ] `RegistrationController.register_account()`, `update_home_location()`, `_validate_account_information()`, `_is_email_registered()`
- [ ] `LoginController.login()`, `logout()`, `get_current_user()`, `_validate_credentials()`, `_handle_failed_attempt()`
- [ ] `NotificationPreferenceController.get_preference()`, `update_preference()`
- [ ] `OneMapGateway.geocode_postal_code()`
- [ ] `auth_routes`: register, login, logout, me, update_home_location; `notification_routes`: get/update preference
- [ ] Pages: RegistrationUI, LoginUI, NotificationPreferencesUI; session guard in App.tsx (DM-80)

### F5 M2 Student profiles (UC03); depends on F4
- [ ] `StudentProfileController.list_profiles()`, `get_profile()`, `create_profile()`, `edit_profile()`, `remove_profile()`, `_validate_profile()`
- [x] `SchoolSearchController.list_subjects()`, `list_ccas()`; `reference_routes` GET /subjects and /ccas (Person B, 2026-11-06)
- [ ] `profile_routes` (5), `reference_routes`: subjects, ccas
- [ ] Pages: StudentProfileUI, HomeUI; ActiveStudentContext already declared

### F6 M8 School data sync (UC12); depends on F3, DATA-01 F2
- [x] `ExternalSchoolDataGateway.request_school_data()`, `_receive_school_data()` (+ `fetch_all()`, retry/backoff) (Person B, 2026-11-06)
- [x] `SchoolDataSyncController.synchronise_school_data()`, `_validate_school_data()`, `_record_sync_failure()`, `get_last_successful_sync()` (+ `synchronise_cca_data()` for ADR-006 CCAs) (Person B, 2026-11-06)
- [ ] `jobs.cli.sync_schools_command()` (Person A: one line, `SchoolDataSyncController().synchronise_school_data()`); [x] `reference_routes.data_freshness()` (Person B, 2026-11-06)
- Note (Person B): `OneMapGateway.geocode_postal_code()` (F4) was implemented here because the sync needs it. Seed rows (21 subjects, 4 criteria) must come from the F2 migration; the sync stops with a clear error if they are missing. Verified locally: 337 schools (all geocoded), 1,099 school–subject links, 175 CCAs, 7,135 school–CCA links; a re-run changes nothing.

### F7 M3 School discovery (UC04–UC06); depends on F6
- [x] `SchoolSearchController.search_schools()`, `filter_schools()`, `_apply_filters()` (Person B, 2026-11-06)
- [x] `SchoolDetailsController.retrieve_school_details()` (Person B, 2026-11-06)
- [x] `school_routes`: search_schools, school_details (Person B, 2026-11-06)
- [ ] Pages: SchoolSearchUI, SchoolDetailsUI; `client.searchSchools()`

### F8 M4 Comparison (UC07, UC07a–d); depends on F7
- [x] `DistanceCriterion`, `SubjectMatchCriterion`, `CcaMatchCriterion`, `AffiliationCriterion` `.evaluate()` (Person B, 2026-11-06). Distance = OneMap travel distance/time (`OneMapGateway.get_travel_route`, user decision), straight-line fallback with a note
- [x] `SchoolComparisonController.compare_schools()`, `_validate_selection()` (Person B, 2026-11-06)
- [x] `school_routes.compare_schools()` (Person B, 2026-11-06)
- [ ] Page: SchoolComparisonUI; `ComparisonSelectionContext` addSchool/removeSchool/canCompare

### F9 M5 Shortlist (UC08); depends on F5, F7
- [x] `ShortlistController.get_shortlist()`, `add_school_to_shortlist()`, `remove_school_from_shortlist()` (Person B, 2026-11-06). One shortlist per profile, created on first use. Uses `access_control.require_profile_owner()` (F3, implemented by Person B)
- [x] `shortlist_routes` (3) (Person B, 2026-11-06)
- [ ] Page: ShortlistUI; add-to-shortlist in SchoolDetailsUI

### F10 M6 Applications (UC09, UC10, UC13); depends on F5, F7
- [x] `ApplicationController.list_applications()`, `create_application()`, `get_application()`, `update_application()` (2026-11-07). Returned applications carry `.school` (helper `attach_school`); `updated_at` uses the database clock (`touch`); a retired school (`is_active = false`) gives 404 on create, as in the shortlist.
- [x] `ApplicationStatusController.get_application_status()`, `update_application_status()`, `_validate_status_transition()` (2026-11-07). Entering Submitted sets `date_submitted` to today in Asia/Singapore (`singapore_today()`, reusable by F11); a refused move is 409 with `details.allowed`.
- [x] `ApplicationDeadlineController.get_deadline()`, `set_deadline()`, `clear_deadline()`, `_validate_deadline()` (2026-11-07)
- [x] `application_routes` (7) (2026-11-07)
- [ ] Pages: ApplicationUI, ApplicationStatusUI, ApplicationDeadlineUI (frontend, out of scope for the backend team)
- Tests: `tests/test_person_a_applications.py` (22: controllers, state machine, deadlines, HTTP flow, 400/404/409/401).

### F11 M7 Notifications (UC11); depends on F10
- [x] `ReminderController.check_deadlines()`, `generate_reminder()`, `list_notifications()`, `_is_notification_opted_in()`, `_is_reminder_already_generated()` (2026-11-07). Window today to today + 7 in Asia/Singapore (inclusive); each insert in its own savepoint, so one failure is logged and the rest still save; a lost race on the unique constraint counts as already reminded. `channel` keeps the column default 'email' until ARC-02 Q2 is decided; no email is sent.
- [ ] `ReminderController.mark_as_read()` and `PATCH /notifications/<id>/read`: implemented 2026-11-07 with `deadline_reminder.is_read` (migration `c3f1a7d2e9b4`, DATA-01 v1.1); tick once `flask db upgrade` and the tests pass
- [x] `jobs.cli.check_deadlines_command()`; daily job in `register_jobs()` (done in F3, 2026-11-06)
- [x] `notification_routes`: list_notifications (2026-11-07); mark_notification_read implemented, not yet verified (above)
- [ ] Page: NotificationUI (frontend, out of scope for the backend team)
- Tests: `tests/test_person_a_reminders.py` (13: window edges, repeat runs, opt-out, changed deadline, failure isolation and retry, CLI, list and HTTP, mark-as-read: idempotent, HTTP, other user's 404, unknown id and 401).
- Notes for the architect: UC11 does not say whether finished applications (Rejected, Accepted) still get reminders; they currently do if a deadline is set.

## Skeleton check (2026-10-25)

- `py -m compileall App` (now `app`): OK.
- Import test in a scratch venv (Flask, Flask-SQLAlchemy, Flask-Migrate, GeoAlchemy2, Flask-JWT-Extended, marshmallow, APScheduler, requests): every module imports; 7 blueprints with 30 routes, matching all 30 rows of ARC-02 §4.1; `ALLOWED_TRANSITIONS` covers all 6 `ApplicationStatus` values.
- Front end: not type-checked; Node.js is not installed on this machine. Run `npm install && npx tsc -b` in `app/frontend` to check.

## Open questions

1. ARC-02 Q1: add `deadline_reminder.is_read` (DATA-01 v1.1)? Implemented 2026-11-07 as `boolean NOT NULL DEFAULT false` (migration `c3f1a7d2e9b4`); DATA-01 still needs the v1.1 update.
2. ARC-02 Q2: email reminders through SES, or in-app only?
3. ARC-02 Q3/Q4: straight-line distance in PostGIS (as stubbed) or OneMap travel distance?
4. Subject and affiliation datasets are not named yet (INT-01); only the school dataset id is in the gateway, plus the candidate CCA dataset.
