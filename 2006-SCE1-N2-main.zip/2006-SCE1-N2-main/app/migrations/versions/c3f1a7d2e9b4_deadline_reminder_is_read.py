"""deadline_reminder.is_read: the notification read flag (DATA-01 v1.1, ARC-02 Q1)

Revision ID: c3f1a7d2e9b4
Revises: b44eb0ca9710
Create Date: 2026-11-07 18:00:00

Adds `is_read boolean NOT NULL DEFAULT false`. Existing reminders become unread, which is what
GET /api/notifications already reported for them.
"""
from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision = 'c3f1a7d2e9b4'
down_revision = 'b44eb0ca9710'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column(
        'deadline_reminder',
        sa.Column('is_read', sa.Boolean(), server_default=sa.text('false'), nullable=False),
    )


def downgrade():
    op.drop_column('deadline_reminder', 'is_read')
