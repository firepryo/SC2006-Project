"""Person A tests: applications (F10: UC09 create/edit, UC10 status, UC13 deadline).

Run from the repository root, against a local database that has had `flask db upgrade` and one school sync:
    python -m pytest app/tests/test_person_a_applications.py -v

Each test creates its own users and profiles and deletes them afterwards; deleting a user cascades to its
profiles and applications (DATA-01 §3.5).
"""
import uuid
from datetime import date, datetime

import pytest
from flask_jwt_extended import create_access_token, get_csrf_token
from sqlalchemy import delete, func, select

from app.app import create_app
from app.control import ApplicationController, ApplicationDeadlineController, ApplicationStatusController
from app.control.application_status_controller import singapore_today
from app.errors import ConflictError, NotFoundError, ValidationError
from app.extensions import db
from app.models import Application, School, StudentProfile, UserAccount
from app.models.enums import ApplicationStatus, EducationLevel

S = ApplicationStatus


# ---------------------------------------------------------------- fixtures


@pytest.fixture(scope="module")
def app():
    flask_app = create_app()
    flask_app.config["TESTING"] = True
    with flask_app.app_context():
        if db.session.scalar(select(func.count()).select_from(School)) < 2:
            pytest.skip("Run `flask db upgrade` and `flask sync-schools` first: the tests use real school rows.")
        yield flask_app


@pytest.fixture
def user(app):
    created = []

    def factory() -> UserAccount:
        account = UserAccount(
            name="Person A test",
            email=f"person-a-{uuid.uuid4().hex[:12]}@test.local",
            password_hash="not-a-real-hash",
        )
        db.session.add(account)
        db.session.commit()
        created.append(account)
        return account

    yield factory
    db.session.rollback()
    db.session.execute(delete(UserAccount).where(UserAccount.user_id.in_([u.user_id for u in created])))
    db.session.commit()


@pytest.fixture
def profile(user):
    def factory(owner: UserAccount | None = None) -> StudentProfile:
        owner = owner or user()
        student = StudentProfile(user_id=owner.user_id, name="Test child", current_level=EducationLevel.Primary, current_year=6)
        db.session.add(student)
        db.session.commit()
        return student

    return factory


@pytest.fixture
def schools(app):
    """Two active schools from the synced catalogue."""
    rows = list(db.session.scalars(select(School).where(School.is_active).order_by(School.name).limit(2)))
    return rows[0], rows[1]


def _client(app, account: UserAccount):
    """A test client logged in as `account`, sending the CSRF header that cookie JWTs require."""
    token = create_access_token(identity=str(account.user_id))
    client = app.test_client()
    client.set_cookie("access_token_cookie", token)
    client.environ_base["HTTP_X_CSRF_TOKEN"] = get_csrf_token(token)
    return client


def _new_application(owner, student, school, notes=None) -> Application:
    return ApplicationController().create_application(owner.user_id, student.student_id, school.school_id, notes)


# ---------------------------------------------------------------- UC09 applications


class TestApplications:
    def test_create_is_draft_with_school(self, user, profile, schools):
        owner = user()
        student = profile(owner)
        application = _new_application(owner, student, schools[0], "Open house in March")
        assert application.status is S.Draft
        assert application.date_submitted is None and application.deadline is None
        assert application.notes == "Open house in March"
        assert application.school.school_id == schools[0].school_id
        assert application.updated_at is not None

    def test_duplicate_is_conflict(self, user, profile, schools):
        owner = user()
        student = profile(owner)
        first = _new_application(owner, student, schools[0])
        with pytest.raises(ConflictError) as error:
            _new_application(owner, student, schools[0])
        assert error.value.details["application_id"] == str(first.application_id)

    def test_same_school_for_two_students_is_fine(self, user, profile, schools):
        owner = user()
        _new_application(owner, profile(owner), schools[0])
        _new_application(owner, profile(owner), schools[0])

    def test_unknown_school_not_found(self, user, profile):
        owner = user()
        with pytest.raises(NotFoundError):
            ApplicationController().create_application(owner.user_id, profile(owner).student_id, uuid.uuid4())

    def test_inactive_school_not_found(self, user, profile, schools):
        owner = user()
        student = profile(owner)
        school = schools[1]
        school.is_active = False
        db.session.commit()
        try:
            with pytest.raises(NotFoundError):
                _new_application(owner, student, school)
        finally:
            school.is_active = True
            db.session.commit()

    def test_other_users_profile_not_found(self, user, profile, schools):
        stranger = user()
        student = profile()  # another user's profile
        with pytest.raises(NotFoundError):
            ApplicationController().create_application(stranger.user_id, student.student_id, schools[0].school_id)
        with pytest.raises(NotFoundError):
            ApplicationController().list_applications(stranger.user_id, student.student_id)

    def test_list_all_profiles_or_one(self, user, profile, schools):
        owner = user()
        first, second = profile(owner), profile(owner)
        _new_application(owner, first, schools[0])
        _new_application(owner, second, schools[1])
        other_owner = user()
        _new_application(other_owner, profile(other_owner), schools[0])  # never listed for owner

        everything = ApplicationController().list_applications(owner.user_id)
        assert {a.student_id for a in everything} == {first.student_id, second.student_id}
        assert all(a.school is not None for a in everything)
        only_first = ApplicationController().list_applications(owner.user_id, first.student_id)
        assert [a.student_id for a in only_first] == [first.student_id]

    def test_get_and_update_notes(self, user, profile, schools):
        owner = user()
        application = _new_application(owner, profile(owner), schools[0])
        before = application.updated_at
        updated = ApplicationController().update_application(owner.user_id, application.application_id, "Bring report book")
        assert updated.notes == "Bring report book" and updated.updated_at > before
        cleared = ApplicationController().update_application(owner.user_id, application.application_id, None)
        assert cleared.notes is None
        fetched = ApplicationController().get_application(owner.user_id, application.application_id)
        assert fetched.school.school_id == schools[0].school_id

    def test_other_users_application_not_found(self, user, profile, schools):
        owner, stranger = user(), user()
        application = _new_application(owner, profile(owner), schools[0])
        with pytest.raises(NotFoundError):
            ApplicationController().get_application(stranger.user_id, application.application_id)
        with pytest.raises(NotFoundError):
            ApplicationController().update_application(stranger.user_id, application.application_id, "x")


# ---------------------------------------------------------------- UC10 status


class TestStatus:
    def test_validate_transition_matches_table(self):
        controller = ApplicationStatusController()
        allowed = {(a, b) for a, targets in controller.ALLOWED_TRANSITIONS.items() for b in targets}
        assert allowed == {(S.Draft, S.Submitted), (S.Submitted, S.UnderReview), (S.UnderReview, S.Offered),
                           (S.UnderReview, S.Rejected), (S.Offered, S.Accepted)}
        for current in S:
            for target in S:
                assert controller._validate_status_transition(current, target) == ((current, target) in allowed)

    def test_full_path_sets_date_submitted(self, user, profile, schools):
        owner = user()
        application = _new_application(owner, profile(owner), schools[0])
        controller = ApplicationStatusController()
        submitted = controller.update_application_status(owner.user_id, application.application_id, S.Submitted)
        assert submitted.status is S.Submitted and submitted.date_submitted == singapore_today()
        for status in (S.UnderReview, S.Offered, S.Accepted):
            result = controller.update_application_status(owner.user_id, application.application_id, status)
            assert result.status is status
        assert controller.get_application_status(owner.user_id, application.application_id) is S.Accepted
        assert result.date_submitted == singapore_today()  # kept after Submitted

    def test_invalid_transition_is_conflict_and_unchanged(self, user, profile, schools):
        owner = user()
        application = _new_application(owner, profile(owner), schools[0])
        with pytest.raises(ConflictError) as error:
            ApplicationStatusController().update_application_status(owner.user_id, application.application_id, S.Offered)
        assert error.value.details == {"current_status": "Draft", "requested_status": "Offered", "allowed": ["Submitted"]}
        assert ApplicationStatusController().get_application_status(owner.user_id, application.application_id) is S.Draft

    def test_final_states_allow_nothing(self, user, profile, schools):
        owner = user()
        application = _new_application(owner, profile(owner), schools[0])
        controller = ApplicationStatusController()
        for status in (S.Submitted, S.UnderReview, S.Rejected):
            controller.update_application_status(owner.user_id, application.application_id, status)
        with pytest.raises(ConflictError):
            controller.update_application_status(owner.user_id, application.application_id, S.Accepted)

    def test_other_users_application_not_found(self, user, profile, schools):
        owner, stranger = user(), user()
        application = _new_application(owner, profile(owner), schools[0])
        with pytest.raises(NotFoundError):
            ApplicationStatusController().update_application_status(stranger.user_id, application.application_id, S.Submitted)


# ---------------------------------------------------------------- UC13 deadline


class TestDeadline:
    def test_set_change_clear(self, user, profile, schools):
        owner = user()
        application = _new_application(owner, profile(owner), schools[0])
        controller = ApplicationDeadlineController()
        assert controller.get_deadline(owner.user_id, application.application_id) is None
        controller.set_deadline(owner.user_id, application.application_id, date(2027, 3, 1))
        changed = controller.set_deadline(owner.user_id, application.application_id, date(2027, 4, 15))
        assert changed.deadline == date(2027, 4, 15) and changed.school is not None
        cleared = controller.clear_deadline(owner.user_id, application.application_id)
        assert cleared.deadline is None
        assert controller.get_deadline(owner.user_id, application.application_id) is None

    def test_past_date_is_stored(self, user, profile, schools):
        owner = user()
        application = _new_application(owner, profile(owner), schools[0])
        stored = ApplicationDeadlineController().set_deadline(owner.user_id, application.application_id, date(2020, 1, 1))
        assert stored.deadline == date(2020, 1, 1)  # UC13 alt flow 2: kept, never reminded

    def test_datetime_is_rejected(self, user, profile, schools):
        owner = user()
        application = _new_application(owner, profile(owner), schools[0])
        with pytest.raises(ValidationError):
            ApplicationDeadlineController().set_deadline(owner.user_id, application.application_id, datetime(2027, 1, 1, 9))

    def test_other_users_application_not_found(self, user, profile, schools):
        owner, stranger = user(), user()
        application = _new_application(owner, profile(owner), schools[0])
        with pytest.raises(NotFoundError):
            ApplicationDeadlineController().set_deadline(stranger.user_id, application.application_id, date(2027, 1, 1))
        with pytest.raises(NotFoundError):
            ApplicationDeadlineController().clear_deadline(stranger.user_id, application.application_id)


# ---------------------------------------------------------------- HTTP (application_routes, §4.2 errors)


class TestHttp:
    def test_full_flow(self, app, user, profile, schools):
        owner = user()
        student = profile(owner)
        client = _client(app, owner)

        created = client.post("/api/applications", json={"student_id": str(student.student_id), "school_id": str(schools[0].school_id)})
        assert created.status_code == 201
        body = created.get_json()
        assert body["status"] == "Draft" and body["school"]["name"] == schools[0].name and body["deadline"] is None
        app_url = f"/api/applications/{body['application_id']}"

        duplicate = client.post("/api/applications", json={"student_id": str(student.student_id), "school_id": str(schools[0].school_id)})
        assert duplicate.status_code == 409 and duplicate.get_json()["error"] == "conflict"

        listed = client.get(f"/api/applications?student_id={student.student_id}")
        assert listed.status_code == 200 and [a["application_id"] for a in listed.get_json()] == [body["application_id"]]
        assert client.get("/api/applications").status_code == 200

        patched = client.patch(app_url, json={"notes": "Ballot phase 2B"})
        assert patched.status_code == 200 and patched.get_json()["notes"] == "Ballot phase 2B"

        bad_move = client.patch(f"{app_url}/status", json={"status": "Accepted"})
        assert bad_move.status_code == 409 and bad_move.get_json()["details"]["allowed"] == ["Submitted"]
        submitted = client.patch(f"{app_url}/status", json={"status": "Submitted"})
        assert submitted.status_code == 200 and submitted.get_json()["date_submitted"] == singapore_today().isoformat()

        deadline = client.put(f"{app_url}/deadline", json={"deadline": "2027-02-28"})
        assert deadline.status_code == 200 and deadline.get_json()["deadline"] == "2027-02-28"
        cleared = client.delete(f"{app_url}/deadline")
        assert cleared.status_code == 200 and cleared.get_json()["deadline"] is None

        fetched = client.get(app_url)
        assert fetched.status_code == 200 and fetched.get_json()["status"] == "Submitted"

    def test_bad_input_is_400(self, app, user, profile, schools):
        owner = user()
        client = _client(app, owner)
        missing = client.post("/api/applications", json={"school_id": str(schools[0].school_id)})
        assert missing.status_code == 400 and "student_id" in missing.get_json()["details"]["json"]

        application = _new_application(owner, profile(owner), schools[0])
        app_url = f"/api/applications/{application.application_id}"
        assert client.put(f"{app_url}/deadline", json={"deadline": "2027-02-30"}).status_code == 400
        assert client.patch(f"{app_url}/status", json={"status": "Waiting"}).status_code == 400

    def test_foreign_and_missing_are_404(self, app, user, profile, schools):
        owner, stranger = user(), user()
        application = _new_application(owner, profile(owner), schools[0])
        client = _client(app, stranger)
        for response in (
            client.get(f"/api/applications/{application.application_id}"),
            client.patch(f"/api/applications/{application.application_id}", json={"notes": "x"}),
            client.delete(f"/api/applications/{application.application_id}/deadline"),
            client.get(f"/api/applications/{uuid.uuid4()}"),
            client.get(f"/api/applications?student_id={profile(owner).student_id}"),
        ):
            assert response.status_code == 404 and response.get_json()["error"] == "not_found"

    def test_requires_login(self, app):
        response = app.test_client().get("/api/applications")
        assert response.status_code == 401 and response.get_json()["error"] == "unauthorised"
