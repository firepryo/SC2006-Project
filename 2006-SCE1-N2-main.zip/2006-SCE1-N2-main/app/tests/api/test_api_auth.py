"""/auth/register, /auth/login, /auth/logout, /auth/me and /users/me."""
import uuid
from datetime import datetime, timedelta, timezone

import pytest
from sqlalchemy import select

from api_helpers import UNKNOWN_POSTAL_CODE, assert_error
from app.extensions import db
from app.models import UserAccount
from conftest import PASSWORD, unique_email

SECRET_FIELDS = {"password", "password_hash", "failed_login_count", "locked_until"}


def payload(**overrides) -> dict:
    return {"name": "Test Parent", "email": unique_email(), "password": PASSWORD, **overrides}


def stored_account(in_db, email):
    def work():
        row = db.session.scalar(select(UserAccount).where(UserAccount.email == email))
        return row.preferred_postal_code, row.home_location is not None, row.password_hash

    return in_db(work)


class TestRegister:
    def test_success_returns_account_without_secrets(self, anonymous):
        data = payload()
        response = anonymous.post("/api/auth/register", json=data)
        assert response.status_code == 201
        body = response.get_json()
        assert set(body) == {"user_id", "name", "email", "preferred_postal_code", "notification_opt_in"}
        assert uuid.UUID(body["user_id"]) and body["name"] == data["name"] and body["email"] == data["email"]
        assert body["preferred_postal_code"] is None and body["notification_opt_in"] is True
        assert not SECRET_FIELDS & set(body)

    def test_password_is_stored_hashed(self, anonymous, in_db):
        data = payload()
        anonymous.post("/api/auth/register", json=data)
        assert stored_account(in_db, data["email"])[2] != PASSWORD

    def test_can_opt_out_of_notifications(self, anonymous):
        body = anonymous.post("/api/auth/register", json=payload(notification_opt_in=False)).get_json()
        assert body["notification_opt_in"] is False

    @pytest.mark.parametrize("field", ["name", "email", "password"])
    def test_required_field_missing_is_400(self, anonymous, field):
        data = payload()
        del data[field]
        assert_error(anonymous.post("/api/auth/register", json=data), 400, "validation_failed", field)

    @pytest.mark.parametrize(
        "field, value",
        [
            ("name", "   "),
            ("name", "x" * 101),
            ("email", "not-an-email"),
            ("email", "missing@domain"),
            ("password", "x" * 7),
            ("preferred_postal_code", "12345"),
            ("preferred_postal_code", "1234567"),
            ("preferred_postal_code", "12a456"),
        ],
    )
    def test_invalid_field_is_400(self, anonymous, field, value):
        assert_error(anonymous.post("/api/auth/register", json=payload(**{field: value})), 400, "validation_failed", field)

    @pytest.mark.parametrize("field, value", [("name", "x" * 100), ("password", "x" * 8)])
    def test_boundary_values_are_accepted(self, anonymous, field, value):
        assert anonymous.post("/api/auth/register", json=payload(**{field: value})).status_code == 201

    def test_unknown_field_is_400(self, anonymous):
        assert_error(anonymous.post("/api/auth/register", json=payload(role="admin")), 400, "validation_failed", "role")

    def test_duplicate_email_is_409(self, anonymous):
        data = payload()
        assert anonymous.post("/api/auth/register", json=data).status_code == 201
        assert_error(anonymous.post("/api/auth/register", json=data), 409, "conflict", "email")

    def test_duplicate_email_ignores_case(self, anonymous):
        data = payload()
        assert anonymous.post("/api/auth/register", json=data).status_code == 201
        assert_error(anonymous.post("/api/auth/register", json={**data, "email": data["email"].upper()}), 409, "conflict")

    def test_postal_code_is_geocoded(self, anonymous, in_db, fake_onemap):
        data = payload(preferred_postal_code="123456")
        assert anonymous.post("/api/auth/register", json=data).status_code == 201
        assert stored_account(in_db, data["email"])[:2] == ("123456", True)

    def test_unknown_postal_code_still_registers(self, anonymous, in_db, fake_onemap):
        data = payload(preferred_postal_code=UNKNOWN_POSTAL_CODE)
        assert anonymous.post("/api/auth/register", json=data).status_code == 201
        assert stored_account(in_db, data["email"])[1] is False

    def test_onemap_outage_still_registers(self, anonymous, in_db, fake_onemap):
        fake_onemap.fail = True
        data = payload(preferred_postal_code="123456")
        assert anonymous.post("/api/auth/register", json=data).status_code == 201
        assert stored_account(in_db, data["email"])[1] is False

    @pytest.mark.usefixtures("live_onemap")
    @pytest.mark.live_onemap
    def test_real_school_postal_code_is_geocoded_by_onemap(self, anonymous, in_db, located_school):
        data = payload(preferred_postal_code=located_school.postal_code)
        assert anonymous.post("/api/auth/register", json=data).status_code == 201
        assert stored_account(in_db, data["email"])[:2] == (located_school.postal_code, True)


class TestLogin:
    def login(self, client, email, password):
        return client.post("/api/auth/login", json={"email": email, "password": password})

    def test_success_returns_account_and_sets_cookies(self, anonymous, user):
        response = self.login(anonymous, user.email, user.password)
        assert response.status_code == 200
        body = response.get_json()
        assert body["user_id"] == user.user_id and not SECRET_FIELDS & set(body)
        names = {h.split("=")[0] for h in response.headers.getlist("Set-Cookie")}
        assert {"access_token_cookie", "csrf_access_token"} <= names

    def test_email_ignores_case(self, anonymous, user):
        assert self.login(anonymous, user.email.upper(), user.password).status_code == 200

    def test_wrong_password_is_401(self, anonymous, user):
        assert_error(self.login(anonymous, user.email, "WrongPassword1"), 401, "invalid_credentials")

    def test_unknown_email_is_401(self, anonymous):
        assert_error(self.login(anonymous, unique_email(), PASSWORD), 401, "invalid_credentials")

    @pytest.mark.parametrize("field", ["email", "password"])
    def test_required_field_missing_is_400(self, anonymous, field):
        data = {"email": unique_email(), "password": PASSWORD}
        del data[field]
        assert_error(anonymous.post("/api/auth/login", json=data), 400, "validation_failed", field)

    def test_malformed_email_is_400(self, anonymous):
        assert_error(self.login(anonymous, "not-an-email", PASSWORD), 400, "validation_failed", "email")

    def test_fifth_failure_locks_the_account(self, anonymous, user):
        for _ in range(4):
            assert_error(self.login(anonymous, user.email, "WrongPassword1"), 401, "invalid_credentials")
        body = assert_error(self.login(anonymous, user.email, "WrongPassword1"), 423, "account_locked", "remaining_seconds")
        assert 0 < body["details"]["remaining_seconds"] <= 15 * 60

    def test_correct_password_is_refused_while_locked(self, anonymous, user):
        for _ in range(5):
            self.login(anonymous, user.email, "WrongPassword1")
        assert_error(self.login(anonymous, user.email, user.password), 423, "account_locked")

    def test_success_resets_the_failure_count(self, anonymous, user):
        for _ in range(4):
            self.login(anonymous, user.email, "WrongPassword1")
        assert self.login(anonymous, user.email, user.password).status_code == 200
        assert_error(self.login(anonymous, user.email, "WrongPassword1"), 401, "invalid_credentials")

    def test_login_works_again_after_the_lock_expires(self, anonymous, in_db, user):
        for _ in range(5):
            self.login(anonymous, user.email, "WrongPassword1")

        def expire_lock():
            db.session.get(UserAccount, uuid.UUID(user.user_id)).locked_until = datetime.now(timezone.utc) - timedelta(seconds=1)
            db.session.commit()

        in_db(expire_lock)
        assert self.login(anonymous, user.email, user.password).status_code == 200


class TestLogout:
    def test_clears_the_session(self, user):
        response = user.client.post("/api/auth/logout")
        assert response.status_code == 204 and response.get_data() == b""
        assert user.client.get_cookie("access_token_cookie") is None
        assert_error(user.client.get("/api/auth/me"), 401, "unauthorised")


class TestCurrentUser:
    def test_returns_the_logged_in_account(self, user):
        response = user.client.get("/api/auth/me")
        assert response.status_code == 200
        assert response.get_json()["user_id"] == user.user_id and response.get_json()["email"] == user.email

    def test_deleted_account_is_404(self, in_db, new_user):
        account = new_user()

        def remove():
            db.session.delete(db.session.get(UserAccount, uuid.UUID(account.user_id)))
            db.session.commit()

        in_db(remove)
        assert_error(account.client.get("/api/auth/me"), 404, "not_found")


class TestHomeLocation:
    def patch(self, account, value):
        return account.client.patch("/api/users/me", json={"preferred_postal_code": value})

    def test_set_and_clear(self, user, fake_onemap, in_db):
        response = self.patch(user, "123456")
        assert response.status_code == 200 and response.get_json()["preferred_postal_code"] == "123456"
        assert stored_account(in_db, user.email)[:2] == ("123456", True)
        cleared = self.patch(user, "")
        assert cleared.status_code == 200 and cleared.get_json()["preferred_postal_code"] is None
        assert stored_account(in_db, user.email)[:2] == (None, False)

    @pytest.mark.parametrize("value", ["12345", "1234567", "abcdef"])
    def test_malformed_postal_code_is_400(self, user, fake_onemap, value):
        assert_error(self.patch(user, value), 400, "validation_failed", "preferred_postal_code")

    def test_field_is_required(self, user):
        assert_error(user.client.patch("/api/users/me", json={}), 400, "validation_failed", "preferred_postal_code")

    def test_postal_code_onemap_cannot_find_is_400(self, user, fake_onemap):
        assert_error(self.patch(user, UNKNOWN_POSTAL_CODE), 400, "validation_failed", "preferred_postal_code")

    def test_onemap_outage_is_503_and_keeps_the_old_home(self, user, fake_onemap, in_db):
        self.patch(user, "123456")
        fake_onemap.fail = True
        assert_error(self.patch(user, "654321"), 503, "external_unavailable")
        assert stored_account(in_db, user.email)[0] == "123456"

    @pytest.mark.usefixtures("live_onemap")
    @pytest.mark.live_onemap
    def test_real_school_postal_code_is_accepted_by_onemap(self, user, located_school):
        response = self.patch(user, located_school.postal_code)
        assert response.status_code == 200 and response.get_json()["preferred_postal_code"] == located_school.postal_code
