"""/profiles/<student_id>/shortlist and its entries, using real schools."""
import pytest

from api_helpers import assert_error

UNKNOWN = "00000000-0000-4000-8000-000000000004"


@pytest.fixture
def base(student):
    return f"/api/profiles/{student['student_id']}/shortlist"


def add(account, base_path, school_id):
    return account.client.post(f"{base_path}/entries", json={"school_id": school_id})


class TestView:
    def test_new_profile_has_an_empty_shortlist(self, user, base):
        response = user.client.get(base)
        assert response.status_code == 200
        body = response.get_json()
        assert set(body) == {"shortlist_id", "name", "notes", "entries"} and body["entries"] == []

    def test_other_users_profile_is_404(self, other_user, base):
        assert_error(other_user.client.get(base), 404, "not_found")

    def test_unknown_profile_is_404(self, user):
        assert_error(user.client.get(f"/api/profiles/{UNKNOWN}/shortlist"), 404, "not_found")


class TestAdd:
    def test_adds_a_real_school(self, user, base, schools):
        response = add(user, base, schools[0].id)
        assert response.status_code == 201
        entry = response.get_json()
        assert set(entry) == {"entry_id", "school", "date_added", "rank"}
        assert entry["school"]["school_id"] == schools[0].id and entry["school"]["name"] == schools[0].name
        assert [e["entry_id"] for e in user.client.get(base).get_json()["entries"]] == [entry["entry_id"]]

    def test_same_school_twice_is_409(self, user, base, schools):
        entry = add(user, base, schools[0].id).get_json()
        body = assert_error(add(user, base, schools[0].id), 409, "conflict", "entry_id")
        assert body["details"]["entry_id"] == entry["entry_id"]

    def test_several_schools(self, user, base, schools):
        for school in schools[:3]:
            assert add(user, base, school.id).status_code == 201
        assert {e["school"]["school_id"] for e in user.client.get(base).get_json()["entries"]} == {s.id for s in schools[:3]}

    def test_shortlists_are_per_student(self, user, new_student, base, schools):
        other = f"/api/profiles/{new_student(user)['student_id']}/shortlist"
        assert add(user, base, schools[0].id).status_code == 201
        assert add(user, other, schools[0].id).status_code == 201
        assert len(user.client.get(other).get_json()["entries"]) == 1

    def test_unknown_school_is_404(self, user, base):
        assert_error(add(user, base, UNKNOWN), 404, "not_found")

    def test_other_users_profile_is_404(self, other_user, base, schools):
        assert_error(add(other_user, base, schools[0].id), 404, "not_found")

    def test_school_id_is_required(self, user, base):
        assert_error(user.client.post(f"{base}/entries", json={}), 400, "validation_failed", "school_id")

    def test_malformed_school_id_is_400(self, user, base):
        assert_error(add(user, base, "not-a-uuid"), 400, "validation_failed", "school_id")


class TestRemove:
    def test_removes_the_entry(self, user, base, schools):
        entry = add(user, base, schools[0].id).get_json()
        response = user.client.delete(f"{base}/entries/{entry['entry_id']}")
        assert response.status_code == 204 and response.get_data() == b""
        assert user.client.get(base).get_json()["entries"] == []

    def test_removing_twice_is_404(self, user, base, schools):
        entry = add(user, base, schools[0].id).get_json()
        user.client.delete(f"{base}/entries/{entry['entry_id']}")
        assert_error(user.client.delete(f"{base}/entries/{entry['entry_id']}"), 404, "not_found")

    def test_unknown_entry_is_404(self, user, base):
        assert_error(user.client.delete(f"{base}/entries/{UNKNOWN}"), 404, "not_found")

    def test_entry_of_another_profile_is_404(self, user, new_student, base, schools):
        entry = add(user, base, schools[0].id).get_json()
        other = f"/api/profiles/{new_student(user)['student_id']}/shortlist"
        assert_error(user.client.delete(f"{other}/entries/{entry['entry_id']}"), 404, "not_found")

    def test_other_users_profile_is_404_and_entry_is_kept(self, user, other_user, base, schools):
        entry = add(user, base, schools[0].id).get_json()
        assert_error(other_user.client.delete(f"{base}/entries/{entry['entry_id']}"), 404, "not_found")
        assert len(user.client.get(base).get_json()["entries"]) == 1

    def test_removing_a_school_keeps_its_application(self, user, base, student, schools, new_application):
        application = new_application(user, student, schools[0])
        entry = add(user, base, schools[0].id).get_json()
        assert user.client.delete(f"{base}/entries/{entry['entry_id']}").status_code == 204
        assert user.client.get(f"/api/applications/{application['application_id']}").status_code == 200
