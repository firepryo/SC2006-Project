"""/notifications, /notifications/<id>/read and /users/me/notification-preference."""
import uuid
from datetime import date

import pytest

from api_helpers import assert_error
from app.control import ReminderController
from app.extensions import db
from app.models import Application

UNKNOWN = "00000000-0000-4000-8000-000000000006"


@pytest.fixture
def make_reminder(in_db):
    """Create one stored reminder for an application, without scanning anyone else's deadlines."""

    def factory(application: dict, deadline: date = date(2027, 3, 1)) -> str:
        def work():
            row = db.session.get(Application, uuid.UUID(application["application_id"]))
            row.deadline = deadline
            reminder = ReminderController().generate_reminder(row)
            db.session.commit()
            return str(reminder.reminder_id)

        return in_db(work)

    return factory


class TestList:
    def test_empty_for_a_new_account(self, user):
        response = user.client.get("/api/notifications")
        assert response.status_code == 200 and response.get_json() == []

    def test_lists_my_reminder_as_unread(self, user, application, make_reminder):
        reminder_id = make_reminder(application)
        rows = user.client.get("/api/notifications").get_json()
        assert len(rows) == 1
        assert set(rows[0]) == {"reminder_id", "application_id", "remind_for_deadline", "sent_at", "is_read"}
        assert rows[0]["reminder_id"] == reminder_id and rows[0]["application_id"] == application["application_id"]
        assert rows[0]["remind_for_deadline"] == "2027-03-01" and rows[0]["is_read"] is False

    def test_other_users_reminders_are_hidden(self, other_user, application, make_reminder):
        make_reminder(application)
        assert other_user.client.get("/api/notifications").get_json() == []


class TestMarkAsRead:
    def test_marks_read_and_persists(self, user, application, make_reminder):
        reminder_id = make_reminder(application)
        response = user.client.patch(f"/api/notifications/{reminder_id}/read")
        assert response.status_code == 200
        assert response.get_json()["reminder_id"] == reminder_id and response.get_json()["is_read"] is True
        assert user.client.get("/api/notifications").get_json()[0]["is_read"] is True

    def test_marking_twice_is_fine(self, user, application, make_reminder):
        reminder_id = make_reminder(application)
        user.client.patch(f"/api/notifications/{reminder_id}/read")
        response = user.client.patch(f"/api/notifications/{reminder_id}/read")
        assert response.status_code == 200 and response.get_json()["is_read"] is True

    def test_other_users_reminder_is_404_and_stays_unread(self, user, other_user, application, make_reminder):
        reminder_id = make_reminder(application)
        assert_error(other_user.client.patch(f"/api/notifications/{reminder_id}/read"), 404, "not_found")
        assert user.client.get("/api/notifications").get_json()[0]["is_read"] is False

    def test_unknown_reminder_is_404(self, user):
        assert_error(user.client.patch(f"/api/notifications/{UNKNOWN}/read"), 404, "not_found")

    def test_malformed_id_is_404(self, user):
        assert_error(user.client.patch("/api/notifications/not-a-uuid/read"), 404, "not_found")


class TestPreference:
    URL = "/api/users/me/notification-preference"

    def test_default_is_on(self, user):
        response = user.client.get(self.URL)
        assert response.status_code == 200 and response.get_json() == {"notification_opt_in": True}

    def test_registration_choice_is_used(self, new_user):
        account = new_user(notification_opt_in=False)
        assert account.client.get(self.URL).get_json() == {"notification_opt_in": False}

    @pytest.mark.parametrize("value", [False, True])
    def test_saves_the_value(self, user, value):
        response = user.client.put(self.URL, json={"notification_opt_in": value})
        assert response.status_code == 200 and response.get_json() == {"notification_opt_in": value}
        assert user.client.get(self.URL).get_json() == {"notification_opt_in": value}

    def test_field_is_required(self, user):
        assert_error(user.client.put(self.URL, json={}), 400, "validation_failed", "notification_opt_in")

    def test_non_boolean_is_400(self, user):
        response = user.client.put(self.URL, json={"notification_opt_in": "maybe"})
        assert_error(response, 400, "validation_failed", "notification_opt_in")
