"""Fixtures for the HTTP API tests: every test goes through the real routes, JWT cookie and CSRF header.

Run from the repository root, after `flask db upgrade` and one `flask sync-schools`:
    .venv/bin/python -m pytest app/tests/api -v

The tests read the real synchronised schools and never change them. Accounts use the EMAIL_DOMAIN below and
are deleted at the end of the run; deleting an account cascades to its profiles, shortlists and applications.
Tests marked live_onemap call the real OneMap API and are skipped when no usable credentials are configured.
"""
import base64
import json
import os
import time
import uuid
from dataclasses import dataclass
from types import SimpleNamespace

import pytest
from flask.testing import FlaskClient
from geoalchemy2.elements import WKTElement
from sqlalchemy import delete, select

import app.boundary.auth_routes as auth_routes
import app.boundary.school_routes as school_routes
from api_helpers import HOME, FakeOneMap
from app.app import create_app
from app.control.comparison_criteria import DistanceCriterion
from app.extensions import db
from app.models import School, SchoolCca, SchoolSubject, UserAccount

EMAIL_DOMAIN = "@api-test.local"
PASSWORD = "CorrectHorse1"
MIN_REAL_SCHOOLS = 300


def pytest_configure(config):
    config.addinivalue_line("markers", "live_onemap: calls the real OneMap API; needs a valid token or login in app/.env")


@dataclass
class ApiUser:
    """A logged-in account: `client` carries its cookies and sends the CSRF header."""

    client: FlaskClient
    email: str
    password: str
    user_id: str


def unique_email() -> str:
    return f"user-{uuid.uuid4().hex[:12]}{EMAIL_DOMAIN}"


@pytest.fixture(scope="session")
def app():
    flask_app = create_app()
    flask_app.config["TESTING"] = True
    flask_app.config["JWT_COOKIE_SECURE"] = False  # the test client talks plain http
    with flask_app.app_context():
        active = db.session.scalars(select(School.school_id).where(School.is_active)).all()
        if len(active) < MIN_REAL_SCHOOLS:
            pytest.skip("Run `flask db upgrade` and `flask sync-schools` first: these tests use the real schools.")
    yield flask_app
    with flask_app.app_context():
        db.session.execute(delete(UserAccount).where(UserAccount.email.like(f"%{EMAIL_DOMAIN}")))
        db.session.commit()


@pytest.fixture
def in_db(app):
    """Run a function inside an app context, for arranging or checking rows outside a request."""

    def run(work):
        with app.app_context():
            return work()

    return run


@pytest.fixture(scope="session")
def schools(app) -> list[SimpleNamespace]:
    """Every active real school in the API's order (by name), with what each test needs to pick one."""
    with app.app_context():
        subjects: dict[uuid.UUID, list[str]] = {}
        for school_id, subject_id in db.session.execute(select(SchoolSubject.school_id, SchoolSubject.subject_id)):
            subjects.setdefault(school_id, []).append(str(subject_id))
        ccas: dict[uuid.UUID, list[str]] = {}
        for school_id, cca_id in db.session.execute(select(SchoolCca.school_id, SchoolCca.cca_id)):
            ccas.setdefault(school_id, []).append(str(cca_id))
        rows = db.session.scalars(select(School).where(School.is_active).order_by(School.name)).all()
        return [
            SimpleNamespace(
                id=str(row.school_id),
                name=row.name,
                postal_code=row.postal_code,
                zone=row.zone,
                planning_area=row.planning_area,
                main_level=row.main_level,
                has_location=row.location is not None,
                subject_ids=subjects.get(row.school_id, []),
                cca_ids=ccas.get(row.school_id, []),
            )
            for row in rows
        ]


@pytest.fixture(scope="session")
def located_school(schools):
    return next(s for s in schools if s.has_location and s.postal_code)


@pytest.fixture
def anonymous(app) -> FlaskClient:
    return app.test_client()


@pytest.fixture
def new_user(app):
    """Factory: register and log in through the real endpoints."""

    def factory(**register_fields) -> ApiUser:
        client = app.test_client()
        email = register_fields.pop("email", None) or unique_email()
        payload = {"name": "API Test Parent", "email": email, "password": PASSWORD, **register_fields}
        registered = client.post("/api/auth/register", json=payload)
        assert registered.status_code == 201, registered.get_data(as_text=True)
        logged_in = client.post("/api/auth/login", json={"email": email, "password": PASSWORD})
        assert logged_in.status_code == 200, logged_in.get_data(as_text=True)
        client.environ_base["HTTP_X_CSRF_TOKEN"] = client.get_cookie("csrf_access_token").value
        return ApiUser(client, email, PASSWORD, logged_in.get_json()["user_id"])

    return factory


@pytest.fixture
def user(new_user) -> ApiUser:
    return new_user()


@pytest.fixture
def other_user(new_user) -> ApiUser:
    return new_user()


@pytest.fixture
def set_home(in_db):
    """Give a user a home location directly, so distance tests do not depend on geocoding."""

    def setter(account: ApiUser, coordinates: tuple[float, float] = HOME) -> None:
        def work():
            row = db.session.get(UserAccount, uuid.UUID(account.user_id))
            row.preferred_postal_code = "123456"
            row.home_location = WKTElement(f"POINT({coordinates[1]} {coordinates[0]})", srid=4326)
            db.session.commit()

        in_db(work)

    return setter


@pytest.fixture
def new_student():
    """Factory: create a student profile through the API and return its JSON."""

    def factory(owner: ApiUser, **fields) -> dict:
        payload = {"name": "Test Child", "current_level": "Primary", "current_year": 6, **fields}
        response = owner.client.post("/api/profiles", json=payload)
        assert response.status_code == 201, response.get_data(as_text=True)
        return response.get_json()

    return factory


@pytest.fixture
def student(user, new_student) -> dict:
    return new_student(user)


@pytest.fixture
def new_application():
    """Factory: create a Draft application through the API and return its JSON."""

    def factory(owner: ApiUser, student_row: dict, school, **fields) -> dict:
        payload = {"student_id": student_row["student_id"], "school_id": school.id, **fields}
        response = owner.client.post("/api/applications", json=payload)
        assert response.status_code == 201, response.get_data(as_text=True)
        return response.get_json()

    return factory


@pytest.fixture
def application(user, student, schools, new_application) -> dict:
    return new_application(user, student, schools[0])


@pytest.fixture
def fake_onemap(app, monkeypatch) -> FakeOneMap:
    """Replace OneMap for tests that need an outage or a no-result answer, which the real API cannot give on demand."""
    fake = FakeOneMap()
    monkeypatch.setattr(auth_routes.registration_controller, "onemap_gateway", fake)
    monkeypatch.setattr(school_routes.school_details_controller, "onemap_gateway", fake)
    for criterion in school_routes.school_comparison_controller.criteria:
        if isinstance(criterion, DistanceCriterion):
            monkeypatch.setattr(criterion, "onemap_gateway", fake)
    return fake


def _token_is_valid(token: str | None) -> bool:
    """True if the OneMap token is a JWT that has more than a minute left."""
    if not token:
        return False
    try:
        payload = token.split(".")[1]
        expiry = json.loads(base64.urlsafe_b64decode(payload + "=" * (-len(payload) % 4)))["exp"]
    except (IndexError, KeyError, TypeError, ValueError):
        return False
    return float(expiry) > time.time() + 60


@pytest.fixture
def live_onemap(app):
    """Skip unless the real OneMap API can be called with what app/.env provides."""
    can_renew = os.environ.get("ONEMAP_EMAIL") and os.environ.get("ONEMAP_PASSWORD")
    if not can_renew and not _token_is_valid(app.config.get("ONEMAP_API_TOKEN")):
        pytest.skip("OneMap token is missing or expired; renew ONEMAP_API_TOKEN or set ONEMAP_EMAIL/ONEMAP_PASSWORD.")
