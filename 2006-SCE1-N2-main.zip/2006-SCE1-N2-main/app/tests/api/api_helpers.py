"""Assertions and test doubles shared by the HTTP API tests."""
from app.errors import ExternalServiceError

HOME = (1.3521, 103.8198)  # central Singapore (latitude, longitude)
UNKNOWN_POSTAL_CODE = "999999"


def assert_error(response, status: int, code: str, field: str | None = None) -> dict:
    """Check the ARC-02 §4.2 error body and, when given, that `field` is named in its details.

    Schema failures nest fields under "json" or "query"; controller failures put them directly in details.
    """
    assert response.status_code == status, response.get_data(as_text=True)
    body = response.get_json()
    assert body["error"] == code, body
    assert isinstance(body["message"], str) and body["message"], body
    if field is not None:
        details = body["details"]
        named = {**details, **details.get("json", {}), **details.get("query", {})}
        assert field in named, body
    return body


class FakeOneMap:
    """Stands in for OneMapGateway when a test needs an outage or a no-result answer from OneMap."""

    ROUTE_TYPE = "drive"

    def __init__(self):
        self.fail = False
        self.no_route = False

    def _raise_if_down(self):
        if self.fail:
            raise ExternalServiceError("simulated OneMap outage")

    def geocode_postal_code(self, postal_code):
        self._raise_if_down()
        return None if postal_code == UNKNOWN_POSTAL_CODE else HOME

    def get_route_detail(self, start, end):
        self._raise_if_down()
        if self.no_route:
            return None
        return {"distance_m": 5_000.0, "duration_s": 600.0, "path": [list(start), list(end)]}

    def get_travel_route(self, start, end):
        self._raise_if_down()
        return None if self.no_route else (5_000.0, 600.0)
