"""/subjects, /ccas, /data-freshness and /schools, checked against the real synchronised data."""
from datetime import datetime

import pytest
from sqlalchemy import func, select

from api_helpers import HOME, assert_error
from app.control.school_data_sync_controller import MAIN_LEVEL_MAP
from app.extensions import db
from app.models import Cca, CcaCategory, EducationLevel, School, Subject

UNKNOWN = "00000000-0000-4000-8000-000000000003"
SUMMARY_FIELDS = {"school_id", "name", "type", "address", "zone", "planning_area", "distance_km"}
SEEDED_SUBJECTS = 21


def ids(response) -> list[str]:
    assert response.status_code == 200, response.get_data(as_text=True)
    return [school["school_id"] for school in response.get_json()]


class TestReferenceData:
    def test_subjects_match_the_database(self, user, in_db):
        response = user.client.get("/api/subjects")
        assert response.status_code == 200
        rows = response.get_json()
        assert len(rows) >= SEEDED_SUBJECTS
        assert len(rows) == in_db(lambda: db.session.scalar(select(func.count()).select_from(Subject)))
        assert set(rows[0]) == {"subject_id", "subject_name", "level", "is_special_programme"}
        assert {row["level"] for row in rows} <= {level.value for level in EducationLevel}

    def test_ccas_match_the_real_data(self, user, in_db):
        response = user.client.get("/api/ccas")
        assert response.status_code == 200
        rows = response.get_json()
        assert rows and len(rows) == in_db(lambda: db.session.scalar(select(func.count()).select_from(Cca)))
        assert set(rows[0]) == {"cca_id", "cca_name", "category"}
        assert {row["category"] for row in rows} <= {category.value for category in CcaCategory}

    def test_data_freshness_reports_the_real_sync(self, user):
        response = user.client.get("/api/data-freshness")
        assert response.status_code == 200
        assert datetime.fromisoformat(response.get_json()["last_successful_sync"])


class TestSearch:
    def test_no_filters_returns_every_active_school_by_name(self, user, schools):
        assert ids(user.client.get("/api/schools")) == [school.id for school in schools]

    def test_result_shape_without_home_has_no_distance(self, user):
        rows = user.client.get("/api/schools").get_json()
        assert set(rows[0]) == SUMMARY_FIELDS
        assert all(row["distance_km"] is None for row in rows)

    def test_home_gives_a_distance_for_located_schools(self, user, set_home, schools):
        set_home(user)
        rows = {row["school_id"]: row["distance_km"] for row in user.client.get("/api/schools").get_json()}
        for school in schools:
            if school.has_location:
                assert rows[school.id] is not None and 0 <= rows[school.id] < 60
            else:
                assert rows[school.id] is None

    def test_name_search_is_partial_and_ignores_case(self, user, schools):
        target = schools[len(schools) // 2]
        fragment = target.name.split()[0].lower()
        expected = [s.id for s in schools if fragment in s.name.lower()]
        assert target.id in expected
        assert ids(user.client.get("/api/schools", query_string={"q": fragment})) == expected

    def test_exact_real_name_finds_that_school(self, user, schools):
        assert schools[0].id in ids(user.client.get("/api/schools", query_string={"q": schools[0].name}))

    def test_no_match_is_an_empty_list(self, user):
        assert ids(user.client.get("/api/schools", query_string={"q": "zzz-no-such-school"})) == []

    def test_percent_sign_is_matched_literally(self, user, schools):
        expected = [s.id for s in schools if "%" in s.name]
        assert ids(user.client.get("/api/schools", query_string={"q": "%"})) == expected

    def test_query_of_150_characters_is_accepted(self, user):
        assert ids(user.client.get("/api/schools", query_string={"q": "x" * 150})) == []

    def test_query_of_151_characters_is_400(self, user):
        assert_error(user.client.get("/api/schools", query_string={"q": "x" * 151}), 400, "validation_failed", "q")

    @pytest.mark.parametrize("level", list(EducationLevel))
    def test_level_filter_matches_the_real_schools(self, user, schools, level):
        main_levels = {code for code, (_, levels) in MAIN_LEVEL_MAP.items() if level in levels}
        expected = [s.id for s in schools if s.main_level in main_levels]
        assert expected
        assert ids(user.client.get("/api/schools", query_string={"level": level.value})) == expected

    def test_invalid_level_is_400(self, user):
        assert_error(user.client.get("/api/schools", query_string={"level": "University"}), 400, "validation_failed", "level")

    @pytest.mark.parametrize("zone", ["North", "SOUTH", "east", "West"])
    def test_zone_filter_ignores_case(self, user, schools, zone):
        expected = [s.id for s in schools if s.zone == zone.upper()]
        assert expected
        assert ids(user.client.get("/api/schools", query_string={"zone": zone})) == expected

    def test_invalid_zone_is_400(self, user):
        assert_error(user.client.get("/api/schools", query_string={"zone": "Central"}), 400, "validation_failed", "zone")

    def test_planning_area_filter_ignores_case(self, user, schools):
        area = next(s.planning_area for s in schools if s.planning_area)
        expected = [s.id for s in schools if s.planning_area and s.planning_area.upper() == area.upper()]
        assert ids(user.client.get("/api/schools", query_string={"planning_area": area.lower()})) == expected

    def test_subject_filter_matches_the_real_offerings(self, user, schools):
        subject_id = next(s.subject_ids[0] for s in schools if s.subject_ids)
        expected = [s.id for s in schools if subject_id in s.subject_ids]
        assert ids(user.client.get("/api/schools", query_string={"subject_id": subject_id})) == expected

    def test_cca_filter_matches_the_real_offerings(self, user, schools):
        cca_id = next(s.cca_ids[0] for s in schools if s.cca_ids)
        expected = [s.id for s in schools if cca_id in s.cca_ids]
        assert ids(user.client.get("/api/schools", query_string={"cca_id": cca_id})) == expected

    @pytest.mark.parametrize("field", ["subject_id", "cca_id"])
    def test_unknown_id_filter_is_400(self, user, field):
        assert_error(user.client.get("/api/schools", query_string={field: UNKNOWN}), 400, "validation_failed", field)

    @pytest.mark.parametrize("field", ["subject_id", "cca_id"])
    def test_malformed_id_filter_is_400(self, user, field):
        assert_error(user.client.get("/api/schools", query_string={field: "not-a-uuid"}), 400, "validation_failed", field)

    def test_filters_combine(self, user, schools):
        main_levels = {code for code, (_, levels) in MAIN_LEVEL_MAP.items() if EducationLevel.Primary in levels}
        expected = [s.id for s in schools if s.zone == "NORTH" and s.main_level in main_levels]
        assert ids(user.client.get("/api/schools", query_string={"zone": "north", "level": "Primary"})) == expected


class TestDetails:
    def test_real_school_with_its_offerings(self, user, schools, in_db):
        school = next(s for s in schools if s.subject_ids and s.cca_ids)
        response = user.client.get(f"/api/schools/{school.id}")
        assert response.status_code == 200
        details = response.get_json()
        assert details["school_id"] == school.id and details["name"] == school.name
        assert {s["subject_id"] for s in details["subjects"]} == set(school.subject_ids)
        assert {c["cca_id"] for c in details["ccas"]} == set(school.cca_ids)
        assert isinstance(details["affiliations"], list)
        assert {"postal_code", "website", "telephone", "email", "description"} <= set(details)
        assert "distance_km" not in details

    def test_unknown_school_is_404(self, user):
        assert_error(user.client.get(f"/api/schools/{UNKNOWN}"), 404, "not_found")

    def test_malformed_id_is_404(self, user):
        assert_error(user.client.get("/api/schools/not-a-uuid"), 404, "not_found")


class TestRoute:
    def route(self, account, school):
        return account.client.get(f"/api/schools/{school.id}/route")

    def test_without_home_returns_only_the_school(self, user, located_school):
        response = self.route(user, located_school)
        assert response.status_code == 200
        body = response.get_json()
        assert body["home"] is None and body["note"] == "Home location not set"
        assert 1.1 < body["school"]["lat"] < 1.5 and 103.5 < body["school"]["lng"] < 104.1

    def test_with_home_returns_the_route(self, user, set_home, located_school, fake_onemap):
        set_home(user)
        body = self.route(user, located_school).get_json()
        assert body["home"]["lat"] == pytest.approx(HOME[0]) and body["home"]["lng"] == pytest.approx(HOME[1])
        assert body["distance_km"] == 5.0 and body["duration_min"] == 10.0 and body["path"] and body["note"] is None
        assert body["straight_line_km"] > 0 and body["route_type"] == "drive"

    def test_onemap_outage_keeps_the_straight_line(self, user, set_home, located_school, fake_onemap):
        fake_onemap.fail = True
        set_home(user)
        response = self.route(user, located_school)
        assert response.status_code == 200
        body = response.get_json()
        assert body["distance_km"] is None and body["straight_line_km"] > 0 and body["note"] == "OneMap route unavailable"

    def test_no_route_from_onemap(self, user, set_home, located_school, fake_onemap):
        fake_onemap.no_route = True
        set_home(user)
        body = self.route(user, located_school).get_json()
        assert body["distance_km"] is None and body["note"] == "OneMap found no route"

    def test_unknown_school_is_404(self, user):
        assert_error(user.client.get(f"/api/schools/{UNKNOWN}/route"), 404, "not_found")

    def test_school_without_a_location_is_404(self, user, schools):
        school = next((s for s in schools if not s.has_location), None)
        if school is None:
            pytest.skip("Every real school currently has a location.")
        assert_error(self.route(user, school), 404, "not_found")

    @pytest.mark.usefixtures("live_onemap")
    @pytest.mark.live_onemap
    def test_real_onemap_route(self, user, set_home, located_school):
        set_home(user)
        body = self.route(user, located_school).get_json()
        assert body["note"] is None, body
        assert body["distance_km"] > 0 and body["duration_min"] > 0 and len(body["path"]) > 1


class TestCompare:
    def compare(self, account, school_ids, **extra):
        return account.client.post("/api/schools/compare", json={"school_ids": school_ids, **extra})

    @pytest.mark.parametrize("count", [2, 3, 5])
    def test_keeps_the_chosen_order_with_one_cell_per_school(self, user, schools, count):
        chosen = [s.id for s in reversed(schools[:count])]
        response = self.compare(user, chosen)
        assert response.status_code == 200
        body = response.get_json()
        assert [s["school_id"] for s in body["schools"]] == chosen and body["personalised"] is False
        assert set(body["rows"]) == {"1", "2", "3", "4"}
        assert all(len(cells) == count for cells in body["rows"].values())

    @pytest.mark.parametrize("count", [0, 1, 6])
    def test_wrong_number_of_schools_is_400(self, user, schools, count):
        assert_error(self.compare(user, [s.id for s in schools[:count]]), 400, "validation_failed", "school_ids")

    def test_duplicate_schools_are_400(self, user, schools):
        assert_error(self.compare(user, [schools[0].id, schools[0].id]), 400, "validation_failed", "school_ids")

    def test_school_ids_are_required(self, user):
        assert_error(user.client.post("/api/schools/compare", json={}), 400, "validation_failed", "school_ids")

    def test_malformed_school_id_is_400(self, user, schools):
        assert_error(self.compare(user, [schools[0].id, "not-a-uuid"]), 400, "validation_failed", "school_ids")

    def test_unknown_school_is_404(self, user, schools):
        assert_error(self.compare(user, [schools[0].id, UNKNOWN]), 404, "not_found", "school_ids")

    def test_other_users_student_is_404(self, user, other_user, new_student, schools):
        theirs = new_student(other_user)
        assert_error(self.compare(user, [s.id for s in schools[:2]], student_id=theirs["student_id"]), 404, "not_found")

    def test_without_home_distance_is_not_available(self, user, schools):
        cell = self.compare(user, [s.id for s in schools[:2]]).get_json()["rows"]["1"][0]
        assert cell["available"] is False and cell["value"] is None and cell["note"] == "Home location not set"

    def test_with_home_uses_the_travel_route(self, user, set_home, schools, fake_onemap):
        set_home(user)
        located = [s.id for s in schools if s.has_location][:2]
        cell = self.compare(user, located).get_json()["rows"]["1"][0]
        assert cell["available"] is True and cell["value"]["distance_km"] == 5.0 and cell["value"]["travel_time_min"] == 10
        assert cell["value"]["method"] == "travel (drive)"

    def test_onemap_outage_falls_back_to_straight_line(self, user, set_home, schools, fake_onemap):
        fake_onemap.fail = True
        set_home(user)
        located = [s.id for s in schools if s.has_location][:2]
        response = self.compare(user, located)
        assert response.status_code == 200
        cell = response.get_json()["rows"]["1"][0]
        assert cell["value"]["method"] == "straight line" and cell["value"]["travel_time_min"] is None and cell["note"]

    def test_student_preferences_match_real_offerings(self, user, new_student, schools):
        with_data = [s for s in schools if s.subject_ids and s.cca_ids][:2]
        student = new_student(user, preferred_subject_ids=with_data[0].subject_ids[:1], preferred_cca_ids=with_data[0].cca_ids[:1])
        body = self.compare(user, [s.id for s in with_data], student_id=student["student_id"]).get_json()
        assert body["personalised"] is True
        assert body["rows"]["2"][0]["value"]["matched"] and body["rows"]["2"][0]["note"] is None
        assert body["rows"]["3"][0]["value"]["matched"] and body["rows"]["3"][0]["note"] is None

    def test_student_without_preferences_is_noted(self, user, student, schools):
        with_data = [s.id for s in schools if s.subject_ids][:2]
        body = self.compare(user, with_data, student_id=student["student_id"]).get_json()
        assert body["rows"]["2"][0]["value"]["matched"] == [] and body["rows"]["2"][0]["note"] == "Preferences not set"

    @pytest.mark.usefixtures("live_onemap")
    @pytest.mark.live_onemap
    def test_real_onemap_travel_distance(self, user, set_home, schools):
        set_home(user)
        located = [s.id for s in schools if s.has_location][:2]
        cell = self.compare(user, located).get_json()["rows"]["1"][0]
        assert cell["value"]["method"] == "travel (drive)", cell
        assert cell["value"]["distance_km"] > 0 and cell["value"]["travel_time_min"] > 0


def test_tests_did_not_change_the_real_schools(in_db, schools):
    """Guards the promise in conftest: the shared session list still equals the database."""
    assert in_db(lambda: db.session.scalar(select(func.count()).select_from(School).where(School.is_active))) == len(schools)
