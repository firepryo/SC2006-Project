"""/applications, its status state machine and its deadline, using real schools."""
import itertools

import pytest

from api_helpers import assert_error
from app.control.application_status_controller import singapore_today

UNKNOWN = "00000000-0000-4000-8000-000000000005"
FIELDS = {"application_id", "student_id", "school", "status", "date_submitted", "deadline", "notes", "updated_at"}
# The route that reaches each status from Draft.
PATHS = {
    "Draft": [],
    "Submitted": ["Submitted"],
    "UnderReview": ["Submitted", "UnderReview"],
    "Offered": ["Submitted", "UnderReview", "Offered"],
    "Rejected": ["Submitted", "UnderReview", "Rejected"],
    "Accepted": ["Submitted", "UnderReview", "Offered", "Accepted"],
}
ALLOWED = {
    ("Draft", "Submitted"),
    ("Submitted", "UnderReview"),
    ("UnderReview", "Offered"),
    ("UnderReview", "Rejected"),
    ("Offered", "Accepted"),
}
FORBIDDEN = sorted(set(itertools.product(PATHS, PATHS)) - ALLOWED)
ALLOWED_FROM = {status: sorted(to for frm, to in ALLOWED if frm == status) for status in PATHS}


def url(application) -> str:
    return f"/api/applications/{application['application_id']}"


def move(account, application, status):
    return account.client.patch(f"{url(application)}/status", json={"status": status})


def advance_to(account, application, status) -> None:
    for step in PATHS[status]:
        assert move(account, application, step).status_code == 200


class TestCreate:
    def test_new_application_is_a_draft_for_the_real_school(self, user, student, schools):
        response = user.client.post(
            "/api/applications", json={"student_id": student["student_id"], "school_id": schools[0].id, "notes": "Open house"}
        )
        assert response.status_code == 201
        body = response.get_json()
        assert set(body) == FIELDS and body["status"] == "Draft" and body["notes"] == "Open house"
        assert body["date_submitted"] is None and body["deadline"] is None
        assert body["school"]["school_id"] == schools[0].id and body["student_id"] == student["student_id"]

    def test_notes_are_optional(self, user, student, schools, new_application):
        assert new_application(user, student, schools[0])["notes"] is None

    def test_same_student_and_school_twice_is_409(self, user, student, schools, new_application):
        first = new_application(user, student, schools[0])
        response = user.client.post("/api/applications", json={"student_id": student["student_id"], "school_id": schools[0].id})
        body = assert_error(response, 409, "conflict", "application_id")
        assert body["details"]["application_id"] == first["application_id"]

    def test_another_student_can_apply_to_the_same_school(self, user, student, new_student, schools, new_application):
        new_application(user, student, schools[0])
        assert new_application(user, new_student(user), schools[0])["status"] == "Draft"

    def test_unknown_school_is_404(self, user, student):
        response = user.client.post("/api/applications", json={"student_id": student["student_id"], "school_id": UNKNOWN})
        assert_error(response, 404, "not_found")

    def test_other_users_student_is_404(self, other_user, student, schools):
        response = other_user.client.post("/api/applications", json={"student_id": student["student_id"], "school_id": schools[0].id})
        assert_error(response, 404, "not_found")

    @pytest.mark.parametrize("field", ["student_id", "school_id"])
    def test_required_field_missing_is_400(self, user, student, schools, field):
        data = {"student_id": student["student_id"], "school_id": schools[0].id}
        del data[field]
        assert_error(user.client.post("/api/applications", json=data), 400, "validation_failed", field)

    @pytest.mark.parametrize("field", ["student_id", "school_id"])
    def test_malformed_id_is_400(self, user, student, schools, field):
        data = {"student_id": student["student_id"], "school_id": schools[0].id, field: "not-a-uuid"}
        assert_error(user.client.post("/api/applications", json=data), 400, "validation_failed", field)


class TestRead:
    def test_list_contains_only_my_applications(self, user, other_user, student, new_student, schools, new_application):
        mine = new_application(user, student, schools[0])
        new_application(other_user, new_student(other_user), schools[1])
        response = user.client.get("/api/applications")
        assert response.status_code == 200
        assert [a["application_id"] for a in response.get_json()] == [mine["application_id"]]

    def test_list_filters_by_student(self, user, student, new_student, schools, new_application):
        mine = new_application(user, student, schools[0])
        new_application(user, new_student(user), schools[1])
        rows = user.client.get("/api/applications", query_string={"student_id": student["student_id"]}).get_json()
        assert [a["application_id"] for a in rows] == [mine["application_id"]]

    def test_list_is_most_recently_changed_first(self, user, student, schools, new_application):
        first, second = new_application(user, student, schools[0]), new_application(user, student, schools[1])
        user.client.patch(url(first), json={"notes": "touched"})
        rows = user.client.get("/api/applications").get_json()
        assert [a["application_id"] for a in rows] == [first["application_id"], second["application_id"]]

    def test_list_is_empty_for_a_new_account(self, user):
        assert user.client.get("/api/applications").get_json() == []

    def test_filter_by_other_users_student_is_404(self, other_user, student):
        response = other_user.client.get("/api/applications", query_string={"student_id": student["student_id"]})
        assert_error(response, 404, "not_found")

    def test_filter_with_malformed_id_is_400(self, user):
        response = user.client.get("/api/applications", query_string={"student_id": "not-a-uuid"})
        assert_error(response, 400, "validation_failed", "student_id")

    def test_get_one(self, user, application):
        response = user.client.get(url(application))
        assert response.status_code == 200 and response.get_json() == application

    def test_other_users_application_is_404(self, other_user, application):
        assert_error(other_user.client.get(url(application)), 404, "not_found")

    def test_unknown_application_is_404(self, user):
        assert_error(user.client.get(f"/api/applications/{UNKNOWN}"), 404, "not_found")

    def test_malformed_id_is_404(self, user):
        assert_error(user.client.get("/api/applications/not-a-uuid"), 404, "not_found")


class TestEditNotes:
    def test_sets_notes_and_updates_the_time(self, user, application):
        response = user.client.patch(url(application), json={"notes": "New notes"})
        assert response.status_code == 200
        body = response.get_json()
        assert body["notes"] == "New notes" and body["updated_at"] > application["updated_at"]

    def test_null_clears_notes(self, user, student, schools, new_application):
        created = new_application(user, student, schools[1], notes="Old")
        assert user.client.patch(url(created), json={"notes": None}).get_json()["notes"] is None

    def test_notes_field_is_required(self, user, application):
        assert_error(user.client.patch(url(application), json={}), 400, "validation_failed", "notes")

    def test_other_users_application_is_404(self, other_user, application):
        assert_error(other_user.client.patch(url(application), json={"notes": "x"}), 404, "not_found")

    def test_unknown_application_is_404(self, user):
        assert_error(user.client.patch(f"/api/applications/{UNKNOWN}", json={"notes": "x"}), 404, "not_found")


class TestStatus:
    @pytest.mark.parametrize("final", ["Accepted", "Rejected"])
    def test_full_path_to_each_final_status(self, user, application, final):
        for step in PATHS[final]:
            response = move(user, application, step)
            assert response.status_code == 200 and response.get_json()["status"] == step
        assert user.client.get(url(application)).get_json()["status"] == final

    def test_submitting_sets_todays_singapore_date(self, user, application):
        body = move(user, application, "Submitted").get_json()
        assert body["date_submitted"] == singapore_today().isoformat()

    def test_later_moves_keep_the_submitted_date(self, user, application):
        submitted = move(user, application, "Submitted").get_json()["date_submitted"]
        assert move(user, application, "UnderReview").get_json()["date_submitted"] == submitted

    @pytest.mark.parametrize("current, requested", FORBIDDEN)
    def test_forbidden_move_is_409_and_changes_nothing(self, user, application, current, requested):
        advance_to(user, application, current)
        body = assert_error(move(user, application, requested), 409, "conflict")
        assert body["details"] == {
            "current_status": current,
            "requested_status": requested,
            "allowed": ALLOWED_FROM[current],
        }
        assert user.client.get(url(application)).get_json()["status"] == current

    def test_invalid_status_is_400(self, user, application):
        assert_error(move(user, application, "Waitlisted"), 400, "validation_failed", "status")

    def test_status_is_required(self, user, application):
        assert_error(user.client.patch(f"{url(application)}/status", json={}), 400, "validation_failed", "status")

    def test_other_users_application_is_404(self, other_user, application):
        assert_error(move(other_user, application, "Submitted"), 404, "not_found")

    def test_unknown_application_is_404(self, user):
        assert_error(user.client.patch(f"/api/applications/{UNKNOWN}/status", json={"status": "Submitted"}), 404, "not_found")


class TestDeadline:
    def put(self, account, application, value):
        return account.client.put(f"{url(application)}/deadline", json={"deadline": value})

    def test_set_and_change(self, user, application):
        assert self.put(user, application, "2027-03-01").get_json()["deadline"] == "2027-03-01"
        assert self.put(user, application, "2027-04-15").get_json()["deadline"] == "2027-04-15"
        assert user.client.get(url(application)).get_json()["deadline"] == "2027-04-15"

    def test_past_date_is_accepted(self, user, application):
        response = self.put(user, application, "2020-01-01")
        assert response.status_code == 200 and response.get_json()["deadline"] == "2020-01-01"

    @pytest.mark.parametrize("value", ["2026-02-30", "not-a-date", "01/03/2027", ""])
    def test_invalid_date_is_400(self, user, application, value):
        assert_error(self.put(user, application, value), 400, "validation_failed", "deadline")

    def test_deadline_is_required(self, user, application):
        assert_error(user.client.put(f"{url(application)}/deadline", json={}), 400, "validation_failed", "deadline")

    def test_other_users_application_is_404(self, other_user, application):
        assert_error(self.put(other_user, application, "2027-03-01"), 404, "not_found")

    def test_unknown_application_is_404(self, user):
        response = user.client.put(f"/api/applications/{UNKNOWN}/deadline", json={"deadline": "2027-03-01"})
        assert_error(response, 404, "not_found")

    def test_clear(self, user, application):
        self.put(user, application, "2027-03-01")
        response = user.client.delete(f"{url(application)}/deadline")
        assert response.status_code == 200 and response.get_json()["deadline"] is None

    def test_clearing_when_none_is_set_is_fine(self, user, application):
        response = user.client.delete(f"{url(application)}/deadline")
        assert response.status_code == 200 and response.get_json()["deadline"] is None

    def test_clear_other_users_application_is_404(self, other_user, application):
        assert_error(other_user.client.delete(f"{url(application)}/deadline"), 404, "not_found")

    def test_clear_unknown_application_is_404(self, user):
        assert_error(user.client.delete(f"/api/applications/{UNKNOWN}/deadline"), 404, "not_found")
