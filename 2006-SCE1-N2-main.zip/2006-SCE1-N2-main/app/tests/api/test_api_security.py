"""The API as a whole: the 31 documented endpoints, login protection, CSRF, session cookie, error format."""
import uuid
from datetime import timedelta

import pytest
from flask_jwt_extended import create_access_token

from api_helpers import assert_error

ID = "00000000-0000-4000-8000-000000000001"
PUBLIC = [("POST", "/api/auth/register"), ("POST", "/api/auth/login")]
READS = [
    ("GET", "/api/auth/me"),
    ("GET", "/api/profiles"),
    ("GET", f"/api/profiles/{ID}"),
    ("GET", "/api/subjects"),
    ("GET", "/api/ccas"),
    ("GET", "/api/data-freshness"),
    ("GET", "/api/schools"),
    ("GET", f"/api/schools/{ID}"),
    ("GET", f"/api/schools/{ID}/route"),
    ("GET", f"/api/profiles/{ID}/shortlist"),
    ("GET", "/api/applications"),
    ("GET", f"/api/applications/{ID}"),
    ("GET", "/api/notifications"),
    ("GET", "/api/users/me/notification-preference"),
]
WRITES = [
    ("POST", "/api/auth/logout"),
    ("PATCH", "/api/users/me"),
    ("POST", "/api/profiles"),
    ("PUT", f"/api/profiles/{ID}"),
    ("DELETE", f"/api/profiles/{ID}"),
    ("POST", "/api/schools/compare"),
    ("POST", f"/api/profiles/{ID}/shortlist/entries"),
    ("DELETE", f"/api/profiles/{ID}/shortlist/entries/{ID}"),
    ("POST", "/api/applications"),
    ("PATCH", f"/api/applications/{ID}"),
    ("PATCH", f"/api/applications/{ID}/status"),
    ("PUT", f"/api/applications/{ID}/deadline"),
    ("DELETE", f"/api/applications/{ID}/deadline"),
    ("PATCH", f"/api/notifications/{ID}/read"),
    ("PUT", "/api/users/me/notification-preference"),
]
PROTECTED = READS + WRITES


def test_exactly_the_31_documented_endpoints_exist(app):
    registered = {
        (method, rule.rule)
        for rule in app.url_map.iter_rules()
        if rule.rule.startswith("/api/")
        for method in rule.methods - {"HEAD", "OPTIONS"}
    }
    assert len(registered) == 31 == len(PUBLIC) + len(PROTECTED)


@pytest.mark.parametrize("method, path", PROTECTED)
def test_protected_endpoint_without_login_is_401(anonymous, method, path):
    assert_error(anonymous.open(path, method=method, json={}), 401, "unauthorised")


@pytest.mark.parametrize("method, path", WRITES)
def test_write_without_csrf_header_is_401(user, method, path):
    user.client.environ_base.pop("HTTP_X_CSRF_TOKEN")
    assert_error(user.client.open(path, method=method, json={}), 401, "unauthorised")


def test_write_with_wrong_csrf_header_is_401(user):
    user.client.environ_base["HTTP_X_CSRF_TOKEN"] = "not-the-token"
    assert_error(user.client.post("/api/profiles", json={}), 401, "unauthorised")


def test_read_needs_no_csrf_header(user):
    user.client.environ_base.pop("HTTP_X_CSRF_TOKEN")
    assert user.client.get("/api/auth/me").status_code == 200


def test_tampered_cookie_is_401(app):
    client = app.test_client()
    client.set_cookie("access_token_cookie", "not.a.jwt")
    assert_error(client.get("/api/auth/me"), 401, "unauthorised")


def test_expired_session_is_401_session_expired(app, in_db, user):
    token = in_db(lambda: create_access_token(identity=user.user_id, expires_delta=timedelta(seconds=-1)))
    client = app.test_client()
    client.set_cookie("access_token_cookie", token)
    assert_error(client.get("/api/auth/me"), 401, "session_expired")


def test_login_cookie_is_http_only_and_same_site_lax(anonymous, new_user):
    account = new_user()
    response = anonymous.post("/api/auth/login", json={"email": account.email, "password": account.password})
    cookie = next(h for h in response.headers.getlist("Set-Cookie") if h.startswith("access_token_cookie="))
    assert "HttpOnly" in cookie and "SameSite=Lax" in cookie


def test_session_cookie_is_refreshed_and_csrf_value_kept(user):
    csrf_before = user.client.get_cookie("csrf_access_token").value
    response = user.client.get("/api/auth/me")
    assert any(h.startswith("access_token_cookie=") for h in response.headers.getlist("Set-Cookie"))
    assert user.client.get_cookie("csrf_access_token").value == csrf_before
    assert user.client.post("/api/profiles", json={"current_level": "Primary", "current_year": 1}).status_code == 201


def test_unknown_url_uses_the_error_format(anonymous):
    assert_error(anonymous.get(f"/api/{uuid.uuid4().hex}"), 404, "not_found")


def test_wrong_method_uses_the_error_format(anonymous):
    assert_error(anonymous.delete("/api/auth/login"), 405, "method_not_allowed")
