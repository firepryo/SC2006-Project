"""/profiles and /profiles/<student_id>, using the real subjects and CCAs."""
import uuid

import pytest
from sqlalchemy import select

from api_helpers import assert_error
from app.extensions import db
from app.models import Cca, Subject

UNKNOWN = "00000000-0000-4000-8000-000000000002"
FIELDS = {"student_id", "name", "current_level", "current_year", "preferred_subject_ids", "preferred_cca_ids"}


@pytest.fixture
def subject_ids(in_db):
    return in_db(lambda: [str(i) for i in db.session.scalars(select(Subject.subject_id).limit(2))])


@pytest.fixture
def cca_ids(in_db):
    return in_db(lambda: [str(i) for i in db.session.scalars(select(Cca.cca_id).limit(2))])


def body(**overrides) -> dict:
    return {"name": "Child", "current_level": "Primary", "current_year": 3, **overrides}


class TestCreate:
    def test_minimal_profile(self, user):
        response = user.client.post("/api/profiles", json={"current_level": "Secondary", "current_year": 2})
        assert response.status_code == 201
        created = response.get_json()
        assert set(created) == FIELDS and created["name"] is None
        assert created["preferred_subject_ids"] == [] and created["preferred_cca_ids"] == []

    def test_with_real_preferences(self, user, subject_ids, cca_ids):
        response = user.client.post(
            "/api/profiles", json=body(preferred_subject_ids=subject_ids, preferred_cca_ids=cca_ids)
        )
        assert response.status_code == 201
        created = response.get_json()
        assert set(created["preferred_subject_ids"]) == set(subject_ids)
        assert set(created["preferred_cca_ids"]) == set(cca_ids)

    @pytest.mark.parametrize(
        "level, year", [("Primary", 1), ("Primary", 6), ("Secondary", 1), ("Secondary", 5), ("JuniorCollege", 1), ("JuniorCollege", 2)]
    )
    def test_year_at_the_limits_is_accepted(self, user, level, year):
        assert user.client.post("/api/profiles", json=body(current_level=level, current_year=year)).status_code == 201

    @pytest.mark.parametrize(
        "level, year", [("Primary", 0), ("Primary", 7), ("Secondary", 0), ("Secondary", 6), ("JuniorCollege", 0), ("JuniorCollege", 3)]
    )
    def test_year_outside_the_limits_is_400(self, user, level, year):
        response = user.client.post("/api/profiles", json=body(current_level=level, current_year=year))
        assert_error(response, 400, "validation_failed", "current_year")

    @pytest.mark.parametrize("field", ["current_level", "current_year"])
    def test_required_field_missing_is_400(self, user, field):
        data = body()
        del data[field]
        assert_error(user.client.post("/api/profiles", json=data), 400, "validation_failed", field)

    @pytest.mark.parametrize(
        "field, value",
        [
            ("current_level", "University"),
            ("current_year", "three"),
            ("preferred_subject_ids", ["not-a-uuid"]),
            ("preferred_cca_ids", ["not-a-uuid"]),
            ("preferred_subject_ids", [UNKNOWN]),
            ("preferred_cca_ids", [UNKNOWN]),
            ("name", "x" * 101),
        ],
    )
    def test_invalid_field_is_400(self, user, field, value):
        assert_error(user.client.post("/api/profiles", json=body(**{field: value})), 400, "validation_failed", field)

    def test_name_of_100_characters_is_accepted(self, user):
        assert user.client.post("/api/profiles", json=body(name="x" * 100)).status_code == 201


class TestRead:
    def test_list_is_oldest_first_and_only_mine(self, user, other_user, new_student):
        first, second = new_student(user, name="First"), new_student(user, name="Second")
        new_student(other_user, name="Theirs")
        response = user.client.get("/api/profiles")
        assert response.status_code == 200
        assert [p["student_id"] for p in response.get_json()] == [first["student_id"], second["student_id"]]

    def test_list_is_empty_for_a_new_account(self, user):
        assert user.client.get("/api/profiles").get_json() == []

    def test_get_one(self, user, student):
        response = user.client.get(f"/api/profiles/{student['student_id']}")
        assert response.status_code == 200 and response.get_json() == student

    def test_other_users_profile_is_404(self, other_user, student):
        assert_error(other_user.client.get(f"/api/profiles/{student['student_id']}"), 404, "not_found")

    def test_unknown_profile_is_404(self, user):
        assert_error(user.client.get(f"/api/profiles/{UNKNOWN}"), 404, "not_found")

    def test_malformed_id_is_404(self, user):
        assert_error(user.client.get("/api/profiles/not-a-uuid"), 404, "not_found")


class TestEdit:
    def test_replaces_fields_and_preferences(self, user, new_student, subject_ids, cca_ids):
        created = new_student(user, preferred_subject_ids=subject_ids[:1], preferred_cca_ids=cca_ids[:1])
        response = user.client.put(
            f"/api/profiles/{created['student_id']}",
            json={"name": "Renamed", "current_level": "Secondary", "current_year": 4, "preferred_subject_ids": subject_ids[1:]},
        )
        assert response.status_code == 200
        edited = response.get_json()
        assert edited["name"] == "Renamed" and edited["current_level"] == "Secondary" and edited["current_year"] == 4
        assert edited["preferred_subject_ids"] == subject_ids[1:] and edited["preferred_cca_ids"] == []

    def test_invalid_year_is_400_and_changes_nothing(self, user, student):
        path = f"/api/profiles/{student['student_id']}"
        assert_error(user.client.put(path, json=body(current_year=7)), 400, "validation_failed", "current_year")
        assert user.client.get(path).get_json() == student

    def test_other_users_profile_is_404(self, other_user, student):
        assert_error(other_user.client.put(f"/api/profiles/{student['student_id']}", json=body()), 404, "not_found")

    def test_unknown_profile_is_404(self, user):
        assert_error(user.client.put(f"/api/profiles/{UNKNOWN}", json=body()), 404, "not_found")


class TestRemove:
    def test_removes_the_profile(self, user, student):
        path = f"/api/profiles/{student['student_id']}"
        response = user.client.delete(path)
        assert response.status_code == 204 and response.get_data() == b""
        assert_error(user.client.get(path), 404, "not_found")

    def test_other_users_profile_is_404_and_is_kept(self, user, other_user, student):
        path = f"/api/profiles/{student['student_id']}"
        assert_error(other_user.client.delete(path), 404, "not_found")
        assert user.client.get(path).status_code == 200

    def test_unknown_profile_is_404(self, user):
        assert_error(user.client.delete(f"/api/profiles/{uuid.uuid4()}"), 404, "not_found")

    def test_profile_with_shortlisted_school_is_409_until_removed(self, user, student, schools):
        path = f"/api/profiles/{student['student_id']}"
        entry = user.client.post(f"{path}/shortlist/entries", json={"school_id": schools[0].id}).get_json()
        body_409 = assert_error(user.client.delete(path), 409, "conflict", "shortlist_entries")
        assert body_409["details"]["shortlist_entries"] is True
        assert user.client.delete(f"{path}/shortlist/entries/{entry['entry_id']}").status_code == 204
        assert user.client.delete(path).status_code == 204

    def test_profile_with_application_is_409(self, user, student, application):
        body_409 = assert_error(user.client.delete(f"/api/profiles/{student['student_id']}"), 409, "conflict", "applications")
        assert body_409["details"]["applications"] is True
