"""Person B tests: school search and details (F7), comparison (F8), shortlist (F9), reference routes (F6).

Run from the repository root, against a local database that has had one school sync:
    .venv/Scripts/python -m pytest app/tests/test_person_b_schools.py -v

Each test creates its own user and student profile and deletes them afterwards. OneMap is replaced by a
fake gateway so distances are predictable. HTTP error codes (400/404/409) need Person A's
register_error_handlers (F3), so error cases are checked on the controllers.
"""
import uuid

import pytest
from flask_jwt_extended import create_access_token, get_csrf_token
from geoalchemy2.elements import WKTElement
from sqlalchemy import delete, func, select

from app.app import create_app
from app.control import SchoolComparisonController, SchoolDetailsController, SchoolSearchController, ShortlistController
from app.control.comparison_criteria import (
    AffiliationCriterion,
    CcaMatchCriterion,
    DistanceCriterion,
    SubjectMatchCriterion,
)
from app.control.school_search_controller import SearchCriteria
from app.errors import ConflictError, ExternalServiceError, NotFoundError, ValidationError
from app.extensions import db
from app.models import (
    Cca,
    School,
    StudentPreferredCca,
    StudentPreferredSubject,
    StudentProfile,
    Subject,
    UserAccount,
)
from app.models.enums import EducationLevel, SchoolType

HOME = (1.3521, 103.8198)  # central Singapore (latitude, longitude)


class FakeOneMap:
    """Stands in for OneMapGateway: a fixed 12.3 km / 25 min route, or an outage."""

    def __init__(self, fail: bool = False):
        self.fail = fail
        self.calls = 0

    def get_travel_route(self, start, end):
        self.calls += 1
        if self.fail:
            raise ExternalServiceError("simulated OneMap outage")
        return 12_300.0, 1_500.0


def comparison_controller(gateway) -> SchoolComparisonController:
    return SchoolComparisonController(
        criteria=[DistanceCriterion(gateway), SubjectMatchCriterion(), CcaMatchCriterion(), AffiliationCriterion()]
    )


# ---------------------------------------------------------------- fixtures


@pytest.fixture(scope="module")
def app():
    flask_app = create_app()
    flask_app.config["TESTING"] = True
    with flask_app.app_context():
        if db.session.scalar(select(func.count()).select_from(School)) < 300:
            pytest.skip("Run the school sync first: the tests use the real school data.")
        yield flask_app


def _make_user(with_home: bool = True) -> UserAccount:
    user = UserAccount(
        name="Person B test",
        email=f"person-b-{uuid.uuid4().hex[:12]}@test.local",
        password_hash="not-a-real-hash",
        preferred_postal_code="569933" if with_home else None,
        home_location=WKTElement(f"POINT({HOME[1]} {HOME[0]})", srid=4326) if with_home else None,
    )
    db.session.add(user)
    db.session.commit()
    return user


@pytest.fixture
def user(app):
    created = []

    def factory(with_home: bool = True) -> UserAccount:
        created.append(_make_user(with_home))
        return created[-1]

    yield factory
    # Deleting the user cascades to profiles, preferences, shortlists and entries (DATA-01 §3.5).
    db.session.rollback()
    db.session.execute(delete(UserAccount).where(UserAccount.user_id.in_([u.user_id for u in created])))
    db.session.commit()


@pytest.fixture
def profile(user):
    def factory(owner: UserAccount | None = None) -> StudentProfile:
        owner = owner or user()
        student = StudentProfile(user_id=owner.user_id, name="Test child", current_level=EducationLevel.Primary, current_year=6)
        db.session.add(student)
        db.session.commit()
        return student

    return factory


def _client(app, account: UserAccount):
    """A test client logged in as `account`, sending the CSRF header that cookie JWTs require."""
    token = create_access_token(identity=str(account.user_id))
    client = app.test_client()
    client.set_cookie("access_token_cookie", token)
    client.environ_base["HTTP_X_CSRF_TOKEN"] = get_csrf_token(token)
    return client


def _school(name: str) -> School:
    return db.session.scalar(select(School).where(School.name == name))


def _subject(name: str, level: EducationLevel) -> Subject:
    return db.session.scalar(select(Subject).where(Subject.subject_name == name, Subject.level == level))


# ---------------------------------------------------------------- F7 search (UC04, UC05)


class TestSearch:
    def test_name_search_is_case_insensitive_and_partial(self, app):
        results = SchoolSearchController().search_schools(SearchCriteria(q="raffles"))
        assert results and all("RAFFLES" in s.name for s in results)
        assert [s.name for s in results] == sorted(s.name for s in results)

    def test_no_criteria_returns_every_active_school(self, app):
        active = db.session.scalar(select(func.count()).select_from(School).where(School.is_active))
        assert len(SchoolSearchController().search_schools(SearchCriteria())) == active

    def test_no_match_returns_empty_list(self, app):
        assert SchoolSearchController().search_schools(SearchCriteria(q="zzz no such school")) == []

    def test_like_wildcards_are_literal(self, app):
        assert SchoolSearchController().search_schools(SearchCriteria(q="%")) == []

    def test_level_filter_includes_mixed_level_schools(self, app):
        results = SchoolSearchController().search_schools(SearchCriteria(level=EducationLevel.JuniorCollege))
        types = {s.type for s in results}
        assert SchoolType.JuniorCollege in types and SchoolType.MixedLevels in types
        assert SchoolType.Primary not in types

    def test_zone_filter_any_case(self, app):
        results = SchoolSearchController().search_schools(SearchCriteria(zone="north"))
        assert results and {s.zone for s in results} == {"NORTH"}

    def test_planning_area_filter(self, app):
        results = SchoolSearchController().search_schools(SearchCriteria(planning_area="ang mo kio"))
        assert results and {s.planning_area for s in results} == {"ANG MO KIO"}

    def test_subject_filter(self, app):
        sap = _subject("Special Assistance Plan (SAP)", EducationLevel.Primary)
        results = SchoolSearchController().search_schools(SearchCriteria(subject_id=sap.subject_id))
        assert len(results) == 15  # data.gov.sg dataset, 2026-11-06

    def test_cca_filter(self, app):
        cca = db.session.scalar(select(Cca).where(Cca.cca_name == "CHOIR"))
        results = SchoolSearchController().search_schools(SearchCriteria(cca_id=cca.cca_id))
        assert len(results) > 50

    def test_combined_filters(self, app):
        results = SchoolSearchController().search_schools(
            SearchCriteria(q="primary", zone="EAST", level=EducationLevel.Primary)
        )
        assert results and all(s.zone == "EAST" and "PRIMARY" in s.name for s in results)

    @pytest.mark.parametrize(
        "criteria, field",
        [
            (SearchCriteria(zone="CENTRAL"), "zone"),
            (SearchCriteria(subject_id=uuid.uuid4()), "subject_id"),
            (SearchCriteria(cca_id=uuid.uuid4()), "cca_id"),
            (SearchCriteria(q="x" * 151), "q"),
        ],
    )
    def test_invalid_filters_raise_validation_error(self, app, criteria, field):
        with pytest.raises(ValidationError) as error:
            SchoolSearchController().search_schools(criteria)
        assert field in error.value.details

    def test_http_search(self, app, user):
        response = _client(app, user()).get("/api/schools?q=raffles&level=JuniorCollege")
        assert response.status_code == 200
        body = response.get_json()
        assert body and set(body[0]) == {"school_id", "name", "type", "address", "zone", "planning_area", "distance_km"}
        assert all(isinstance(s["distance_km"], float) for s in body)  # this user has a home location

    def test_http_requires_login(self, app):
        assert app.test_client().get("/api/schools").status_code == 401


# ---------------------------------------------------------------- F7 details (UC06)


class TestDetails:
    def test_details_include_subjects_and_ccas(self, app):
        school = _school("ADMIRALTY PRIMARY SCHOOL")
        details = SchoolDetailsController().retrieve_school_details(school.school_id)
        assert details.school.name == "ADMIRALTY PRIMARY SCHOOL"
        assert any(s.subject_name == "Chinese Language" for s in details.subjects)
        assert any(c.cca_name == "CHOIR" for c in details.ccas)
        assert details.affiliations == []  # no affiliation source yet

    def test_unknown_school_raises_not_found(self, app):
        with pytest.raises(NotFoundError):
            SchoolDetailsController().retrieve_school_details(uuid.uuid4())

    def test_inactive_school_raises_not_found(self, app):
        school = _school("ADMIRALTY PRIMARY SCHOOL")
        school.is_active = False
        db.session.flush()
        try:
            with pytest.raises(NotFoundError):
                SchoolDetailsController().retrieve_school_details(school.school_id)
        finally:
            db.session.rollback()

    def test_http_details(self, app, user):
        school = _school("RAFFLES INSTITUTION")
        response = _client(app, user()).get(f"/api/schools/{school.school_id}")
        assert response.status_code == 200
        body = response.get_json()
        assert body["name"] == "RAFFLES INSTITUTION" and body["postal_code"]
        assert {"Integrated Programme", "Gifted Education Programme"} <= {s["subject_name"] for s in body["subjects"]}
        assert body["ccas"] and body["affiliations"] == []


# ---------------------------------------------------------------- F8 comparison (UC07, UC07a–d)


class TestComparison:
    @pytest.fixture
    def two_schools(self, app):
        return [_school("RAFFLES INSTITUTION").school_id, _school("ADMIRALTY PRIMARY SCHOOL").school_id]

    @pytest.mark.parametrize("count", [0, 1, 6])
    def test_selection_must_be_2_to_5(self, app, user, count):
        ids = list(db.session.scalars(select(School.school_id).limit(count)))
        with pytest.raises(ValidationError):
            comparison_controller(FakeOneMap()).compare_schools(user().user_id, ids)

    def test_duplicates_rejected(self, app, user, two_schools):
        with pytest.raises(ValidationError):
            comparison_controller(FakeOneMap()).compare_schools(user().user_id, [two_schools[0], two_schools[0]])

    def test_unknown_school_not_found(self, app, user, two_schools):
        with pytest.raises(NotFoundError):
            comparison_controller(FakeOneMap()).compare_schools(user().user_id, [two_schools[0], uuid.uuid4()])

    def test_other_users_profile_not_found(self, app, user, profile, two_schools):
        someone_elses = profile()
        with pytest.raises(NotFoundError):
            comparison_controller(FakeOneMap()).compare_schools(
                user().user_id, two_schools, student_id=someone_elses.student_id
            )

    def test_non_personalised_comparison(self, app, user, two_schools):
        gateway = FakeOneMap()
        result = comparison_controller(gateway).compare_schools(user().user_id, two_schools)
        assert not result.personalised
        assert [s.school_id for s in result.schools] == two_schools  # column order kept
        assert set(result.rows) == {1, 2, 3, 4} and all(len(cells) == 2 for cells in result.rows.values())

        distance = result.rows[1][0]
        assert distance.available and distance.value["distance_km"] == 12.3 and distance.value["travel_time_min"] == 25
        assert gateway.calls == 2
        assert result.rows[2][0].note == "Preferences not set"
        assert result.rows[3][0].note == "Preferences not set"
        assert not result.rows[4][0].available and result.rows[4][0].note == "Affiliation data not available"

    def test_personalised_matches(self, app, user, profile, two_schools):
        owner = user()
        student = profile(owner)
        ip = _subject("Integrated Programme", EducationLevel.Secondary)
        choir = db.session.scalar(select(Cca).where(Cca.cca_name == "CHOIR"))
        db.session.add_all(
            [
                StudentPreferredSubject(student_id=student.student_id, subject_id=ip.subject_id),
                StudentPreferredCca(student_id=student.student_id, cca_id=choir.cca_id),
            ]
        )
        db.session.commit()

        result = comparison_controller(FakeOneMap()).compare_schools(
            owner.user_id, two_schools, student_id=student.student_id
        )
        assert result.personalised
        raffles_subjects, admiralty_subjects = result.rows[2]
        assert raffles_subjects.value["matched"] == ["Integrated Programme"] and raffles_subjects.note is None
        assert admiralty_subjects.value["matched"] == [] and admiralty_subjects.note == "No preference match"
        assert "CHOIR" in result.rows[3][1].value["matched"]  # Admiralty Primary has a choir

    def test_distance_falls_back_to_straight_line(self, app, user, two_schools):
        result = comparison_controller(FakeOneMap(fail=True)).compare_schools(user().user_id, two_schools)
        cell = result.rows[1][0]
        assert cell.available and cell.value["method"] == "straight line" and cell.value["distance_km"] > 0
        assert cell.note.startswith("Straight-line")

    def test_distance_unavailable_without_home_location(self, app, user, two_schools):
        result = comparison_controller(FakeOneMap()).compare_schools(user(with_home=False).user_id, two_schools)
        assert all(not cell.available and cell.note == "Home location not set" for cell in result.rows[1])

    def test_http_compare(self, app, user, two_schools, monkeypatch):
        from app.boundary import school_routes

        monkeypatch.setattr(school_routes, "school_comparison_controller", comparison_controller(FakeOneMap()))
        response = _client(app, user()).post(
            "/api/schools/compare", json={"school_ids": [str(i) for i in two_schools]}
        )
        assert response.status_code == 200
        body = response.get_json()
        assert len(body["schools"]) == 2 and set(body["rows"]) == {"1", "2", "3", "4"}
        assert body["rows"]["1"][0]["value"]["distance_km"] == 12.3


# ---------------------------------------------------------------- F9 shortlist (UC08)


class TestShortlist:
    def test_add_view_remove(self, app, user, profile):
        owner = user()
        student = profile(owner)
        controller = ShortlistController()
        school = _school("RAFFLES INSTITUTION")

        assert controller.get_shortlist(owner.user_id, student.student_id).entries == []
        entry = controller.add_school_to_shortlist(owner.user_id, student.student_id, school.school_id)
        shortlist = controller.get_shortlist(owner.user_id, student.student_id)
        assert [e.school.name for e in shortlist.entries] == ["RAFFLES INSTITUTION"]

        controller.remove_school_from_shortlist(owner.user_id, student.student_id, entry.entry_id)
        assert controller.get_shortlist(owner.user_id, student.student_id).entries == []

    def test_duplicate_is_conflict(self, app, user, profile):
        owner = user()
        student = profile(owner)
        school = _school("RAFFLES INSTITUTION")
        controller = ShortlistController()
        controller.add_school_to_shortlist(owner.user_id, student.student_id, school.school_id)
        with pytest.raises(ConflictError):
            controller.add_school_to_shortlist(owner.user_id, student.student_id, school.school_id)

    def test_unknown_school_not_found(self, app, user, profile):
        owner = user()
        student = profile(owner)
        with pytest.raises(NotFoundError):
            ShortlistController().add_school_to_shortlist(owner.user_id, student.student_id, uuid.uuid4())

    def test_other_users_profile_not_found(self, app, user, profile):
        stranger = user()
        student = profile()  # belongs to another user
        with pytest.raises(NotFoundError):
            ShortlistController().get_shortlist(stranger.user_id, student.student_id)

    def test_remove_unknown_entry_not_found(self, app, user, profile):
        owner = user()
        student = profile(owner)
        with pytest.raises(NotFoundError):
            ShortlistController().remove_school_from_shortlist(owner.user_id, student.student_id, uuid.uuid4())

    def test_http_shortlist_flow(self, app, user, profile):
        owner = user()
        student = profile(owner)
        client = _client(app, owner)
        school = _school("ADMIRALTY PRIMARY SCHOOL")
        base = f"/api/profiles/{student.student_id}/shortlist"

        added = client.post(f"{base}/entries", json={"school_id": str(school.school_id)})
        assert added.status_code == 201
        assert added.get_json()["school"]["name"] == "ADMIRALTY PRIMARY SCHOOL"

        listed = client.get(base)
        assert listed.status_code == 200 and len(listed.get_json()["entries"]) == 1

        removed = client.delete(f"{base}/entries/{added.get_json()['entry_id']}")
        assert removed.status_code == 204
        assert client.get(base).get_json()["entries"] == []


# ---------------------------------------------------------------- F6 reference routes


class TestReference:
    def test_subjects_ccas_and_freshness(self, app, user):
        client = _client(app, user())
        # The 21 seeded data.gov.sg subjects, plus any the MOE SchoolFinder supplement added.
        assert len(client.get("/api/subjects").get_json()) >= 21
        assert len(client.get("/api/ccas").get_json()) > 100
        assert client.get("/api/data-freshness").get_json()["last_successful_sync"] is not None
