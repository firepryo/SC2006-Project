"""Person A tests: deadline reminders and notifications (F11: UC11, ARC-02 §3.7.4).

Run from the repository root, against a local database that has had `flask db upgrade` and one school sync:
    python -m pytest app/tests/test_person_a_reminders.py -v

check_deadlines() scans every application in the database, so these tests pass a "today" in 2031: only the
deadlines the tests set themselves fall inside that window. Users are deleted afterwards (cascades to
profiles, applications and reminders).
"""
import uuid
from datetime import date, timedelta

import pytest
from flask_jwt_extended import create_access_token, get_csrf_token
from sqlalchemy import delete, func, select

from app.app import create_app
from app.control import ApplicationController, ReminderController
from app.extensions import db
from app.models import Application, DeadlineReminder, School, StudentProfile, UserAccount
from app.models.enums import EducationLevel

TODAY = date(2031, 6, 2)  # far from any real deadline, see the module docstring


@pytest.fixture(scope="module")
def app():
    flask_app = create_app()
    flask_app.config["TESTING"] = True
    with flask_app.app_context():
        if db.session.scalar(select(func.count()).select_from(School)) < 2:
            pytest.skip("Run `flask db upgrade` and `flask sync-schools` first: the tests use real school rows.")
        yield flask_app


@pytest.fixture
def user(app):
    created = []

    def factory(opt_in: bool = True) -> UserAccount:
        account = UserAccount(
            name="Person A test",
            email=f"person-a-{uuid.uuid4().hex[:12]}@test.local",
            password_hash="not-a-real-hash",
            notification_opt_in=opt_in,
        )
        db.session.add(account)
        db.session.commit()
        created.append(account)
        return account

    yield factory
    db.session.rollback()
    db.session.execute(delete(UserAccount).where(UserAccount.user_id.in_([u.user_id for u in created])))
    db.session.commit()


@pytest.fixture
def make_application(user, app):
    schools = list(db.session.scalars(select(School).where(School.is_active).order_by(School.name).limit(5)))
    counter = {"next": 0}

    def factory(owner: UserAccount | None = None, deadline: date | None = None) -> Application:
        owner = owner or user()
        student = StudentProfile(user_id=owner.user_id, name="Test child", current_level=EducationLevel.Primary, current_year=6)
        db.session.add(student)
        db.session.commit()
        school = schools[counter["next"] % len(schools)]
        counter["next"] += 1
        application = ApplicationController().create_application(owner.user_id, student.student_id, school.school_id)
        if deadline is not None:
            application.deadline = deadline
            db.session.commit()
        return application

    return factory


def _reminders(application: Application) -> list[date]:
    return sorted(db.session.scalars(
        select(DeadlineReminder.remind_for_deadline).where(DeadlineReminder.application_id == application.application_id)
    ))


def _client(app, account: UserAccount):
    token = create_access_token(identity=str(account.user_id))
    client = app.test_client()
    client.set_cookie("access_token_cookie", token)
    client.environ_base["HTTP_X_CSRF_TOKEN"] = get_csrf_token(token)
    return client


class TestCheckDeadlines:
    def test_window_is_today_to_today_plus_7(self, make_application):
        inside = {offset: make_application(deadline=TODAY + timedelta(days=offset)) for offset in (0, 3, 7)}
        outside = {offset: make_application(deadline=TODAY + timedelta(days=offset)) for offset in (-1, 8)}
        no_deadline = make_application()

        assert ReminderController().check_deadlines(TODAY) == 3
        for application in inside.values():
            assert _reminders(application) == [application.deadline]
        for application in [*outside.values(), no_deadline]:
            assert _reminders(application) == []

    def test_second_run_creates_nothing(self, make_application):
        application = make_application(deadline=TODAY + timedelta(days=2))
        controller = ReminderController()
        assert controller.check_deadlines(TODAY) == 1
        assert controller.check_deadlines(TODAY) == 0
        assert controller.check_deadlines(TODAY + timedelta(days=1)) == 0  # next day, same deadline
        assert _reminders(application) == [application.deadline]

    def test_opted_out_user_gets_nothing(self, user, make_application):
        application = make_application(owner=user(opt_in=False), deadline=TODAY + timedelta(days=1))
        assert ReminderController().check_deadlines(TODAY) == 0
        assert _reminders(application) == []

    def test_changed_deadline_is_reminded_again(self, make_application):
        application = make_application(deadline=TODAY + timedelta(days=5))
        controller = ReminderController()
        controller.check_deadlines(TODAY)
        application.deadline = TODAY + timedelta(days=6)
        db.session.commit()
        assert controller.check_deadlines(TODAY) == 1
        assert _reminders(application) == [TODAY + timedelta(days=5), TODAY + timedelta(days=6)]

    def test_one_failure_does_not_stop_the_others(self, make_application, monkeypatch):
        broken = make_application(deadline=TODAY + timedelta(days=1))
        fine = make_application(deadline=TODAY + timedelta(days=2))
        controller = ReminderController()
        real_generate = controller.generate_reminder

        def flaky(application):
            if application.application_id == broken.application_id:
                raise RuntimeError("simulated failure")
            return real_generate(application)

        monkeypatch.setattr(controller, "generate_reminder", flaky)
        assert controller.check_deadlines(TODAY) == 1
        assert _reminders(broken) == [] and _reminders(fine) == [fine.deadline]
        monkeypatch.undo()
        assert ReminderController().check_deadlines(TODAY) == 1  # retried on the next run (UC11 alt flow 2)
        assert _reminders(broken) == [broken.deadline]

    def test_cli_command(self, app, make_application):
        make_application(deadline=date.today() + timedelta(days=1))
        result = app.test_cli_runner().invoke(args=["check-deadlines"])
        assert result.exit_code == 0 and "reminders created" in result.output


class TestNotifications:
    def test_list_own_newest_first(self, user, make_application):
        owner = user()
        first = make_application(owner=owner, deadline=TODAY + timedelta(days=1))
        controller = ReminderController()
        controller.check_deadlines(TODAY)
        second = make_application(owner=owner, deadline=TODAY + timedelta(days=4))
        controller.check_deadlines(TODAY)
        make_application(deadline=TODAY + timedelta(days=2))  # someone else's
        controller.check_deadlines(TODAY)

        listed = controller.list_notifications(owner.user_id)
        assert [r.application_id for r in listed] == [second.application_id, first.application_id]

    def test_http_list(self, app, user, make_application):
        owner = user()
        application = make_application(owner=owner, deadline=TODAY + timedelta(days=3))
        ReminderController().check_deadlines(TODAY)
        response = _client(app, owner).get("/api/notifications")
        assert response.status_code == 200
        [item] = response.get_json()
        assert item["application_id"] == str(application.application_id)
        assert item["remind_for_deadline"] == application.deadline.isoformat()
        assert item["is_read"] is False  # a new reminder starts unread

    def test_http_empty_and_login_required(self, app, user):
        assert _client(app, user()).get("/api/notifications").get_json() == []
        response = app.test_client().get("/api/notifications")
        assert response.status_code == 401 and response.get_json()["error"] == "unauthorised"


class TestMarkAsRead:
    def _reminder_for(self, owner, make_application) -> DeadlineReminder:
        application = make_application(owner=owner, deadline=TODAY + timedelta(days=2))
        ReminderController().check_deadlines(TODAY)
        return db.session.scalar(select(DeadlineReminder).where(DeadlineReminder.application_id == application.application_id))

    def test_controller_marks_once_and_is_idempotent(self, user, make_application):
        owner = user()
        reminder = self._reminder_for(owner, make_application)
        assert reminder.is_read is False
        controller = ReminderController()
        assert controller.mark_as_read(owner.user_id, reminder.reminder_id).is_read is True
        assert controller.mark_as_read(owner.user_id, reminder.reminder_id).is_read is True
        db.session.expire_all()
        assert db.session.get(DeadlineReminder, reminder.reminder_id).is_read is True

    def test_http_mark_then_list_shows_read(self, app, user, make_application):
        owner = user()
        reminder = self._reminder_for(owner, make_application)
        client = _client(app, owner)
        response = client.patch(f"/api/notifications/{reminder.reminder_id}/read")
        assert response.status_code == 200
        body = response.get_json()
        assert body["reminder_id"] == str(reminder.reminder_id) and body["is_read"] is True
        [item] = client.get("/api/notifications").get_json()
        assert item["is_read"] is True

    def test_http_other_users_reminder_is_404(self, app, user, make_application):
        reminder = self._reminder_for(user(), make_application)
        response = _client(app, user()).patch(f"/api/notifications/{reminder.reminder_id}/read")
        assert response.status_code == 404 and response.get_json()["error"] == "not_found"
        db.session.expire_all()
        assert db.session.get(DeadlineReminder, reminder.reminder_id).is_read is False

    def test_http_unknown_id_404_and_login_required(self, app, user):
        assert _client(app, user()).patch(f"/api/notifications/{uuid.uuid4()}/read").status_code == 404
        assert _client(app, user()).patch("/api/notifications/not-a-uuid/read").status_code == 404
        assert app.test_client().patch(f"/api/notifications/{uuid.uuid4()}/read").status_code == 401
