"""Tests: accounts (F4), student profiles (F5), distance + OneMap route, MOE SchoolFinder supplement.

Run from the repository root, against a local database that has had one school sync:
    .venv/Scripts/python -m pytest app/tests/test_accounts_route_supplement.py -v

OneMap and SchoolFinder are replaced by fakes; every row a test creates is deleted afterwards.
"""
import json
import uuid

import pytest
from flask_jwt_extended import create_access_token, get_csrf_token
from sqlalchemy import delete, func, select

import app.boundary.auth_routes as auth_routes
import app.boundary.school_routes as school_routes
from app.app import create_app
from app.control import SchoolDataSyncController
from app.control.school_data_sync_controller import MOE_SCHOOL_FINDER_DATASET
from app.errors import ExternalServiceError
from app.extensions import db
from app.gateway.moe_school_finder_gateway import MoeSchool, parse_school_finder_page
from app.models import School, SchoolSubject, SchoolSyncLog, Subject, UserAccount
from app.models.enums import EducationLevel, SyncStatus

EMAIL_DOMAIN = "@accounts-test.local"
HOME = (1.3521, 103.8198)
PASSWORD = "CorrectHorse1"


class FakeOneMap:
    """Geocodes 123456 to HOME, anything else to nothing; routes are a fixed 5 km / 10 min line."""

    ROUTE_TYPE = "drive"

    def __init__(self, fail_route: bool = False):
        self.fail_route = fail_route

    def geocode_postal_code(self, postal_code):
        return HOME if postal_code == "123456" else None

    def get_route_detail(self, start, end):
        if self.fail_route:
            raise ExternalServiceError("simulated OneMap outage")
        return {"distance_m": 5_000.0, "duration_s": 600.0, "path": [list(start), list(end)]}


@pytest.fixture(scope="module")
def app():
    flask_app = create_app()
    flask_app.config["TESTING"] = True
    with flask_app.app_context():
        if db.session.scalar(select(func.count()).select_from(School)) < 300:
            pytest.skip("Run the school sync first: the tests use the real school data.")
        yield flask_app
        db.session.rollback()
        db.session.execute(delete(UserAccount).where(UserAccount.email.like(f"%{EMAIL_DOMAIN}")))
        db.session.commit()


@pytest.fixture(autouse=True)
def fake_onemap(app, monkeypatch):
    fake = FakeOneMap()
    monkeypatch.setattr(auth_routes.registration_controller, "onemap_gateway", fake)
    monkeypatch.setattr(school_routes.school_details_controller, "onemap_gateway", fake)
    return fake


def _email() -> str:
    return f"user-{uuid.uuid4().hex[:10]}{EMAIL_DOMAIN}"


def _register(client, email=None, postal="123456", password=PASSWORD):
    return client.post(
        "/api/auth/register",
        json={"name": "Test Parent", "email": email or _email(), "password": password, "preferred_postal_code": postal},
    )


def _logged_in(app, email=None, postal="123456"):
    """Register and log in through the real endpoints; returns a client carrying the cookie and CSRF header."""
    client = app.test_client()
    email = email or _email()
    assert _register(client, email, postal).status_code == 201
    response = client.post("/api/auth/login", json={"email": email, "password": PASSWORD})
    assert response.status_code == 200
    token = client.get_cookie("access_token_cookie").value
    client.environ_base["HTTP_X_CSRF_TOKEN"] = get_csrf_token(token)
    return client


# ---------------------------------------------------------------- F4 accounts


class TestAccounts:
    def test_register_geocodes_home_and_hides_secrets(self, app):
        email = _email()
        response = _register(app.test_client(), email)
        assert response.status_code == 201
        body = response.get_json()
        assert body["preferred_postal_code"] == "123456" and "password" not in body and "password_hash" not in body
        account = db.session.scalar(select(UserAccount).where(UserAccount.email == email))
        assert account.home_location is not None and account.password_hash != PASSWORD

    def test_register_unknown_postal_code_still_succeeds(self, app):
        email = _email()
        assert _register(app.test_client(), email, postal="999999").status_code == 201
        assert db.session.scalar(select(UserAccount.home_location).where(UserAccount.email == email)) is None

    def test_duplicate_email_is_case_insensitive(self, app):
        email = _email()
        client = app.test_client()
        assert _register(client, email).status_code == 201
        response = _register(client, email.upper())
        assert response.status_code == 409 and response.get_json()["error"] == "conflict"

    def test_invalid_fields(self, app):
        response = _register(app.test_client(), postal="12ab", password="short")
        assert response.status_code == 400
        assert {"password", "preferred_postal_code"} <= set(response.get_json()["details"])

    def test_login_me_logout(self, app):
        client = _logged_in(app)
        assert client.get("/api/auth/me").status_code == 200
        assert client.post("/api/auth/logout").status_code == 204
        assert client.get_cookie("access_token_cookie") is None
        assert client.get("/api/auth/me").status_code == 401

    def test_wrong_password_then_lockout(self, app):
        email = _email()
        client = app.test_client()
        _register(client, email)
        for _ in range(4):
            assert client.post("/api/auth/login", json={"email": email, "password": "wrong-pass"}).status_code == 401
        assert client.post("/api/auth/login", json={"email": email, "password": "wrong-pass"}).status_code == 423
        # Locked: even the right password is refused.
        response = client.post("/api/auth/login", json={"email": email, "password": PASSWORD})
        assert response.status_code == 423 and response.get_json()["details"]["remaining_seconds"] > 0

    def test_update_and_clear_home_location(self, app):
        client = _logged_in(app, postal="")
        assert client.patch("/api/users/me", json={"preferred_postal_code": "999999"}).status_code == 400
        assert client.patch("/api/users/me", json={"preferred_postal_code": "123456"}).get_json()[
            "preferred_postal_code"
        ] == "123456"
        assert client.patch("/api/users/me", json={"preferred_postal_code": ""}).get_json()[
            "preferred_postal_code"
        ] is None

    def test_notification_preference(self, app):
        client = _logged_in(app)
        assert client.get("/api/users/me/notification-preference").get_json() == {"notification_opt_in": True}
        response = client.put("/api/users/me/notification-preference", json={"notification_opt_in": False})
        assert response.get_json() == {"notification_opt_in": False}


# ---------------------------------------------------------------- F5 profiles


class TestProfiles:
    def test_create_edit_list_remove(self, app):
        client = _logged_in(app)
        subject = db.session.scalar(select(Subject).limit(1))
        created = client.post(
            "/api/profiles",
            json={"name": "Ethan", "current_level": "Primary", "current_year": 6,
                  "preferred_subject_ids": [str(subject.subject_id)]},
        )
        assert created.status_code == 201
        student_id = created.get_json()["student_id"]
        assert created.get_json()["preferred_subject_ids"] == [str(subject.subject_id)]
        assert client.get(f"/api/profiles/{student_id}/shortlist").status_code == 200  # created with the profile

        edited = client.put(f"/api/profiles/{student_id}", json={"name": "Ethan T", "current_level": "Secondary", "current_year": 1})
        assert edited.status_code == 200 and edited.get_json()["preferred_subject_ids"] == []
        assert [p["name"] for p in client.get("/api/profiles").get_json()] == ["Ethan T"]
        assert client.delete(f"/api/profiles/{student_id}").status_code == 204
        assert client.get(f"/api/profiles/{student_id}").status_code == 404

    def test_validation(self, app):
        client = _logged_in(app)
        response = client.post("/api/profiles", json={"current_level": "JuniorCollege", "current_year": 3})
        assert response.status_code == 400 and "current_year" in response.get_json()["details"]
        response = client.post(
            "/api/profiles", json={"current_level": "Primary", "current_year": 1, "preferred_cca_ids": [str(uuid.uuid4())]}
        )
        assert response.status_code == 400 and "preferred_cca_ids" in response.get_json()["details"]

    def test_cannot_remove_with_shortlisted_school(self, app):
        client = _logged_in(app)
        student_id = client.post("/api/profiles", json={"current_level": "Primary", "current_year": 5}).get_json()["student_id"]
        school_id = db.session.scalar(select(School.school_id).limit(1))
        assert client.post(f"/api/profiles/{student_id}/shortlist/entries", json={"school_id": str(school_id)}).status_code == 201
        assert client.delete(f"/api/profiles/{student_id}").status_code == 409

    def test_other_users_profile_is_not_found(self, app):
        owner = _logged_in(app)
        student_id = owner.post("/api/profiles", json={"current_level": "Primary", "current_year": 2}).get_json()["student_id"]
        assert _logged_in(app).get(f"/api/profiles/{student_id}").status_code == 404


# ---------------------------------------------------------------- distance and OneMap route


class TestDistanceAndRoute:
    def test_search_distance_only_with_home(self, app):
        with_home = _logged_in(app).get("/api/schools?q=raffles").get_json()
        without_home = _logged_in(app, postal="").get("/api/schools?q=raffles").get_json()
        assert with_home and all(0 < s["distance_km"] < 60 for s in with_home)
        assert without_home and all(s["distance_km"] is None for s in without_home)

    def test_route_with_home(self, app):
        school_id = db.session.scalar(select(School.school_id).where(School.location.is_not(None)).limit(1))
        body = _logged_in(app).get(f"/api/schools/{school_id}/route").get_json()
        assert body["home"] == {"lat": HOME[0], "lng": HOME[1]}
        assert body["distance_km"] == 5.0 and body["duration_min"] == 10.0 and len(body["path"]) == 2
        assert body["straight_line_km"] > 0 and body["note"] is None

    def test_route_without_home(self, app):
        school_id = db.session.scalar(select(School.school_id).where(School.location.is_not(None)).limit(1))
        body = _logged_in(app, postal="").get(f"/api/schools/{school_id}/route").get_json()
        assert body["home"] is None and body["distance_km"] is None and body["school"]["lat"]
        assert body["note"] == "Home location not set"

    def test_route_onemap_outage_keeps_straight_line(self, app, fake_onemap):
        fake_onemap.fail_route = True
        school_id = db.session.scalar(select(School.school_id).where(School.location.is_not(None)).limit(1))
        body = _logged_in(app).get(f"/api/schools/{school_id}/route").get_json()
        assert body["distance_km"] is None and body["straight_line_km"] > 0
        assert body["note"] == "OneMap route unavailable"


# ---------------------------------------------------------------- MOE SchoolFinder supplement


def _finder_page(schools: list[dict]) -> str:
    """A SchoolFinder-like page: the schools array inside an escaped Next.js push string."""
    payload = '5:["$","div",null,{"journey":[],"schools":' + json.dumps(schools) + "}]"
    return f'<script>self.__next_f.push([1,{json.dumps(payload)}])</script>'


def test_parse_school_finder_page():
    html = _finder_page([
        {"school_name": "Alpha Secondary School", "school_telephone_no": "61234567", "school_website_url": "https://a.sg",
         "subjects": [{"moe_school_subject_id": {"subject_description": "Physics"}},
                      {"moe_school_subject_id": {"subject_description": "Physics"}},
                      {"moe_school_subject_id": {"subject_description": "Chemistry"}}]},
        {"school_name": "Beta Secondary School", "subjects": []},
    ])
    schools = parse_school_finder_page(html)
    assert [s.name for s in schools] == ["Alpha Secondary School", "Beta Secondary School"]
    assert schools[0].subjects == {"Physics", "Chemistry"} and schools[0].telephone == "61234567"


def test_parse_school_finder_page_rejects_unknown_layout():
    with pytest.raises(ExternalServiceError):
        parse_school_finder_page("<html>no payload</html>")


class FakeFinder:
    def __init__(self, schools_by_level=None, fail=False):
        self.schools_by_level = schools_by_level or {}
        self.fail = fail

    def fetch_schools(self, level):
        if self.fail:
            raise ExternalServiceError("simulated SchoolFinder outage")
        return self.schools_by_level.get(level, [])


@pytest.fixture
def secondary_school(app):
    school = db.session.scalar(select(School).where(School.main_level == "SECONDARY (S1-S4)").limit(1))
    saved = (school.website, school.telephone)
    yield school
    db.session.rollback()
    school.website, school.telephone = saved
    db.session.execute(delete(Subject).where(Subject.subject_name.like("Test Subject %")))
    db.session.execute(delete(SchoolSyncLog).where(SchoolSyncLog.dataset == MOE_SCHOOL_FINDER_DATASET,
                                                   SchoolSyncLog.started_at > func.now() - func.make_interval(0, 0, 0, 0, 0, 5)))
    db.session.commit()


def _links(school_id):
    return set(db.session.scalars(select(SchoolSubject.subject_id).where(SchoolSubject.school_id == school_id)))


class TestSupplement:
    def test_adds_subjects_and_fills_only_empty_contacts(self, app, secondary_school):
        before = _links(secondary_school.school_id)
        original_phone = secondary_school.telephone
        secondary_school.website = None
        db.session.commit()
        name = f"Test Subject {uuid.uuid4().hex[:8]}"
        finder = FakeFinder({EducationLevel.Secondary: [MoeSchool(
            name=secondary_school.name.title(), subjects={name, name.upper(), "Chinese Language"},
            telephone="69999999", website="https://filled.example",
        )]})
        log = SchoolDataSyncController(school_finder_gateway=finder).supplement_from_school_finder()

        assert log.status == SyncStatus.Success
        after = _links(secondary_school.school_id)
        assert before <= after  # nothing from data.gov.sg was removed
        added = db.session.scalars(select(Subject).where(Subject.subject_id.in_(after - before))).all()
        # Case variants merged into one row; the data.gov.sg-owned "Chinese Language" skipped.
        assert [s.subject_name.casefold() for s in added] == [name.casefold()]
        assert added[0].level == EducationLevel.Secondary
        assert secondary_school.website == "https://filled.example"  # was empty: filled
        assert secondary_school.telephone == original_phone  # had a value: never overwritten

    def test_wrong_level_or_unknown_school_is_not_matched(self, app, secondary_school):
        before = _links(secondary_school.school_id)
        finder = FakeFinder({EducationLevel.Primary: [
            MoeSchool(name=secondary_school.name, subjects={f"Test Subject {uuid.uuid4().hex[:8]}"}),
            MoeSchool(name="Nowhere Imaginary School", subjects={"Art"}),
        ]})
        log = SchoolDataSyncController(school_finder_gateway=finder).supplement_from_school_finder()
        assert log.status == SyncStatus.Partial and "Nowhere Imaginary School" in log.error_message
        assert _links(secondary_school.school_id) == before

    def test_outage_changes_nothing(self, app, secondary_school):
        before = _links(secondary_school.school_id)
        log = SchoolDataSyncController(school_finder_gateway=FakeFinder(fail=True)).supplement_from_school_finder()
        assert log.status == SyncStatus.Failed and "outage" in log.error_message
        assert _links(secondary_school.school_id) == before
