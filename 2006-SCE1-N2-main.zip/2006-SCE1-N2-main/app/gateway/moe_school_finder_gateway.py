"""MOE SchoolFinder gateway: subjects (and contact details) that the data.gov.sg datasets lack.

Supplement only (user decision 2026-11-07): data.gov.sg stays the main source. This gateway reads the
public SchoolFinder listing pages, which embed every school of that level, with its subjects, in the
Next.js payload (`self.__next_f.push([1, "..."])` strings). Nothing is written here; the sync decides.
"""
import json
import re
from dataclasses import dataclass, field

import requests

from app.errors import ExternalServiceError
from app.models.enums import EducationLevel

BASE_URL = "https://www.moe.gov.sg/schoolfinder/"
# Listing page per level. Mixed-level schools appear on each page they teach at.
LEVEL_PAGES: dict[EducationLevel, str] = {
    EducationLevel.Primary: "Primary%20school",
    EducationLevel.Secondary: "secondary%20school",
    EducationLevel.JuniorCollege: "Post%20secondary-JC%20school",
}
_PUSH_PATTERN = re.compile(r'self\.__next_f\.push\(\[1,"((?:[^"\\]|\\.)*)"\]\)')
_SCHOOLS_KEY = '"schools":['


@dataclass
class MoeSchool:
    """One school as SchoolFinder lists it."""

    name: str
    subjects: set[str] = field(default_factory=set)
    telephone: str | None = None
    email: str | None = None
    website: str | None = None


def _text(value) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def parse_school_finder_page(html: str) -> list[MoeSchool]:
    """Pull the schools array out of one SchoolFinder listing page.

    Inputs: the page HTML.
    Output: one MoeSchool per listed school (subjects deduplicated by description).
    Errors: ExternalServiceError when the page no longer has the expected structure.
    """
    try:
        payload = "".join(json.loads(f'"{chunk}"') for chunk in _PUSH_PATTERN.findall(html))
    except ValueError as exc:
        raise ExternalServiceError("MOE SchoolFinder page payload could not be decoded.") from exc

    # The page can hold more than one "schools" array (e.g. navigation); the listing is the largest.
    decoder = json.JSONDecoder()
    candidates: list[list] = []
    start = payload.find(_SCHOOLS_KEY)
    while start >= 0:
        try:
            value, _ = decoder.raw_decode(payload, start + len(_SCHOOLS_KEY) - 1)
            if isinstance(value, list):
                candidates.append(value)
        except ValueError:
            pass
        start = payload.find(_SCHOOLS_KEY, start + 1)
    listing = max(candidates, key=len, default=[])
    if not listing or not all(isinstance(item, dict) and "school_name" in item for item in listing):
        raise ExternalServiceError("MOE SchoolFinder page no longer lists schools in the expected format.")

    schools = []
    for item in listing:
        name = _text(item.get("school_name"))
        if not name:
            continue
        subjects = set()
        for link in item.get("subjects") or []:
            subject = link.get("moe_school_subject_id") if isinstance(link, dict) else None
            description = _text(subject.get("subject_description")) if isinstance(subject, dict) else None
            if description:
                subjects.add(description[:150])  # subject.subject_name is varchar(150)
        schools.append(
            MoeSchool(
                name=name,
                subjects=subjects,
                telephone=_text(item.get("school_telephone_no") or item.get("school_telephone_number")),
                email=_text(item.get("school_email_address") or item.get("school_email")),
                website=_text(item.get("school_website_url")),
            )
        )
    return schools


class MoeSchoolFinderGateway:
    """Fetches the SchoolFinder listing pages."""

    def __init__(self, timeout_seconds: float = 60.0):
        self.timeout_seconds = timeout_seconds

    def fetch_schools(self, level: EducationLevel) -> list[MoeSchool]:
        """All schools SchoolFinder lists for one level.

        Errors: ExternalServiceError if the page is unreachable or its structure changed.
        """
        url = BASE_URL + LEVEL_PAGES[level]
        try:
            response = requests.get(
                url, headers={"User-Agent": "Mozilla/5.0 (school-comparison sync)"}, timeout=self.timeout_seconds
            )
        except requests.RequestException as exc:
            raise ExternalServiceError(f"MOE SchoolFinder unreachable: {exc}") from exc
        if not response.ok:
            raise ExternalServiceError(f"MOE SchoolFinder returned HTTP {response.status_code} for {url}.")
        return parse_school_finder_page(response.text)
