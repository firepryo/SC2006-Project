"""Class diagram: ExternalSchoolDataGateway «boundary». Reads the MOE datasets on data.gov.sg (UC12, ARC-02 §3.7.5)."""
import time
from collections.abc import Iterator

import requests
from flask import current_app, has_app_context

from app.errors import ExternalServiceError

SCHOOL_GENERAL_INFO_DATASET = "d_688b934f82c1059ed0a6993d2a829089"  # DATA-01 §3.8, ADR-001
SCHOOL_CCA_DATASET = "d_9aba12b5527843afb0b2e8e4ed6ac6bd"  # ADR-006: CCA names and categories per school


class ExternalSchoolDataGateway:
    """Wraps the data.gov.sg `datastore_search` API; returns plain dict records, page by page."""

    BASE_URL = "https://data.gov.sg/api/action/datastore_search"
    PAGE_SIZE = 1000
    MAX_ATTEMPTS = 4  # first try + 3 retries
    RETRY_STATUSES = {429, 500, 502, 503, 504}

    def __init__(self, api_key: str | None = None, timeout_seconds: float = 10.0):
        self.api_key = api_key
        self.timeout_seconds = timeout_seconds

    def request_school_data(self, dataset_id: str) -> Iterator[list[dict]]:
        """Class diagram: requestSchoolData(). Yield every page of one dataset.

        Inputs: data.gov.sg resource id.
        Output: an iterator of pages, each a list of raw record dicts.
        Errors: ExternalServiceError on timeout, non-2xx status or a malformed body (FR 12.5).
        """
        offset = 0
        while True:
            body = self._get_page(dataset_id, offset)
            records = self._receive_school_data(body)
            if not records:
                return
            yield records
            offset += len(records)
            total = body["result"].get("total")
            if total is not None and offset >= total:
                return

    def fetch_all(self, dataset_id: str) -> list[dict]:
        """Every record of one dataset in a single list. Fails as a whole if any page fails (UC12 alt flow 1)."""
        return [record for page in self.request_school_data(dataset_id) for record in page]

    def _receive_school_data(self, response_body: dict) -> list[dict]:
        """Class diagram: receiveSchoolData(data). Extract `result.records` from one response.

        Inputs: parsed JSON body.
        Output: list of record dicts.
        Errors: ExternalServiceError if `success` is false or `result.records` is missing.
        """
        if not isinstance(response_body, dict) or response_body.get("success") is not True:
            raise ExternalServiceError("data.gov.sg reported an unsuccessful request.")
        records = (response_body.get("result") or {}).get("records")
        if not isinstance(records, list):
            raise ExternalServiceError("data.gov.sg response has no result.records list.")
        return records

    def _get_page(self, dataset_id: str, offset: int) -> dict:
        """One GET with retry and backoff on rate limits, server errors and network errors."""
        params = {"resource_id": dataset_id, "limit": self.PAGE_SIZE, "offset": offset}
        headers = {"x-api-key": key} if (key := self._api_key()) else {}
        last_error = "no attempt made"
        for attempt in range(1, self.MAX_ATTEMPTS + 1):
            try:
                response = requests.get(self.BASE_URL, params=params, headers=headers, timeout=self.timeout_seconds)
            except requests.RequestException as exc:
                last_error = f"network error: {exc}"
            else:
                if response.ok:
                    try:
                        return response.json()
                    except ValueError as exc:
                        raise ExternalServiceError("data.gov.sg returned a body that is not JSON.") from exc
                if response.status_code not in self.RETRY_STATUSES:
                    raise ExternalServiceError(f"data.gov.sg returned HTTP {response.status_code}.")
                last_error = f"HTTP {response.status_code}"
                retry_after = response.headers.get("Retry-After")
                if retry_after and retry_after.isdigit() and attempt < self.MAX_ATTEMPTS:
                    time.sleep(min(int(retry_after), 60))
                    continue
            if attempt < self.MAX_ATTEMPTS:
                time.sleep(5 * 2 ** (attempt - 1))  # 5 s, 10 s, 20 s
        raise ExternalServiceError(
            f"data.gov.sg unavailable after {self.MAX_ATTEMPTS} attempts ({last_error}).",
            {"dataset": dataset_id, "offset": offset},
        )

    def _api_key(self) -> str | None:
        """The key given to the constructor, else DATA_GOV_SG_API_KEY from the app config (optional)."""
        if self.api_key:
            return self.api_key
        return current_app.config.get("DATA_GOV_SG_API_KEY") if has_app_context() else None
