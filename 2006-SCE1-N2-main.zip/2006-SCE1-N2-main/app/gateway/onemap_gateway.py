"""OneMap gateway: postal code to coordinates (ADR-003, UC01, UC07a, UC12) and travel routes (UC07a)."""
import os
import time

import requests
from flask import current_app, has_app_context

from app.errors import ExternalServiceError


def decode_polyline(encoded: str, precision: int = 5) -> list[list[float]]:
    """Decode an encoded polyline (the format of OneMap's route_geometry) into [[lat, lng], ...]."""
    points, index, lat, lng, factor = [], 0, 0, 0, 10**precision
    while index < len(encoded):
        deltas = []
        for _ in range(2):
            shift = result = 0
            while True:
                if index >= len(encoded):
                    return points  # truncated input: keep what decoded cleanly
                byte = ord(encoded[index]) - 63
                index += 1
                result |= (byte & 0x1F) << shift
                shift += 5
                if byte < 0x20:
                    break
            deltas.append(~(result >> 1) if result & 1 else result >> 1)
        lat += deltas[0]
        lng += deltas[1]
        points.append([lat / factor, lng / factor])
    return points


class OneMapGateway:
    """Wraps the OneMap Search, Routing and Authentication APIs."""

    BASE_URL = "https://www.onemap.gov.sg/api/common/elastic/search"
    ROUTE_URL = "https://www.onemap.gov.sg/api/public/routingsvc/route"
    TOKEN_URL = "https://www.onemap.gov.sg/api/auth/post/getToken"
    ROUTE_TYPE = "drive"  # road distance; OneMap also offers walk, cycle and pt (public transport)

    # A token renewed with ONEMAP_EMAIL / ONEMAP_PASSWORD, shared by every instance (tokens last 3 days).
    _renewed_token: str | None = None
    _renewed_token_expiry: float = 0.0

    def __init__(self, api_token: str | None = None, timeout_seconds: float = 10.0):
        self.api_token = api_token
        self.timeout_seconds = timeout_seconds

    def geocode_postal_code(self, postal_code: str) -> tuple[float, float] | None:
        """Look up one Singapore postal code.

        Inputs: postal code; left-padded to six digits before the call (ADR-003).
        Output: (latitude, longitude), or None when OneMap finds no match.
        Errors: ExternalServiceError on timeout or non-2xx status.
        """
        postal = str(postal_code).strip().zfill(6)
        params = {"searchVal": postal, "returnGeom": "Y", "getAddrDetails": "Y", "pageNum": 1}
        headers = {"Authorization": token} if (token := self._api_token()) else {}
        try:
            response = requests.get(self.BASE_URL, params=params, headers=headers, timeout=self.timeout_seconds)
        except requests.RequestException as exc:
            raise ExternalServiceError(f"OneMap unreachable: {exc}") from exc
        if not response.ok:
            raise ExternalServiceError(f"OneMap returned HTTP {response.status_code}.")
        try:
            results = response.json().get("results") or []
        except ValueError as exc:
            raise ExternalServiceError("OneMap returned a body that is not JSON.") from exc

        # Prefer a result at exactly this postal code; a search value can also match street names.
        exact = [r for r in results if str(r.get("POSTAL", "")).strip() == postal]
        for result in exact or results:
            try:
                return float(result["LATITUDE"]), float(result["LONGITUDE"])
            except (KeyError, TypeError, ValueError):
                continue
        return None

    def get_travel_route(
        self, start: tuple[float, float], end: tuple[float, float]
    ) -> tuple[float, float] | None:
        """Travel route between two points (UC07a, user decision 2026-11-06: OneMap travel distance).

        Inputs: (latitude, longitude) of start and end.
        Output: (distance in metres, travel time in seconds), or None when OneMap finds no route.
        Errors: ExternalServiceError when OneMap is unreachable, rejects the token, or returns an error status.
        """
        params = {
            "start": f"{start[0]},{start[1]}",
            "end": f"{end[0]},{end[1]}",
            "routeType": self.ROUTE_TYPE,
        }
        response = self._get_with_token(self.ROUTE_URL, params)
        try:
            body = response.json()
        except ValueError as exc:
            raise ExternalServiceError("OneMap returned a body that is not JSON.") from exc
        summary = body.get("route_summary") or {}
        try:
            return float(summary["total_distance"]), float(summary["total_time"])
        except (KeyError, TypeError, ValueError):
            return None

    def get_route_detail(self, start: tuple[float, float], end: tuple[float, float]) -> dict | None:
        """Travel route with its path, for drawing on the map (school details "Getting there").

        Inputs: (latitude, longitude) of start and end.
        Output: {"distance_m", "duration_s", "path": [[lat, lng], ...]}, or None when OneMap finds no route.
        Errors: ExternalServiceError when OneMap is unreachable, rejects the token, or returns an error status.
        """
        params = {"start": f"{start[0]},{start[1]}", "end": f"{end[0]},{end[1]}", "routeType": self.ROUTE_TYPE}
        response = self._get_with_token(self.ROUTE_URL, params)
        try:
            body = response.json()
        except ValueError as exc:
            raise ExternalServiceError("OneMap returned a body that is not JSON.") from exc
        summary = body.get("route_summary") or {}
        try:
            distance_m, duration_s = float(summary["total_distance"]), float(summary["total_time"])
        except (KeyError, TypeError, ValueError):
            return None
        geometry = body.get("route_geometry")
        return {
            "distance_m": distance_m,
            "duration_s": duration_s,
            "path": decode_polyline(geometry) if isinstance(geometry, str) else [],
        }

    def _get_with_token(self, url: str, params: dict) -> requests.Response:
        """GET with the Authorization token; on 401, renew the token once (if credentials are set) and retry."""
        token = self._api_token()
        for attempt in (1, 2):
            if not token:
                raise ExternalServiceError("No OneMap token; set ONEMAP_API_TOKEN or ONEMAP_EMAIL/ONEMAP_PASSWORD.")
            try:
                response = requests.get(
                    url, params=params, headers={"Authorization": token}, timeout=self.timeout_seconds
                )
            except requests.RequestException as exc:
                raise ExternalServiceError(f"OneMap unreachable: {exc}") from exc
            if response.status_code == 401 and attempt == 1:
                token = self._renew_token()
                continue
            if not response.ok:
                raise ExternalServiceError(f"OneMap returned HTTP {response.status_code}.")
            return response
        raise ExternalServiceError("OneMap rejected the token (expired?). Renew ONEMAP_API_TOKEN.")

    def _api_token(self) -> str | None:
        """Constructor token, else a still-valid renewed token, else ONEMAP_API_TOKEN from the config."""
        if self.api_token:
            return self.api_token
        if OneMapGateway._renewed_token and time.time() < OneMapGateway._renewed_token_expiry - 60:
            return OneMapGateway._renewed_token
        return self._setting("ONEMAP_API_TOKEN")

    def _renew_token(self) -> str | None:
        """Get a fresh 3-day token with ONEMAP_EMAIL / ONEMAP_PASSWORD. Returns None if they are not set."""
        email, password = self._setting("ONEMAP_EMAIL"), self._setting("ONEMAP_PASSWORD")
        if not (email and password):
            return None
        try:
            response = requests.post(
                self.TOKEN_URL, json={"email": email, "password": password}, timeout=self.timeout_seconds
            )
            body = response.json() if response.ok else {}
        except (requests.RequestException, ValueError):
            return None
        token = body.get("access_token")
        if not token:
            return None
        OneMapGateway._renewed_token = token
        try:
            OneMapGateway._renewed_token_expiry = float(body.get("expiry_timestamp"))
        except (TypeError, ValueError):
            OneMapGateway._renewed_token_expiry = time.time() + 3 * 24 * 3600
        return token

    @staticmethod
    def _setting(name: str) -> str | None:
        """A setting from the Flask config if present, else from the environment (loaded from app/.env)."""
        if has_app_context() and current_app.config.get(name):
            return current_app.config.get(name)
        return os.environ.get(name) or None
