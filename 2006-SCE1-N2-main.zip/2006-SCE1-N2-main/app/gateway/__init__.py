"""«boundary» gateways: the only code that talks to external systems (ARC-02 §3.2 rule 5, §3.10 Gateway)."""
from app.gateway.external_school_data_gateway import ExternalSchoolDataGateway
from app.gateway.moe_school_finder_gateway import MoeSchoolFinderGateway
from app.gateway.onemap_gateway import OneMapGateway

__all__ = ["ExternalSchoolDataGateway", "MoeSchoolFinderGateway", "OneMapGateway"]
