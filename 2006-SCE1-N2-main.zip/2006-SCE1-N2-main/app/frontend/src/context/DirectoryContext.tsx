import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { useNavigate } from "react-router-dom";
import type { ShortlistEntry } from "../api/types";
import { backend } from "../data/backend";
import { useActiveStudent } from "./ActiveStudentContext";

interface DirectoryState {
  entries: ShortlistEntry[];
  savedIds: string[];
  toggleSaved: (id: string) => void;
  searchPath: string;
  rememberSearch: (path: string) => void;
}

const DirectoryContext = createContext<DirectoryState>(null!);
// UC08 / dialog map §4–5: the shortlist belongs to the active student; saving without a profile goes to Profiles (DM-36 -> DM-20).
export function DirectoryProvider({ children }: { children: ReactNode }) {
  const { activeStudent } = useActiveStudent();
  const navigate = useNavigate();
  const [entries, setEntries] = useState<ShortlistEntry[]>([]);
  const [searchPath, setSearchPath] = useState(() => sessionStorage.getItem("school-search-path") ?? "/schools");
  const studentId = activeStudent?.student_id;
  useEffect(() => { if (studentId) backend.getShortlist(studentId).then(list => setEntries(list.entries)); else setEntries([]); }, [studentId]);
  useEffect(() => sessionStorage.setItem("school-search-path", searchPath), [searchPath]);
  const toggleSaved = async (schoolId: string) => {
    if (!studentId) return navigate("/profiles");
    const entry = entries.find(e => e.school.school_id === schoolId);
    if (entry) await backend.removeFromShortlist(studentId, entry.entry_id);
    else await backend.addToShortlist(studentId, schoolId);
    setEntries((await backend.getShortlist(studentId)).entries);
  };
  const savedIds = entries.map(e => e.school.school_id);
  return <DirectoryContext.Provider value={{ entries, savedIds, toggleSaved, searchPath, rememberSearch: setSearchPath }}>{children}</DirectoryContext.Provider>;
}
export const useDirectory = () => useContext(DirectoryContext);
