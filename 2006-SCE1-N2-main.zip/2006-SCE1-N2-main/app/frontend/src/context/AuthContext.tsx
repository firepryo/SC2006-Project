// Signed-in account (UC02, dialog map §2). Restored from the session on page load.
import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { UserAccount } from "../api/types";
import { backend } from "../data/backend";

interface AuthState {
  user: UserAccount | null;
  ready: boolean;
  setUser: (user: UserAccount | null) => void;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthState>(null!);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserAccount | null>(null);
  const [ready, setReady] = useState(false);
  useEffect(() => { backend.getCurrentUser().then(setUser, () => setUser(null)).finally(() => setReady(true)); }, []);
  const logout = async () => { await backend.logout(); setUser(null); };
  return <AuthContext.Provider value={{ user, ready, setUser, logout }}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);
