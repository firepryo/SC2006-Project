// The student profile every screen acts for (dialog map §7 item 2; ARC-02 §3.6).
import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { StudentProfile } from "../api/types";
import { backend } from "../data/backend";
import { useAuth } from "./AuthContext";

interface ActiveStudentState {
  profiles: StudentProfile[];
  profilesLoaded: boolean;
  activeStudent: StudentProfile | null;
  setActiveStudent: (studentId: string) => void;
  refreshProfiles: () => Promise<void>;
}

const ActiveStudentContext = createContext<ActiveStudentState | undefined>(undefined);

export function ActiveStudentProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [profiles, setProfiles] = useState<StudentProfile[]>([]);
  const [profilesLoaded, setProfilesLoaded] = useState(false);
  const [activeId, setActiveId] = useState(() => localStorage.getItem("active-student") ?? "");
  const refreshProfiles = async () => { setProfiles(await backend.listProfiles()); setProfilesLoaded(true); };
  useEffect(() => { setProfilesLoaded(false); if (user) refreshProfiles(); else setProfiles([]); }, [user?.user_id]);
  const setActiveStudent = (studentId: string) => { localStorage.setItem("active-student", studentId); setActiveId(studentId); };
  const activeStudent = profiles.find(p => p.student_id === activeId) ?? profiles[0] ?? null;
  return (
    <ActiveStudentContext.Provider value={{ profiles, profilesLoaded, activeStudent, setActiveStudent, refreshProfiles }}>{children}</ActiveStudentContext.Provider>
  );
}

export function useActiveStudent(): ActiveStudentState {
  const value = useContext(ActiveStudentContext);
  if (!value) throw new Error("useActiveStudent must be used inside ActiveStudentProvider");
  return value;
}
