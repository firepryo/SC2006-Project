// Transient ComparisonSelection (dialog map §8): 2–5 schools, kept across Search, Details and Compare.
import { createContext, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import type { UUID } from "../api/types";

export const MIN_SCHOOLS = 2;
export const MAX_SCHOOLS = 5;

interface ComparisonSelectionState {
  selectedSchoolIds: UUID[];
  addSchool: (schoolId: UUID) => boolean; // false when MAX_SCHOOLS already selected (DM-45)
  removeSchool: (schoolId: UUID) => void;
  canCompare: () => boolean; // DM-40 vs DM-41
  clearSelection: () => void;
}

const ComparisonSelectionContext = createContext<ComparisonSelectionState | undefined>(undefined);

export function ComparisonSelectionProvider({ children }: { children: ReactNode }) {
  const [selectedSchoolIds, setSelectedSchoolIds] = useState<UUID[]>(() => JSON.parse(sessionStorage.getItem("school-comparison") ?? "[]"));
  const selected = useRef(selectedSchoolIds);
  useEffect(() => sessionStorage.setItem("school-comparison", JSON.stringify(selectedSchoolIds)), [selectedSchoolIds]);
  const update = (ids: UUID[]) => { selected.current = ids; setSelectedSchoolIds(ids); };

  const addSchool = (schoolId: UUID): boolean => {
    if (selected.current.includes(schoolId)) return true;
    if (selected.current.length === MAX_SCHOOLS) return false;
    update([...selected.current, schoolId]);
    return true;
  };
  const removeSchool = (schoolId: UUID): void => {
    update(selected.current.filter(id => id !== schoolId));
  };
  const canCompare = (): boolean => {
    return selectedSchoolIds.length >= MIN_SCHOOLS && selectedSchoolIds.length <= MAX_SCHOOLS;
  };

  return (
    <ComparisonSelectionContext.Provider value={{ selectedSchoolIds, addSchool, removeSchool, canCompare, clearSelection: () => update([]) }}>
      {children}
    </ComparisonSelectionContext.Provider>
  );
}

export function useComparisonSelection(): ComparisonSelectionState {
  const value = useContext(ComparisonSelectionContext);
  if (!value) throw new Error("useComparisonSelection must be used inside ComparisonSelectionProvider");
  return value;
}
