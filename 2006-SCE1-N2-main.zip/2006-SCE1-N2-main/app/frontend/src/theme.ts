// Light/dark theme. With no saved choice the app follows the system setting;
// the toggle saves an explicit choice. index.html applies a saved choice before first paint.
import { useEffect, useState } from "react";

export type Theme = "light" | "dark";
const KEY = "schoolwise-theme";
const media = () => window.matchMedia("(prefers-color-scheme: light)");

function saved(): Theme | null {
  try { const value = localStorage.getItem(KEY); return value === "light" || value === "dark" ? value : null; } catch { return null; }
}
const resolve = (): Theme => saved() ?? (media().matches ? "light" : "dark");

export function useTheme() {
  const [theme, setTheme] = useState<Theme>(resolve);
  useEffect(() => {
    const follow = () => { if (!saved()) setTheme(resolve()); };
    const query = media();
    query.addEventListener("change", follow);
    return () => query.removeEventListener("change", follow);
  }, []);
  const toggle = () => {
    const next: Theme = theme === "dark" ? "light" : "dark";
    document.documentElement.dataset.theme = next;
    try { localStorage.setItem(KEY, next); } catch { /* storage blocked: the choice lasts for this page only */ }
    setTheme(next);
  };
  return { theme, toggle };
}
