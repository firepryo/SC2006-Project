import type { CSSProperties } from "react";
const paths: Record<string, React.ReactNode> = {
  search: <><circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4.5 4.5"/></>,
  arrow: <path d="M5 12h14m-6-6 6 6-6 6"/>, back: <path d="M19 12H5m6-6-6 6 6 6"/>, down: <path d="m6 9 6 6 6-6"/>,
  close: <path d="m6 6 12 12M6 18 18 6"/>, check: <path d="m5 12 4 4L19 6"/>, plus: <path d="M12 5v14M5 12h14"/>,
  pin: <><path d="M20 10c0 6-8 11-8 11S4 16 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/></>,
  bookmark: <path d="M6 4h12v17l-6-4-6 4V4Z"/>, compare: <path d="M4 6h6v14H4zM14 3h6v17h-6z"/>,
  book: <path d="M12 5v15M3 4c4-1 6 0 9 2 3-2 5-3 9-2v15c-4-1-6 0-9 2-3-2-5-3-9-2V4Z"/>,
  info: <><circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10v1"/></>,
  external: <path d="M14 3h7v7m0-7L10 14M10 4H4v16h16v-6"/>,
  mail: <><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 6 9 7 9-7"/></>,
  phone: <path d="M6 3H3c0 10 8 18 18 18v-5l-5-2-2 3a15 15 0 0 1-7-7l3-2-2-5H6Z"/>,
  reset: <path d="M3 10a9 9 0 1 1 2 8M3 4v6h6"/>,
  filter: <path d="M4 6h16M7 12h10m-7 6h4"/>,
};
export function Icon({ name, size = 20, style }: { name: string; size?: number; style?: CSSProperties }) {
  return <svg aria-hidden="true" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" style={style}>{paths[name] ?? paths.book}</svg>;
}

// The brand mark is a tiny exercise book: chalk cover, darker spine, a ruled label.
export function BrandMark({ size = 28 }: { size?: number }) {
  return <svg className="brand-mark" aria-hidden="true" width={size * 0.8} height={size} viewBox="0 0 24 30">
    <rect x="0" y="0" width="24" height="30" rx="4" fill="var(--ink)"/>
    <rect x="0" y="0" width="6" height="30" rx="2.5" fill="var(--dim)"/>
    <path d="M10 11h10M10 15h10M10 19h6" stroke="var(--bg)" strokeWidth="1.6" strokeLinecap="round"/>
  </svg>;
}
