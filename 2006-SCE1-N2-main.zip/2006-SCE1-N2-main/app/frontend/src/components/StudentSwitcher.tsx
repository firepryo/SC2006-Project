// Header control for choosing the active student. A custom menu instead of a native <select>,
// so it matches the rest of the interface in both themes.
import { useEffect, useRef, useState, type KeyboardEvent } from "react";
import { useNavigate } from "react-router-dom";
import { useActiveStudent } from "../context/ActiveStudentContext";
import { levelLabel } from "../data/schoolDirectory";
import { Icon } from "./Icon";

export function StudentSwitcher() {
  const { profiles, activeStudent, setActiveStudent } = useActiveStudent();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const root = useRef<HTMLDivElement>(null);
  const button = useRef<HTMLButtonElement>(null);
  const items = useRef<(HTMLButtonElement | null)[]>([]);

  useEffect(() => {
    if (!open) return;
    const close = (event: PointerEvent) => { if (!root.current?.contains(event.target as Node)) setOpen(false); };
    document.addEventListener("pointerdown", close);
    const current = profiles.findIndex(p => p.student_id === activeStudent?.student_id);
    items.current[Math.max(0, current)]?.focus();
    return () => document.removeEventListener("pointerdown", close);
  }, [open]);

  const choose = (action: () => void) => { action(); setOpen(false); button.current?.focus(); };
  const onMenuKey = (event: KeyboardEvent) => {
    const list = items.current.filter(Boolean) as HTMLButtonElement[];
    const index = list.indexOf(document.activeElement as HTMLButtonElement);
    if (event.key === "Escape") { event.preventDefault(); setOpen(false); button.current?.focus(); }
    else if (event.key === "ArrowDown") { event.preventDefault(); list[(index + 1) % list.length]?.focus(); }
    else if (event.key === "ArrowUp") { event.preventDefault(); list[(index - 1 + list.length) % list.length]?.focus(); }
    else if (event.key === "Home") { event.preventDefault(); list[0]?.focus(); }
    else if (event.key === "End") { event.preventDefault(); list[list.length - 1]?.focus(); }
    else if (event.key === "Tab") setOpen(false);
  };

  if (!profiles.length) return null;
  return <div className="student-switch" ref={root}>
    <button ref={button} type="button" className="student-switch-button" aria-haspopup="menu" aria-expanded={open} aria-controls="student-menu"
      onClick={() => setOpen(!open)} onKeyDown={event => { if (event.key === "ArrowDown") { event.preventDefault(); setOpen(true); } }}>
      <span className="student-switch-label">Student</span>
      <strong>{activeStudent?.name ?? "Choose"}</strong>
      <Icon name="down" size={16}/>
    </button>
    {open && <div id="student-menu" className="student-menu" role="menu" aria-label="Choose a student" onKeyDown={onMenuKey}>
      {profiles.map((p, i) => {
        const active = p.student_id === activeStudent?.student_id;
        return <button key={p.student_id} ref={el => { items.current[i] = el; }} type="button" role="menuitemradio" aria-checked={active}
          className={`student-menu-item ${active ? "is-active" : ""}`} onClick={() => choose(() => setActiveStudent(p.student_id))}>
          <span><strong>{p.name ?? "Unnamed"}</strong><small>{levelLabel[p.current_level]} {p.current_year}</small></span>
          {active && <Icon name="check" size={17}/>}
        </button>;
      })}
      <div className="student-menu-divider" role="separator"/>
      <button ref={el => { items.current[profiles.length] = el; }} type="button" role="menuitem" className="student-menu-item manage"
        onClick={() => choose(() => navigate("/profiles"))}>Manage students</button>
    </div>}
  </div>;
}
