// UC07a: the home postal code that distances and the OneMap route are measured from.
import { useEffect, useState, type FormEvent } from "react";
import { updateHomeLocation } from "../api/client";
import { useAuth } from "../context/AuthContext";
import { isDemo } from "../data/schoolDirectory";

export function HomeLocationCard() {
  const { user, setUser } = useAuth();
  const [postal, setPostal] = useState(user?.preferred_postal_code ?? "");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  useEffect(() => { setPostal(user?.preferred_postal_code ?? ""); }, [user?.preferred_postal_code]);
  useEffect(() => { if (window.location.hash === "#home-location") document.getElementById("home-location")?.scrollIntoView(); }, []);
  if (isDemo || !user) return null;

  const save = async (event: FormEvent) => {
    event.preventDefault();
    setMessage(""); setError("");
    const value = postal.trim();
    if (value && !/^\d{6}$/.test(value)) return setError("Postal code must be 6 digits.");
    setSaving(true);
    try {
      const updated = await updateHomeLocation(value);
      setUser(updated);
      setMessage(value ? "Saved. Distances are now measured from this postal code." : "Home postal code removed.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Couldn’t save the postal code. Please try again.");
    } finally { setSaving(false); }
  };

  return <section id="home-location" className="home-section home-location" aria-labelledby="home-location-title">
    <header><h2 id="home-location-title">Home postal code</h2></header>
    <form className="home-location-form" onSubmit={save} noValidate>
      <label className="field"><span>Postal code</span>
        <input inputMode="numeric" autoComplete="postal-code" maxLength={6} value={postal}
          onChange={e => setPostal(e.target.value.replace(/\D/g, ""))} aria-invalid={!!error} aria-describedby="home-location-help"/>
        <small id="home-location-help">Located with OneMap. Used to show how far each school is from home and the route there.</small>
      </label>
      <button className="button button-primary" type="submit" disabled={saving}>{saving ? "Saving…" : "Save"}</button>
    </form>
    {error && <p className="form-error" role="alert">{error}</p>}
    {message && <p className="form-success" role="status">{message}</p>}
  </section>;
}
