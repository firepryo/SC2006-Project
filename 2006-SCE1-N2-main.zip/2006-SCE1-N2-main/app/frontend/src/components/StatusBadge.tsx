import type { ApplicationStatus } from "../api/types";
import { statusLabel } from "../data/backend";
// UC10: one visual per application status, used on every application screen.
export function StatusBadge({ status }: { status: ApplicationStatus }) {
  return <span className={`status-badge status-${status}`}>{statusLabel[status]}</span>;
}
