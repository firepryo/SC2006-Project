// Where the school is in relation to home, on OneMap (Singapore Land Authority) base map tiles.
import { useEffect, useRef } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import type { LatLng } from "../api/types";

// OneMap tiles need no token; their terms ask for this attribution.
const ONEMAP_ATTRIBUTION =
  '<a href="https://www.onemap.gov.sg/" target="_blank" rel="noopener noreferrer">OneMap</a>&nbsp;&copy;&nbsp;contributors&nbsp;&#124;&nbsp;' +
  '<a href="https://www.sla.gov.sg/" target="_blank" rel="noopener noreferrer">Singapore Land Authority</a>';
// Singapore's extent; OneMap has no tiles outside it.
const SINGAPORE_BOUNDS = L.latLngBounds([1.144, 103.535], [1.494, 104.1]);

const isDark = () => {
  const chosen = document.documentElement.dataset.theme;
  return chosen ? chosen === "dark" : !window.matchMedia("(prefers-color-scheme: light)").matches;
};
const pin = (kind: "home" | "school", label: string) =>
  L.divIcon({ className: "", html: `<span class="map-pin map-pin-${kind}" aria-hidden="true"></span>`, iconSize: [22, 22], iconAnchor: [11, 11], popupAnchor: [0, -12], tooltipAnchor: [12, 0] });

interface Props {
  school: LatLng;
  schoolName: string;
  home?: LatLng | null;
  path?: number[][];
}

export function OneMapView({ school, schoolName, home, path = [] }: Props) {
  const container = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!container.current) return;
    const map = L.map(container.current, { maxBounds: SINGAPORE_BOUNDS, minZoom: 11, maxZoom: 19, scrollWheelZoom: false, attributionControl: true });
    L.tileLayer(`https://www.onemap.gov.sg/maps/tiles/${isDark() ? "Night" : "Default"}/{z}/{x}/{y}.png`, {
      detectRetina: true, maxZoom: 19, minZoom: 11, attribution: ONEMAP_ATTRIBUTION,
    }).addTo(map);

    const points: L.LatLngExpression[] = [[school.lat, school.lng]];
    L.marker([school.lat, school.lng], { icon: pin("school", schoolName), title: schoolName, keyboard: false })
      .bindTooltip(schoolName, { direction: "right" }).addTo(map);
    if (home) {
      points.push([home.lat, home.lng]);
      L.marker([home.lat, home.lng], { icon: pin("home", "Home"), title: "Home", keyboard: false })
        .bindTooltip("Home", { direction: "right", permanent: true, className: "map-home-label" }).addTo(map);
    }
    if (path.length > 1) {
      const color = getComputedStyle(document.documentElement).getPropertyValue("--link").trim() || "#2c4fb0";
      const line = L.polyline(path as L.LatLngExpression[], { color, weight: 4, opacity: 0.85 }).addTo(map);
      // Extra bottom padding keeps the pins clear of the attribution bar.
      map.fitBounds(line.getBounds().extend(L.latLngBounds(points)), { paddingTopLeft: [40, 40], paddingBottomRight: [40, 56], maxZoom: 17 });
    } else if (home) {
      map.fitBounds(L.latLngBounds(points), { paddingTopLeft: [40, 40], paddingBottomRight: [40, 56], maxZoom: 17 });
    } else {
      map.setView([school.lat, school.lng], 16);
    }
    return () => { map.remove(); };
  }, [school.lat, school.lng, home?.lat, home?.lng, path.length, schoolName]);

  return <div ref={container} className="onemap-view" role="img"
    aria-label={home ? `Map showing home and ${schoolName}${path.length > 1 ? " with the travel route" : ""}` : `Map showing ${schoolName}`}/>;
}
