import { Link } from "react-router-dom";
import type { SchoolSummary } from "../api/types";
import type { DirectorySchool } from "../data/demoSchools";
import { levelLabel } from "../data/schoolDirectory";
import { CompareButton, SaveButton } from "./SchoolActions";

// Distance from home, the figure parents check first. Unknown distances say so rather than hiding.
// In search results the figure is the straight-line distance (one OneMap route per school would be too slow).
export function Distance({ km, className = "", label = "from home", missing = "Distance not available" }:
  { km?: number | null; className?: string; label?: string; missing?: string }) {
  if (km == null) return <p className={`distance unknown ${className}`}><small>{missing}</small></p>;
  return <p className={`distance ${className}`}><strong>{km.toFixed(1)}<span>km</span></strong><small>{label}</small></p>;
}

// UI-01 / UC04–UC06: a school is a list row; its name is the link to the details.
export function SchoolRow({ school }: { school: SchoolSummary & Partial<DirectorySchool> }) {
  const rememberPosition = () => sessionStorage.setItem("school-search-scroll", String(window.scrollY));
  return <article className="school-row">
    <div>
      <h3 className="school-row-title"><Link to={`/schools/${school.school_id}`} onClick={rememberPosition}>{school.name}</Link></h3>
      <p className="school-meta"><span>{levelLabel[school.type]}</span><span>{school.planning_area ?? school.zone ?? "Location not available"}</span></p>
      <p className="school-offerings">{school.subjects
        ? <>{school.subjects.length} subjects, {school.ccas?.length ? `${school.ccas.length} co-curricular activities` : "activities not listed"}</>
        : school.address}</p>
    </div>
    <div className="school-row-side">
      {"distance_km" in school ? <Distance km={school.distance_km} label="from home, straight line" missing="Set your home postal code to see distance"/> : <span/>}
      <div className="row-actions"><SaveButton id={school.school_id} name={school.name} compact/><CompareButton id={school.school_id} name={school.name} compact/></div>
    </div>
  </article>;
}
