import { Link, NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useActiveStudent } from "../context/ActiveStudentContext";
import { useDirectory } from "../context/DirectoryContext";
import { useComparisonSelection, MAX_SCHOOLS } from "../context/ComparisonSelectionContext";
import { backend } from "../data/backend";
import { loadSchool } from "../data/schoolDirectory";
import { useLoad } from "../hooks/useLoad";
import { BrandMark, Icon } from "./Icon";
import { ThemeToggle } from "./ThemeToggle";
import { StudentSwitcher } from "./StudentSwitcher";
import { useLiveMotion } from "../hooks/useLiveMotion";
import { useCountUp } from "../hooks/useCountUp";

function ComparisonTray() {
  const { selectedSchoolIds, removeSchool, clearSelection, canCompare } = useComparisonSelection();
  const { data: schools } = useLoad(() => Promise.all(selectedSchoolIds.map(loadSchool)), [selectedSchoolIds.join(",")]);
  if (!selectedSchoolIds.length) return null;
  const hint = selectedSchoolIds.length === 1 ? "Add one more to compare" : selectedSchoolIds.length === MAX_SCHOOLS ? "Remove one to add another" : "Ready to compare";
  return <div className="comparison-tray" role="region" aria-label="Comparison selection"><div className="tray-inner page-width">
    <div className="tray-summary"><strong>{selectedSchoolIds.length} of {MAX_SCHOOLS} schools</strong><span>{hint}</span></div>
    <div className="tray-schools">{schools?.filter(school => selectedSchoolIds.includes(school.school_id)).map(school =>
      <div className="tray-school" key={school.school_id}><span title={school.name}>{school.name}</span>
        <button className="icon-button" aria-label={`Remove ${school.name} from comparison`} onClick={() => removeSchool(school.school_id)}><Icon name="close" size={15}/></button>
      </div>)}
    </div>
    <button className="text-button muted-button" onClick={clearSelection}>Clear</button>
    {canCompare() ? <Link className="button button-primary" to="/compare">Compare schools</Link> : <button className="button button-primary" disabled>Compare schools</button>}
    <span className="sr-only" role="status">{selectedSchoolIds.length} schools selected for comparison.</span>
  </div></div>;
}

export function AppShell() {
  useLiveMotion();
  const { user, logout } = useAuth();
  const { profiles, activeStudent, setActiveStudent } = useActiveStudent();
  const { searchPath, savedIds } = useDirectory();
  const { selectedSchoolIds } = useComparisonSelection();
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const { data: reminders } = useLoad(() => backend.listNotifications(), [pathname]);
  const unread = reminders?.filter(r => !r.is_read).length ?? 0;
  const showTray = pathname.startsWith("/schools") || pathname === "/shortlist";
  const count = (n: number, label: string, attention = false) => n > 0 && <NavCount value={n} label={label} attention={attention}/>;

  return <div className={`app-shell ${selectedSchoolIds.length && showTray ? "has-tray" : ""}`}>
    <a className="skip-link" href="#main-content">Skip to content</a>
    <header className="site-header"><div className="header-inner page-width">
      <Link to="/home" className="brand" aria-label="Schoolwise home"><BrandMark/><span>Schoolwise</span></Link>
      <nav className="main-nav" aria-label="Main navigation">
        <NavLink to="/home">Home</NavLink>
        <Link className={pathname.startsWith("/schools") ? "active" : ""} aria-current={pathname.startsWith("/schools") ? "page" : undefined} to={searchPath}>Find schools</Link>
        <NavLink to="/compare">Compare{count(selectedSchoolIds.length, "selected")}</NavLink>
        <NavLink to="/shortlist">Shortlist{count(savedIds.length, "saved")}</NavLink>
        <NavLink to="/applications">Applications</NavLink>
        <NavLink to="/notifications">Notifications{count(unread, "unread", true)}</NavLink>
      </nav>
      <div className="header-end">
        <StudentSwitcher/>
        <ThemeToggle/>
        <div className="account"><span>{user?.name}</span><button className="text-button muted-button" onClick={async () => { await logout(); navigate("/"); }}>Log out</button></div>
      </div>
    </div></header>
    <main id="main-content" key={pathname} className="page-width main-content route-enter" tabIndex={-1}><Outlet/></main>
    <footer className="site-footer page-width"><span>School Comparison &amp; Shortlisting</span><span>Primary to junior college</span></footer>
    {showTray && <ComparisonTray/>}
  </div>;
}

function NavCount({ value, label, attention }: { value: number; label: string; attention: boolean }) {
  const display = useCountUp(value);
  return <span className={`nav-count ${attention ? "attention" : ""}`} aria-label={`${value} ${label}`}>{display}</span>;
}
