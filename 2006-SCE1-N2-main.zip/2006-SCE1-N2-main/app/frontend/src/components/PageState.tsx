import { Link } from "react-router-dom";
import { Icon } from "./Icon";
export function LoadingState({ rows = 4, label = "Loading" }: { rows?: number; label?: string }) {
  return <div className="loading-state" role="status" aria-label={label}><span className="sr-only">{label}…</span>{Array.from({ length: rows }, (_, i) => <div className="skeleton-row" key={i}><div className="skeleton-mark"/><div><div className="skeleton-line"/><div className="skeleton-line short"/></div></div>)}</div>;
}
export function ErrorState({ message, retry }: { message: string; retry: () => void }) {
  return <div className="empty-state" role="alert"><Icon name="info" size={30}/><h2>This information didn’t load</h2><p>{message || "Check your connection, then try again."}</p><button className="button button-secondary" onClick={retry}><Icon name="reset" size={16}/>Try again</button></div>;
}
export function EmptySelection({ title, children, searchPath }: { title: string; children: React.ReactNode; searchPath: string }) {
  return <div className="empty-state"><Icon name="compare" size={32}/><h2>{title}</h2><p>{children}</p><Link className="button button-primary" to={searchPath}>Find schools</Link></div>;
}
