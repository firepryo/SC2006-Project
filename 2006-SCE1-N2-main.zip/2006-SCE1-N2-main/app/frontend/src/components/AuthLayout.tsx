import type { ReactNode } from "react";
import { Link } from "react-router-dom";
import { BrandMark } from "./Icon";
import { ThemeToggle } from "./ThemeToggle";

// Sign-in screens: the student's exercise-book cover, name still blank.
export function AuthLayout({ children }: { children: ReactNode }) {
  return <div className="auth-page">
    <div className="cover auth-cover">
      <Link to="/" className="brand" aria-label="Schoolwise home"><BrandMark/><span>Schoolwise</span></Link>
      <dl className="label-lines" aria-hidden="true">
        <div><dt>Name</dt><dd className="label-blank"/></div>
        <div className="label-inline"><div><dt>Level</dt><dd>Primary to JC</dd></div><div><dt>Subject</dt><dd>Choosing a school</dd></div></div>
      </dl>
      <p>Every school, side by side. <span>Every deadline, on time.</span></p>
    </div>
    <main className="auth-main"><ThemeToggle className="auth-theme"/><div className="auth-panel">{children}</div></main>
  </div>;
}
