import { useComparisonSelection, MAX_SCHOOLS } from "../context/ComparisonSelectionContext";
import { useDirectory } from "../context/DirectoryContext";
import { useActiveStudent } from "../context/ActiveStudentContext";
import { Icon } from "./Icon";
// UI-01 / UC07: one shared selection, including at the five-school limit.
export function CompareButton({ id, name, compact = false }: { id: string; name: string; compact?: boolean }) {
  const { selectedSchoolIds, addSchool, removeSchool } = useComparisonSelection();
  const selected = selectedSchoolIds.includes(id);
  const full = !selected && selectedSchoolIds.length >= MAX_SCHOOLS;
  return <button className={`button ${selected ? "button-selected" : "button-secondary"} ${compact ? "button-small" : ""}`} disabled={full} aria-pressed={selected}
    aria-label={`${selected ? "Remove" : "Add"} ${name} ${selected ? "from" : "to"} comparison`} title={full ? "Compare up to 5 schools. Remove one to add another." : undefined}
    onClick={() => selected ? removeSchool(id) : addSchool(id)}><Icon name={selected ? "check" : "plus"} size={16}/>{selected ? "In comparison" : "Compare"}</button>;
}
export function SaveButton({ id, name, compact = false }: { id: string; name: string; compact?: boolean }) {
  const { savedIds, toggleSaved } = useDirectory();
  const { activeStudent } = useActiveStudent();
  const saved = savedIds.includes(id);
  const who = activeStudent?.name ?? "this student";
  return <button className={compact ? `icon-button ${saved ? "is-saved" : ""}` : `button ${saved ? "button-selected" : "button-secondary"} ${saved ? "is-saved" : ""}`} aria-pressed={saved}
    aria-label={`${saved ? "Remove" : "Add"} ${name} ${saved ? "from" : "to"} ${who}'s shortlist`} title={saved ? `On ${who}'s shortlist` : `Add to ${who}'s shortlist`}
    onClick={() => toggleSaved(id)}><Icon name="bookmark" size={compact ? 20 : 17}/>{!compact && (saved ? `On ${who}’s shortlist` : "Add to shortlist")}</button>;
}
