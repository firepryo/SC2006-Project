import { useEffect } from "react";

export function useLiveMotion() {
  useEffect(() => {
    const root = document.documentElement;
    const visibility = () => root.classList.toggle("motion-paused", document.hidden);
    visibility();
    document.addEventListener("visibilitychange", visibility);

    const motionTargets = document.querySelectorAll<HTMLElement>(
      ".school-row, .panel, .contact-panel, .home-section, .cover, .detail-section, .notification-list > li, .tray-school, .page-heading, .empty-state, .status-steps, .table-wrap, .comparison-scroll",
    );
    let observer: IntersectionObserver | undefined;
    if ("IntersectionObserver" in window) {
      observer = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          entry.target.classList.add("motion-enter");
          observer?.unobserve(entry.target);
        });
      }, { threshold: 0.08 });
      motionTargets.forEach((target) => observer!.observe(target));
    }

    const pointerMove = (event: PointerEvent) => {
      const target = (event.target as HTMLElement).closest<HTMLElement>(".school-row, .panel, .contact-panel, .home-section");
      if (!target) return;
      const rect = target.getBoundingClientRect();
      target.style.setProperty("--mx", `${event.clientX - rect.left}px`);
      target.style.setProperty("--my", `${event.clientY - rect.top}px`);
    };
    document.addEventListener("pointermove", pointerMove, { passive: true });

    return () => {
      document.removeEventListener("visibilitychange", visibility);
      document.removeEventListener("pointermove", pointerMove);
      observer?.disconnect();
    };
  }, []);
}
