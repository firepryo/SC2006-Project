import { useEffect, useState, type DependencyList } from "react";

// UI-01: the three directory pages share a small loading/error/retry pattern.
export function useLoad<T>(loader: () => Promise<T>, dependencies: DependencyList) {
  const [data, setData] = useState<T>();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [attempt, setAttempt] = useState(0);
  useEffect(() => {
    let current = true;
    setLoading(true); setError("");
    loader().then(value => { if (current) setData(value); })
      .catch(error => { if (current) setError(error.message || "Something went wrong. Please try again."); })
      .finally(() => { if (current) setLoading(false); });
    return () => { current = false; };
  }, [...dependencies, attempt]);
  return { data, loading, error, retry: () => setAttempt(value => value + 1) };
}
