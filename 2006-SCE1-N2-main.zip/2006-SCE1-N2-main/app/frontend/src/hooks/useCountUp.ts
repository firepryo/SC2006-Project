import { useEffect, useState } from "react";

export function useCountUp(value: number, duration = 600) {
  const [display, setDisplay] = useState(0);
  useEffect(() => {
    let current = 0;
    const interval = window.setInterval(() => {
      current = Math.min(value, current + Math.max(1, Math.ceil(value / (duration / 32))));
      setDisplay(current);
      if (current >= value) window.clearInterval(interval);
    }, 32);
    return () => window.clearInterval(interval);
  }, [value, duration]);
  return display;
}
