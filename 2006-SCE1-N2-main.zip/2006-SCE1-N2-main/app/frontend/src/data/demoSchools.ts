// UI-01: fictional fixtures for the authorised interactive preview; not admissions data.
import type { Cca, EducationLevel, SchoolDetails, Subject } from "../api/types";

export interface DirectorySchool extends SchoolDetails {
  distance_km?: number | null;
}

const subjectNames = ["English", "Mathematics", "Science", "Chinese", "Malay", "Tamil", "Art", "Music", "Computing", "Physics", "Chemistry", "Biology", "History", "Geography", "Economics"];
export const demoSubjects: Subject[] = subjectNames.map((name, i) => ({ subject_id: `subject-${i}`, subject_name: name, level: "Secondary", is_special_programme: false }));
export const demoCcas: Cca[] = [
  ["Badminton", "Sports"], ["Basketball", "Sports"], ["Football", "Sports"], ["Swimming", "Sports"],
  ["Choir", "PerformingArts"], ["Drama", "PerformingArts"], ["Concert Band", "PerformingArts"],
  ["Robotics", "ClubSociety"], ["Environmental Club", "ClubSociety"], ["Scouts", "UniformedGroup"],
  ["Photography", "ClubSociety"], ["Debate", "ClubSociety"],
].map(([name, category], i) => ({ cca_id: `cca-${i}`, cca_name: name, category: category as Cca["category"] }));

type Seed = [string, EducationLevel, string, string, string, number | null, number[], number[]];
const seeds: Seed[] = [
  ["Angsana Grove Primary", "Primary", "North", "Woodlands", "18 Grove Avenue", 1.2, [0,1,2,3,4,5,6,7], [0,4,7,8]],
  ["Bayshore Green Primary", "Primary", "East", "Bedok", "42 Bay Lane", 5.8, [0,1,2,3,4,5,6], [2,3,4,9]],
  ["Cedarbrook Secondary", "Secondary", "Central", "Bishan", "7 Cedarbrook Road", 2.4, [0,1,3,4,8,9,10,12], [0,1,6,7,11]],
  ["Dover Grove Secondary", "Secondary", "West", "Clementi", "25 Dover Grove", 4.6, [0,1,3,4,9,10,11,13], [2,4,8,10]],
  ["Eastbank Junior College", "JuniorCollege", "East", "Tampines", "81 Eastbank Avenue", 8.1, [0,1,9,10,11,12,14], [1,3,6,11]],
  ["Fernhill Park Primary", "Primary", "North", "Yishun", "6 Fernhill Walk", 2.1, [0,1,2,3,4,5,6,7], [0,2,4,8]],
  ["Greenhaven Secondary", "Secondary", "North", "Woodlands", "33 Greenhaven Drive", 1.8, [0,1,3,4,6,8,9,10,13], [0,4,7,9]],
  ["Hillview Grove Primary", "Primary", "West", "Bukit Batok", "11 Hillview Grove", 6.2, [0,1,2,3,4,5,7], [1,5,7,8]],
  ["Jade Park Secondary", "Secondary", "East", "Pasir Ris", "9 Jade Park Road", 7.3, [0,1,3,4,6,9,10,11,12], [2,5,6,10]],
  ["Kestrel Grove Primary", "Primary", "Central", "Toa Payoh", "14 Kestrel Grove", 3.2, [0,1,2,3,4,5,6,7], [0,3,4,9]],
  ["Lakewood Junior College", "JuniorCollege", "West", "Jurong East", "51 Lakewood Avenue", null, [0,1,8,9,10,11,14], [0,6,7,11]],
  ["Meranti Park Secondary", "Secondary", "Central", "Ang Mo Kio", "28 Meranti Park", 3.5, [0,1,3,4,8,9,10,12,13], [1,4,7,8]],
  ["Northbank Primary", "Primary", "North", "Sembawang", "4 Northbank Crescent", 2.9, [0,1,2,3,4,5,6], [0,2,5,9]],
  ["Orchard Grove Secondary", "Secondary", "Central", "Bukit Timah", "63 Orchard Grove", 4.2, [0,1,3,4,6,7,9,10,12], [3,4,5,10]],
  ["Pandan Green Primary", "Primary", "West", "Jurong West", "16 Pandan Green", 7.6, [0,1,2,3,4,5,6,7], [1,4,7,8]],
  ["Seraya Heights Secondary", "Secondary", "East", "Bedok", "12 Seraya Heights", null, [0,1,3,4,9,10,11,13], []],
  ["Tembusu Junior College", "JuniorCollege", "Central", "Bishan", "22 Tembusu Road", 3.1, [0,1,8,9,10,12,14], [0,5,7,11]],
  ["Willowbank Primary", "Primary", "North", "Yishun", "38 Willowbank Walk", 2.7, [0,1,2,3,4,5,7], [2,4,8,9]],
];

export const demoSchools: DirectorySchool[] = seeds.map(([name, level, zone, area, address, distance, subjects, ccas], i) => ({
  school_id: `demo-school-${i + 1}`, name, type: level, zone, planning_area: area, address,
  postal_code: null, website: null, telephone: null, email: null,
  distance_km: distance,
  description: `${name} is a fictional ${level === "Primary" ? "primary school" : level === "Secondary" ? "secondary school" : "junior college"} in ${area}. Explore its sample subjects and activities, or add it to your comparison to see the options side by side.`,
  subjects: subjects.map(index => ({ ...demoSubjects[index], level })), ccas: ccas.map(index => demoCcas[index]), affiliations: [],
}));

// A sample known affiliation; all other examples have no affiliations recorded.
demoSchools[0].affiliations = [{ affiliation_id: "demo-affiliation-1", feeder_school_id: "demo-school-1", receiving_school_id: "demo-school-7", priority_description: "Example affiliated school" }];
demoSchools[6].affiliations = demoSchools[0].affiliations;
