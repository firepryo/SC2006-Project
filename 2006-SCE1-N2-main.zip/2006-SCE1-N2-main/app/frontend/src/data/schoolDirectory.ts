// UI-01: one adapter boundary between fictional preview data and ARC-02 APIs.
import type { SearchCriteria, SchoolSummary } from "../api/types";
import * as api from "../api/client";
import { demoCcas, demoSchools, demoSubjects, type DirectorySchool } from "./demoSchools";

export const isDemo = import.meta.env.VITE_DATA_SOURCE !== "api";
// The fictional schools use Central; the API accepts only the school dataset's four zones.
export const zoneOptions = isDemo ? ["Central", "East", "North", "West"] : ["East", "North", "South", "West"];
export const levelLabel: Record<string, string> = { Primary: "Primary", Secondary: "Secondary", JuniorCollege: "Junior college", MixedLevels: "Mixed levels" };
export const schoolInitials = (name: string) => name.split(" ").slice(0, 2).map(word => word[0]).join("");

export async function findSchools(criteria: SearchCriteria): Promise<SchoolSummary[]> {
  if (!isDemo) return api.searchSchools(criteria);
  const query = criteria.q?.trim().toLowerCase() ?? "";
  return demoSchools.filter(school =>
    (!query || `${school.name} ${school.address} ${school.planning_area}`.toLowerCase().includes(query)) &&
    (!criteria.level || school.type === criteria.level) &&
    (!criteria.zone || school.zone === criteria.zone) &&
    (!criteria.subject_id || school.subjects.some(subject => subject.subject_id === criteria.subject_id)) &&
    (!criteria.cca_id || school.ccas.some(cca => cca.cca_id === criteria.cca_id))
  );
}

export async function loadSchool(id: string): Promise<DirectorySchool> {
  if (!isDemo) return api.getSchoolDetails(id);
  const school = demoSchools.find(item => item.school_id === id);
  if (!school) throw new Error("We couldn't find this school. Return to the directory to choose another.");
  return school;
}

export const loadSubjects = () => isDemo ? Promise.resolve(demoSubjects) : api.listSubjects();
export const loadCcas = () => isDemo ? Promise.resolve(demoCcas) : api.listCcas();
export const affiliationNames = (school: DirectorySchool) => school.affiliations.map(item => {
  const id = item.feeder_school_id === school.school_id ? item.receiving_school_id : item.feeder_school_id;
  return demoSchools.find(item => item.school_id === id)?.name ?? item.priority_description ?? "Affiliated school";
});
