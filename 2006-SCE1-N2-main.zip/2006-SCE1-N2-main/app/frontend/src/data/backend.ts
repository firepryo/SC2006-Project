// Pages call `backend`: the local stand-in by default, the Flask API when VITE_DATA_SOURCE=api.
import * as api from "../api/client";
import { localApi } from "./localApi";
import { isDemo } from "./schoolDirectory";

export const backend = isDemo ? localApi : api;
export { nextStatuses } from "./localApi";

export const statusLabel: Record<string, string> = {
  Draft: "Draft", Submitted: "Submitted", UnderReview: "Under review", Offered: "Offered", Rejected: "Rejected", Accepted: "Accepted",
};
export const formatDate = (value: string | null) =>
  value ? new Date(value.length === 10 ? `${value}T00:00:00` : value).toLocaleDateString("en-SG", { day: "numeric", month: "short", year: "numeric" }) : "—";
export const daysUntil = (date: string) => Math.round((new Date(`${date}T00:00:00`).getTime() - new Date(new Date().toDateString()).getTime()) / 86_400_000);
// "Thu 5 Nov": short date for lists where the year is obvious.
export const formatDay = (value: string | null) => {
  if (!value) return "—";
  const date = new Date(value.length === 10 ? `${value}T00:00:00` : value);
  return `${date.toLocaleDateString("en-SG", { weekday: "short" })} ${date.getDate()} ${date.toLocaleDateString("en-SG", { month: "short" })}`;
};
// "in 4 days", "today", "tomorrow", "3 days ago"
export const dueLabel = (date: string) => {
  const days = daysUntil(date);
  if (days === 0) return "today";
  if (days === 1) return "tomorrow";
  if (days < 0) return `${-days} day${days === -1 ? "" : "s"} ago`;
  return `in ${days} days`;
};
