// Browser-only stand-in for the Flask API (ARC-02 §4.1) while the backend is a skeleton.
// Same signatures as api/client.ts; data lives in localStorage. Rules follow ARC-02 §3.7 and dialog map §5.
import type * as api from "../api/client";
import type { Application, ApplicationStatus, Notification, ProfileInput, StudentProfile, UserAccount } from "../api/types";
import { demoCcas, demoSchools, demoSubjects } from "./demoSchools";

interface StoredUser extends UserAccount { password: string; failed: number; locked_until: number }
interface StoredApplication extends Omit<Application, "school"> { school_id: string }
interface Db {
  users: StoredUser[];
  session: string | null;
  profiles: (StudentProfile & { user_id: string })[];
  shortlists: Record<string, { entry_id: string; school_id: string; date_added: string }[]>;
  applications: StoredApplication[];
  read: string[];
}

const KEY = "schoolwise-db";
const DAY = 86_400_000;
const isoDate = (offsetDays: number) => new Date(Date.now() + offsetDays * DAY).toISOString().slice(0, 10);
const id = () => crypto.randomUUID();

// Seed: one account with a profile, a shortlist and two applications, so every screen has something to show.
function seed(): Db {
  const now = new Date().toISOString();
  return {
    users: [{ user_id: "user-1", name: "Tan Mei Ling", email: "demo@schoolwise.test", password: "demo1234", preferred_postal_code: "570123", notification_opt_in: true, failed: 0, locked_until: 0 }],
    session: null,
    profiles: [{ user_id: "user-1", student_id: "student-1", name: "Ethan", current_level: "Primary", current_year: 6, preferred_subject_ids: ["subject-1", "subject-2"], preferred_cca_ids: ["cca-0", "cca-7"] }],
    shortlists: { "student-1": ["demo-school-3", "demo-school-4", "demo-school-9"].map((school_id, i) => ({ entry_id: `entry-${i}`, school_id, date_added: now })) },
    applications: [
      { application_id: "app-1", student_id: "student-1", school_id: "demo-school-3", status: "Submitted", date_submitted: isoDate(-6), deadline: isoDate(4), notes: "Open house attended in March.", updated_at: now },
      { application_id: "app-2", student_id: "student-1", school_id: "demo-school-4", status: "Draft", date_submitted: null, deadline: null, notes: null, updated_at: now },
    ],
    read: [],
  };
}

const load = (): Db => JSON.parse(localStorage.getItem(KEY) ?? "null") ?? seed();
async function tx<T>(change: (db: Db) => T): Promise<T> {
  const db = load();
  const result = change(db);
  localStorage.setItem(KEY, JSON.stringify(db));
  return structuredClone(result);
}

const publicUser = ({ password, failed, locked_until, ...user }: StoredUser): UserAccount => user;
const me = (db: Db) => {
  const user = db.users.find(u => u.user_id === db.session);
  if (!user) throw new Error("Your session has ended. Log in again.");
  return user;
};
const summary = (schoolId: string) => {
  const { school_id, name, type, address, zone, planning_area } = demoSchools.find(s => s.school_id === schoolId)!;
  return { school_id, name, type, address, zone, planning_area };
};
const toApplication = ({ school_id, ...rest }: StoredApplication): Application => ({ ...rest, school: summary(school_id) });
const ownProfile = (db: Db, studentId: string) => db.profiles.find(p => p.student_id === studentId && p.user_id === me(db).user_id)!;
const ownApplication = (db: Db, applicationId: string) => {
  const app = db.applications.find(a => a.application_id === applicationId);
  if (!app || !ownProfile(db, app.student_id)) throw new Error("Application not found.");
  return app;
};

// UC10 / dialog map §5: the only allowed status moves.
export const nextStatuses: Record<ApplicationStatus, ApplicationStatus[]> = {
  Draft: ["Submitted"], Submitted: ["UnderReview"], UnderReview: ["Offered", "Rejected"], Offered: ["Accepted"], Rejected: [], Accepted: [],
};

type LocalApi = Pick<typeof api,
  "registerAccount" | "login" | "logout" | "getCurrentUser" | "getNotificationPreference" | "updateNotificationPreference" |
  "listProfiles" | "createProfile" | "editProfile" | "removeProfile" | "listSubjects" | "listCcas" |
  "getShortlist" | "addToShortlist" | "removeFromShortlist" |
  "listApplications" | "createApplication" | "getApplication" | "updateApplication" | "updateApplicationStatus" | "setDeadline" | "clearDeadline" |
  "listNotifications" | "markNotificationRead">;

export const localApi: LocalApi = {
  // M1 Accounts
  registerAccount: body => tx(db => {
    if (db.users.some(u => u.email.toLowerCase() === body.email.toLowerCase())) throw new Error("An account with this email already exists.");
    const user: StoredUser = { user_id: id(), name: body.name, email: body.email, password: body.password, preferred_postal_code: body.preferred_postal_code || null, notification_opt_in: body.notification_opt_in ?? false, failed: 0, locked_until: 0 };
    db.users.push(user);
    return publicUser(user);
  }),
  login: (email, password) => tx(db => {
    const user = db.users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (user && user.locked_until > Date.now()) throw Object.assign(new Error("account_locked"), { lockedUntil: user.locked_until });
    if (!user || user.password !== password) {
      if (user) { user.failed += 1; if (user.failed >= 5) { user.locked_until = Date.now() + 15 * 60_000; user.failed = 0; } }
      return null;
    }
    user.failed = 0; user.locked_until = 0; db.session = user.user_id;
    return publicUser(user);
  }).then(user => {
    if (user) return user;
    // Re-read so the lock set by the fifth failure is reported straight away (DM-07).
    const locked = load().users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (locked && locked.locked_until > Date.now()) throw Object.assign(new Error("account_locked"), { lockedUntil: locked.locked_until });
    throw new Error("Incorrect email or password.");
  }),
  logout: () => tx(db => { db.session = null; }),
  getCurrentUser: () => tx(db => publicUser(me(db))),
  getNotificationPreference: () => tx(db => ({ notification_opt_in: me(db).notification_opt_in })),
  updateNotificationPreference: optIn => tx(db => { me(db).notification_opt_in = optIn; return { notification_opt_in: optIn }; }),

  // M2 Student profiles
  listProfiles: () => tx(db => db.profiles.filter(p => p.user_id === me(db).user_id)),
  createProfile: (body: ProfileInput) => tx(db => {
    const profile = { ...body, student_id: id(), user_id: me(db).user_id };
    db.profiles.push(profile);
    db.shortlists[profile.student_id] = [];
    return profile;
  }),
  editProfile: (studentId, body) => tx(db => Object.assign(ownProfile(db, studentId), body)),
  removeProfile: studentId => tx(db => {
    ownProfile(db, studentId);
    if (db.applications.some(a => a.student_id === studentId) || db.shortlists[studentId]?.length)
      throw new Error("This profile still has shortlisted schools or applications. Remove them first.");
    db.profiles = db.profiles.filter(p => p.student_id !== studentId);
    delete db.shortlists[studentId];
  }),
  listSubjects: () => Promise.resolve(demoSubjects),
  listCcas: () => Promise.resolve(demoCcas),

  // M5 Shortlist
  getShortlist: studentId => tx(db => {
    const profile = ownProfile(db, studentId);
    return { shortlist_id: studentId, name: `${profile.name ?? "Student"}'s shortlist`, notes: null, entries: (db.shortlists[studentId] ?? []).map((e, i) => ({ entry_id: e.entry_id, date_added: e.date_added, rank: i + 1, school: summary(e.school_id) })) };
  }),
  addToShortlist: (studentId, schoolId) => tx(db => {
    ownProfile(db, studentId);
    const list = db.shortlists[studentId] ??= [];
    const entry = list.find(e => e.school_id === schoolId) ?? { entry_id: id(), school_id: schoolId, date_added: new Date().toISOString() };
    if (!list.includes(entry)) list.push(entry);
    return { entry_id: entry.entry_id, date_added: entry.date_added, rank: list.length, school: summary(schoolId) };
  }),
  removeFromShortlist: (studentId, entryId) => tx(db => {
    ownProfile(db, studentId);
    db.shortlists[studentId] = db.shortlists[studentId].filter(e => e.entry_id !== entryId);
  }),

  // M6 Applications
  listApplications: studentId => tx(db => {
    const mine = db.profiles.filter(p => p.user_id === me(db).user_id).map(p => p.student_id);
    return db.applications.filter(a => studentId ? a.student_id === studentId : mine.includes(a.student_id)).map(toApplication);
  }),
  createApplication: (studentId, schoolId, notes) => tx(db => {
    ownProfile(db, studentId);
    if (db.applications.some(a => a.student_id === studentId && a.school_id === schoolId)) throw new Error("This student already has an application for this school.");
    const app: StoredApplication = { application_id: id(), student_id: studentId, school_id: schoolId, status: "Draft", date_submitted: null, deadline: null, notes: notes || null, updated_at: new Date().toISOString() };
    db.applications.push(app);
    return toApplication(app);
  }),
  getApplication: applicationId => tx(db => toApplication(ownApplication(db, applicationId))),
  updateApplication: (applicationId, notes) => tx(db => {
    const app = ownApplication(db, applicationId);
    Object.assign(app, { notes, updated_at: new Date().toISOString() });
    return toApplication(app);
  }),
  updateApplicationStatus: (applicationId, status) => tx(db => {
    const app = ownApplication(db, applicationId);
    if (!nextStatuses[app.status].includes(status)) throw new Error(`An application cannot move from ${app.status} to ${status}.`);
    Object.assign(app, { status, updated_at: new Date().toISOString(), date_submitted: status === "Submitted" ? isoDate(0) : app.date_submitted });
    return toApplication(app);
  }),
  setDeadline: (applicationId, deadline) => tx(db => {
    const app = ownApplication(db, applicationId);
    Object.assign(app, { deadline, updated_at: new Date().toISOString() });
    return toApplication(app);
  }),
  clearDeadline: applicationId => tx(db => {
    const app = ownApplication(db, applicationId);
    Object.assign(app, { deadline: null, updated_at: new Date().toISOString() });
    return toApplication(app);
  }),

  // M7 Notifications: reminders for deadlines from today to today + 7 days (ARC-02 §3.7.4), only when opted in.
  listNotifications: () => tx(db => {
    if (!me(db).notification_opt_in) return [];
    const mine = db.profiles.filter(p => p.user_id === me(db).user_id).map(p => p.student_id);
    return db.applications
      .filter(a => mine.includes(a.student_id) && a.deadline && a.deadline >= isoDate(0) && a.deadline <= isoDate(7))
      .sort((a, b) => a.deadline!.localeCompare(b.deadline!))
      .map((a): Notification => {
        const reminder_id = `${a.application_id}:${a.deadline}`;
        return { reminder_id, application_id: a.application_id, remind_for_deadline: a.deadline!, sent_at: isoDate(0), is_read: db.read.includes(reminder_id) };
      });
  }),
  markNotificationRead: reminderId => tx(db => {
    if (!db.read.includes(reminderId)) db.read.push(reminderId);
    const [application_id, deadline] = reminderId.split(":");
    return { reminder_id: reminderId, application_id, remind_for_deadline: deadline, sent_at: isoDate(0), is_read: true };
  }),
};
