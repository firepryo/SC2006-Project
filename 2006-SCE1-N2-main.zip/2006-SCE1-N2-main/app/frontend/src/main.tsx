// SPA entry point: mounts <App /> inside the router and the shared context providers (ARC-02 §3.6).
import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App";
import "./i18n";
import { AuthProvider } from "./context/AuthContext";
import { ActiveStudentProvider } from "./context/ActiveStudentContext";
import { ComparisonSelectionProvider } from "./context/ComparisonSelectionContext";
import { DirectoryProvider } from "./context/DirectoryContext";
import "./styles.css";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <BrowserRouter>
      <AuthProvider>
        <ActiveStudentProvider>
          <ComparisonSelectionProvider>
            <DirectoryProvider><App /></DirectoryProvider>
          </ComparisonSelectionProvider>
        </ActiveStudentProvider>
      </AuthProvider>
    </BrowserRouter>
  </React.StrictMode>,
);
