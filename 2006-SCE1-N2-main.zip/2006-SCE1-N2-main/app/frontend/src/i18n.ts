// Localisation set-up (NFR 3.1.3, ARC-02 §3.6).
import i18n from "i18next";
import { initReactI18next } from "react-i18next";

// TODO(NFR 3.1.3): add translation resources per language
i18n.use(initReactI18next).init({
  lng: "en",
  fallbackLng: "en",
  resources: { en: { translation: {} } },
  interpolation: { escapeValue: false },
});

export default i18n;
