// Typed calls to every endpoint in ARC-02 §4.1. Pages call these; nothing else talks to the API.
import type {
  Application,
  ApplicationStatus,
  Cca,
  ComparisonResult,
  Notification,
  ProfileInput,
  SchoolDetails,
  SchoolRoute,
  SchoolSummary,
  SearchCriteria,
  Shortlist,
  ShortlistEntry,
  StudentProfile,
  Subject,
  UserAccount,
  UUID,
} from "./types";

const API_PREFIX = "/api";

/** Send one request with the JWT cookie and CSRF header; throw the ARC-02 §4.2 ApiError on non-2xx. */
async function request<T>(method: string, path: string, body?: unknown): Promise<T> {
  const csrf = document.cookie.split("; ").find(cookie => cookie.startsWith("csrf_access_token="))?.split("=").slice(1).join("=");
  const response = await fetch(API_PREFIX + path, {
    method, credentials: "include",
    headers: { "Accept": "application/json", ...(body !== undefined ? { "Content-Type": "application/json" } : {}), ...(csrf && method !== "GET" ? { "X-CSRF-TOKEN": decodeURIComponent(csrf) } : {}) },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  if (!response.ok) {
    const error = await response.json().catch(() => ({}));
    throw new Error(error.message ?? `The request failed (${response.status}). Please try again.`);
  }
  return response.status === 204 ? undefined as T : response.json();
}

// M1 Accounts: UC01, UC02, UC07a, UC14
export const registerAccount = (body: {
  name: string;
  email: string;
  password: string;
  preferred_postal_code?: string;
  notification_opt_in?: boolean;
}) => request<UserAccount>("POST", "/auth/register", body);
export const login = (email: string, password: string) => request<UserAccount>("POST", "/auth/login", { email, password });
export const logout = () => request<void>("POST", "/auth/logout");
export const getCurrentUser = () => request<UserAccount>("GET", "/auth/me");
export const updateHomeLocation = (preferred_postal_code: string) =>
  request<UserAccount>("PATCH", "/users/me", { preferred_postal_code });
export const getNotificationPreference = () =>
  request<{ notification_opt_in: boolean }>("GET", "/users/me/notification-preference");
export const updateNotificationPreference = (notification_opt_in: boolean) =>
  request<{ notification_opt_in: boolean }>("PUT", "/users/me/notification-preference", { notification_opt_in });

// M2 Student profiles: UC03
export const listProfiles = () => request<StudentProfile[]>("GET", "/profiles");
export const createProfile = (body: ProfileInput) => request<StudentProfile>("POST", "/profiles", body);
export const getProfile = (studentId: UUID) => request<StudentProfile>("GET", `/profiles/${studentId}`);
export const editProfile = (studentId: UUID, body: ProfileInput) =>
  request<StudentProfile>("PUT", `/profiles/${studentId}`, body);
export const removeProfile = (studentId: UUID) => request<void>("DELETE", `/profiles/${studentId}`);
export const listSubjects = () => request<Subject[]>("GET", "/subjects");
export const listCcas = () => request<Cca[]>("GET", "/ccas");

// M3 School discovery and M4 Comparison: UC04–UC07
export const searchSchools = (criteria: SearchCriteria): Promise<SchoolSummary[]> => {
  const params = new URLSearchParams();
  Object.entries(criteria).forEach(([key, value]) => { if (value) params.set(key, value); });
  return request("GET", `/schools?${params}`);
};
export const getSchoolDetails = (schoolId: UUID) => request<SchoolDetails>("GET", `/schools/${schoolId}`);
export const getSchoolRoute = (schoolId: UUID) => request<SchoolRoute>("GET", `/schools/${schoolId}/route`);
export const compareSchools = (school_ids: UUID[], student_id?: UUID) =>
  request<ComparisonResult>("POST", "/schools/compare", { school_ids, student_id });
export const getDataFreshness = () => request<{ last_successful_sync: string | null }>("GET", "/data-freshness");

// M5 Shortlist: UC08
export const getShortlist = (studentId: UUID) => request<Shortlist>("GET", `/profiles/${studentId}/shortlist`);
export const addToShortlist = (studentId: UUID, school_id: UUID) =>
  request<ShortlistEntry>("POST", `/profiles/${studentId}/shortlist/entries`, { school_id });
export const removeFromShortlist = (studentId: UUID, entryId: UUID) =>
  request<void>("DELETE", `/profiles/${studentId}/shortlist/entries/${entryId}`);

// M6 Applications: UC09, UC10, UC13
export const listApplications = (studentId?: UUID) =>
  request<Application[]>("GET", studentId ? `/applications?student_id=${studentId}` : "/applications");
export const createApplication = (student_id: UUID, school_id: UUID, notes?: string) =>
  request<Application>("POST", "/applications", { student_id, school_id, notes });
export const getApplication = (applicationId: UUID) => request<Application>("GET", `/applications/${applicationId}`);
export const updateApplication = (applicationId: UUID, notes: string | null) =>
  request<Application>("PATCH", `/applications/${applicationId}`, { notes });
export const updateApplicationStatus = (applicationId: UUID, status: ApplicationStatus) =>
  request<Application>("PATCH", `/applications/${applicationId}/status`, { status });
export const setDeadline = (applicationId: UUID, deadline: string) =>
  request<Application>("PUT", `/applications/${applicationId}/deadline`, { deadline });
export const clearDeadline = (applicationId: UUID) =>
  request<Application>("DELETE", `/applications/${applicationId}/deadline`);

// M7 Notifications: UC11
export const listNotifications = () => request<Notification[]>("GET", "/notifications");
export const markNotificationRead = (reminderId: UUID) =>
  request<Notification>("PATCH", `/notifications/${reminderId}/read`);
