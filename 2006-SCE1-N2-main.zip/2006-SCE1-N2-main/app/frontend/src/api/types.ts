// Shapes the SPA expects from the API. Names follow DATA-01; exact bodies are fixed in the API- documents.

export type UUID = string;
export type EducationLevel = "Primary" | "Secondary" | "JuniorCollege";
export type SchoolType = EducationLevel | "MixedLevels";
export type CcaCategory = "Sports" | "PerformingArts" | "UniformedGroup" | "ClubSociety" | "Others";
export type ApplicationStatus = "Draft" | "Submitted" | "UnderReview" | "Offered" | "Rejected" | "Accepted";

export interface ApiError {
  error: string; // ARC-02 §4.2 error code, e.g. "account_locked"
  message: string;
  details?: Record<string, unknown>;
}

export interface UserAccount {
  user_id: UUID;
  name: string;
  email: string;
  preferred_postal_code: string | null;
  notification_opt_in: boolean;
}

export interface Subject {
  subject_id: UUID;
  subject_name: string;
  level: EducationLevel;
  is_special_programme: boolean;
}

export interface Cca {
  cca_id: UUID;
  cca_name: string;
  category: CcaCategory;
}

export interface StudentProfile {
  student_id: UUID;
  name: string | null;
  current_level: EducationLevel;
  current_year: number;
  preferred_subject_ids: UUID[];
  preferred_cca_ids: UUID[];
}

export type ProfileInput = Omit<StudentProfile, "student_id">;

export interface SchoolSummary {
  school_id: UUID;
  name: string;
  type: SchoolType;
  address: string;
  zone: string | null;
  planning_area: string | null;
  distance_km?: number | null; // search results: straight-line km from home; null without a home postal code
}

export interface LatLng {
  lat: number;
  lng: number;
}

// GET /api/schools/<id>/route: the school and home on the OneMap map, with the road route between them.
export interface SchoolRoute {
  school: LatLng;
  home: LatLng | null;
  distance_km: number | null;
  duration_min: number | null;
  straight_line_km: number | null;
  path: number[][];
  route_type: string;
  note: string | null;
}

export interface Affiliation {
  affiliation_id: UUID;
  feeder_school_id: UUID;
  receiving_school_id: UUID;
  priority_description: string | null;
}

export interface SchoolDetails extends SchoolSummary {
  postal_code: string | null;
  website: string | null;
  telephone: string | null;
  email: string | null;
  description: string | null;
  subjects: Subject[];
  ccas: Cca[];
  affiliations: Affiliation[];
}

export interface SearchCriteria {
  q?: string;
  level?: EducationLevel;
  zone?: string;
  planning_area?: string;
  subject_id?: UUID;
  cca_id?: UUID;
}

export interface CriterionResult {
  criterion_id: number; // 1 Distance, 2 Subject Match, 3 CCA Match, 4 Affiliation
  value: unknown;
  available: boolean; // false is shown as "Not available" (FR 7.8)
  note: string | null;
}

export interface ComparisonResult {
  schools: SchoolSummary[];
  rows: Record<number, CriterionResult[]>;
  personalised: boolean;
}

export interface ShortlistEntry {
  entry_id: UUID;
  school: SchoolSummary;
  date_added: string;
  rank: number | null;
}

export interface Shortlist {
  shortlist_id: UUID;
  name: string;
  notes: string | null;
  entries: ShortlistEntry[];
}

export interface Application {
  application_id: UUID;
  student_id: UUID;
  school: SchoolSummary;
  status: ApplicationStatus;
  date_submitted: string | null;
  deadline: string | null;
  notes: string | null;
  updated_at: string;
}

export interface Notification {
  reminder_id: UUID;
  application_id: UUID;
  remind_for_deadline: string;
  sent_at: string;
  is_read: boolean; // pending ARC-02 Q1
}
