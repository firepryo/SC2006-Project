// Class diagram: NotificationPreferencesUI «boundary» (UC14). Dialog map DM-70: Turn On / Turn Off.
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { backend } from "../data/backend";
import { useLoad } from "../hooks/useLoad";
import { Icon } from "../components/Icon";

export default function NotificationPreferencesUI() {
  const { data } = useLoad(() => backend.getNotificationPreference(), []);
  const [optIn, setOptIn] = useState<boolean | null>(null);
  const [saved, setSaved] = useState("");
  useEffect(() => { document.title = "Reminder settings · Schoolwise"; }, []);
  if (!data) return null;
  const current = optIn ?? data.notification_opt_in;
  const change = async (value: boolean) => {
    setOptIn((await backend.updateNotificationPreference(value)).notification_opt_in);
    setSaved(value ? "Deadline reminders turned on." : "Deadline reminders turned off.");
  };

  return <>
    <Link className="back-link" to="/notifications"><Icon name="back" size={17}/>Notifications</Link>
    <div className="page-heading"><h1>Reminder settings</h1></div>
    <div className="panel form-panel narrow">
      <fieldset className="radio-group"><legend>Application deadline reminders</legend>
        <label className="radio-row"><input type="radio" name="reminders" checked={current} onChange={() => change(true)}/><span>On: remind me 7 days before each deadline</span></label>
        <label className="radio-row"><input type="radio" name="reminders" checked={!current} onChange={() => change(false)}/><span>Off</span></label>
      </fieldset>
      {saved && <p className="saved-text" role="status"><Icon name="check" size={16}/>{saved}</p>}
    </div>
  </>;
}
