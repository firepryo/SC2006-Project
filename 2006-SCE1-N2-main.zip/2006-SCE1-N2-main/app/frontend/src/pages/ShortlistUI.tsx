// Class diagram: ShortlistUI «boundary» (UC08). Dialog map DM-50 to DM-53; DM-50 -> DM-62 / DM-65.
import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useActiveStudent } from "../context/ActiveStudentContext";
import { useDirectory } from "../context/DirectoryContext";
import { backend, formatDate } from "../data/backend";
import { levelLabel } from "../data/schoolDirectory";
import { useLoad } from "../hooks/useLoad";
import { CompareButton } from "../components/SchoolActions";
import { EmptySelection } from "../components/PageState";
import { StatusBadge } from "../components/StatusBadge";

export default function ShortlistUI() {
  const { activeStudent } = useActiveStudent();
  const { entries, toggleSaved, searchPath } = useDirectory();
  const navigate = useNavigate();
  const studentId = activeStudent!.student_id;
  const { data: applications = [] } = useLoad(() => backend.listApplications(studentId), [studentId]);
  const [confirm, setConfirm] = useState("");
  useEffect(() => { window.scrollTo(0, 0); document.title = "Shortlist · Schoolwise"; }, []);
  const apply = async (schoolId: string) => navigate(`/applications/${(await backend.createApplication(studentId, schoolId)).application_id}`);

  return <>
    <div className="page-heading"><h1>{activeStudent!.name}’s shortlist</h1></div>
    {!entries.length ? <EmptySelection title="Nothing on the shortlist yet" searchPath={searchPath}>Use the bookmark on any school to keep it here for {activeStudent!.name ?? "this student"}.</EmptySelection> : <div className="table-wrap"><table className="data-table">
      <thead><tr><th>School</th><th>Level</th><th>Area</th><th>Added</th><th>Application</th><th/></tr></thead>
      <tbody>{entries.map(e => {
        const application = applications.find(a => a.school.school_id === e.school.school_id);
        return <tr key={e.entry_id}>
          <td><Link className="table-link" to={`/schools/${e.school.school_id}`}>{e.school.name}</Link></td>
          <td data-label="Level">{levelLabel[e.school.type]}</td>
          <td data-label="Area">{e.school.planning_area}</td>
          <td data-label="Added">{formatDate(e.date_added)}</td>
          <td data-label="Application">{application ? <Link to={`/applications/${application.application_id}`}><StatusBadge status={application.status}/></Link> : <button className="text-button" onClick={() => apply(e.school.school_id)}>Start application</button>}</td>
          <td className="row-buttons">{confirm === e.entry_id
            ? <><span>Remove {e.school.name}?</span><button className="text-button danger" onClick={() => { toggleSaved(e.school.school_id); setConfirm(""); }}>Remove</button><button className="text-button" onClick={() => setConfirm("")}>Cancel</button></>
            : <><CompareButton id={e.school.school_id} name={e.school.name} compact/><button className="text-button muted-button" onClick={() => setConfirm(e.entry_id)}>Remove</button></>}</td>
        </tr>;
      })}</tbody>
    </table></div>}
  </>;
}
