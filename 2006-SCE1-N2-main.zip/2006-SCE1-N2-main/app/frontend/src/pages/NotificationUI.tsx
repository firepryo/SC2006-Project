// Class diagram: NotificationUI «boundary» (UC11). Dialog map DM-69, DM-70.
// Stored deadline reminders, nearest first; opening one goes to its application (DM-69 -> DM-65).
import { useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { backend, dueLabel, formatDay } from "../data/backend";
import { useLoad } from "../hooks/useLoad";
import { Icon } from "../components/Icon";

export default function NotificationUI() {
  const navigate = useNavigate();
  const { data } = useLoad(async () => ({
    reminders: await backend.listNotifications(),
    applications: await backend.listApplications(),
    optIn: (await backend.getNotificationPreference()).notification_opt_in,
  }), []);
  useEffect(() => { document.title = "Notifications · Schoolwise"; }, []);
  if (!data) return null;
  const open = async (reminderId: string, applicationId: string) => { await backend.markNotificationRead(reminderId); navigate(`/applications/${applicationId}`); };

  return <>
    <div className="page-heading heading-with-action"><div><h1>Notifications</h1><p>Reminders for application deadlines in the next 7 days.</p></div><Link className="button button-secondary" to="/notifications/preferences">Reminder settings</Link></div>
    {!data.optIn ? <div className="empty-state"><Icon name="info" size={30}/><h2>Deadline reminders are off</h2><p>Turn them on to hear about each application deadline a week before it’s due.</p><Link className="button button-primary" to="/notifications/preferences">Turn on reminders</Link></div>
      : !data.reminders.length ? <div className="empty-state"><Icon name="check" size={30}/><h2>Nothing due in the next 7 days</h2><p>A reminder appears here when an application deadline is a week away.</p><Link className="button button-secondary" to="/applications">View applications</Link></div>
      : <ul className="notification-list">{data.reminders.map(r => {
        const app = data.applications.find(a => a.application_id === r.application_id);
        return <li key={r.reminder_id} className={r.is_read ? "" : "unread"}>
          <p className="notification-date">{formatDay(r.remind_for_deadline)}<small>{dueLabel(r.remind_for_deadline)}</small></p>
          <div><strong>{app?.school.name}</strong>{!r.is_read && <span className="tag tag-new">New</span>}<p>Application deadline {dueLabel(r.remind_for_deadline)}</p></div>
          <button className="button button-secondary button-small" onClick={() => open(r.reminder_id, r.application_id)}>Open application</button>
        </li>;
      })}</ul>}
  </>;
}
