// Class diagram: StudentProfileUI «boundary» (UC03). Dialog map DM-20 to DM-28.
import { useEffect, useState, type FormEvent } from "react";
import { useNavigate } from "react-router-dom";
import type { EducationLevel, ProfileInput, StudentProfile } from "../api/types";
import { useActiveStudent } from "../context/ActiveStudentContext";
import { backend } from "../data/backend";
import { levelLabel } from "../data/schoolDirectory";
import { useLoad } from "../hooks/useLoad";
import { Icon } from "../components/Icon";

const maxYear: Record<EducationLevel, number> = { Primary: 6, Secondary: 5, JuniorCollege: 2 };
const blank: ProfileInput = { name: "", current_level: "Primary", current_year: 1, preferred_subject_ids: [], preferred_cca_ids: [] };

export default function StudentProfileUI() {
  const { profiles, profilesLoaded, activeStudent, setActiveStudent, refreshProfiles } = useActiveStudent();
  const navigate = useNavigate();
  const { data: refs } = useLoad(async () => ({ subjects: await backend.listSubjects(), ccas: await backend.listCcas() }), []);
  const [editing, setEditing] = useState<StudentProfile | "new" | null>(null);
  const [form, setForm] = useState<ProfileInput>(blank);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [confirmRemove, setConfirmRemove] = useState("");
  useEffect(() => { document.title = "Student profiles · Schoolwise"; }, []);
  useEffect(() => { if (profilesLoaded && !profiles.length) open("new"); }, [profilesLoaded, profiles.length]);

  function open(target: StudentProfile | "new") {
    setEditing(target); setError(""); setMessage("");
    setForm(target === "new" ? blank : { name: target.name, current_level: target.current_level, current_year: target.current_year, preferred_subject_ids: target.preferred_subject_ids, preferred_cca_ids: target.preferred_cca_ids });
  }
  const toggle = (key: "preferred_subject_ids" | "preferred_cca_ids", id: string) =>
    setForm({ ...form, [key]: form[key].includes(id) ? form[key].filter(x => x !== id) : [...form[key], id] });

  const save = async (event: FormEvent) => {
    event.preventDefault();
    const firstProfile = !profiles.length;
    const saved = editing === "new" ? await backend.createProfile(form) : await backend.editProfile((editing as StudentProfile).student_id, form);
    await refreshProfiles();
    setActiveStudent(saved.student_id);
    setEditing(null);
    if (firstProfile) return navigate("/schools"); // DM-20 -> DM-30 saveProfileAndFindSchools
    setMessage(`${saved.name ?? "Profile"} saved and selected.`);
  };
  const remove = async (profile: StudentProfile) => {
    setConfirmRemove(""); setMessage(""); setError("");
    try { await backend.removeProfile(profile.student_id); await refreshProfiles(); setMessage(`${profile.name ?? "Profile"} removed.`); }
    catch (e) { setError((e as Error).message); }
  };

  return <>
    <div className="page-heading heading-with-action"><div><h1>Students</h1><p>Each child keeps their own shortlist and applications.</p></div>{profiles.length > 0 && editing !== "new" && <button className="button button-secondary" onClick={() => open("new")}><Icon name="plus" size={17}/>Add student</button>}</div>
    {message && <p className="form-success" role="status">{message}</p>}
    {error && <p className="form-error" role="alert">{error}</p>}
    {profiles.length > 0 && <div className="table-wrap"><table className="data-table">
      <thead><tr><th>Name</th><th>Level</th><th>Preferred subjects</th><th>Preferred CCAs</th><th/></tr></thead>
      <tbody>{profiles.map(p => <tr key={p.student_id} className={p.student_id === activeStudent?.student_id ? "is-active" : ""}>
        <td><strong>{p.name ?? "Unnamed"}</strong>{p.student_id === activeStudent?.student_id && <span className="tag">Selected</span>}</td>
        <td data-label="Level">{levelLabel[p.current_level]} {p.current_year}</td>
        <td data-label="Subjects">{refs?.subjects.filter(s => p.preferred_subject_ids.includes(s.subject_id)).map(s => s.subject_name).join(", ") || "—"}</td>
        <td data-label="CCAs">{refs?.ccas.filter(c => p.preferred_cca_ids.includes(c.cca_id)).map(c => c.cca_name).join(", ") || "—"}</td>
        <td className="row-buttons">{confirmRemove === p.student_id
          ? <><span>Remove {p.name}?</span><button className="text-button danger" onClick={() => remove(p)}>Remove</button><button className="text-button" onClick={() => setConfirmRemove("")}>Cancel</button></>
          : <>{p.student_id !== activeStudent?.student_id && <button className="text-button" onClick={() => setActiveStudent(p.student_id)}>Select</button>}<button className="text-button" onClick={() => open(p)}>Edit</button><button className="text-button muted-button" onClick={() => setConfirmRemove(p.student_id)}>Remove</button></>}
        </td>
      </tr>)}</tbody>
    </table></div>}
    {editing && <form className="panel form-panel" onSubmit={save}>
      <h2>{editing === "new" ? (profiles.length ? "Add student" : "Add your first student") : `Edit ${editing.name ?? "student"}`}</h2>
      <div className="form-row">
        <label className="field"><span>Name</span><input required value={form.name ?? ""} onChange={e => setForm({ ...form, name: e.target.value })}/></label>
        <label className="field"><span>Current level</span><select value={form.current_level} onChange={e => setForm({ ...form, current_level: e.target.value as EducationLevel, current_year: 1 })}>{Object.keys(maxYear).map(l => <option key={l} value={l}>{levelLabel[l]}</option>)}</select></label>
        <label className="field"><span>Year</span><select value={form.current_year} onChange={e => setForm({ ...form, current_year: Number(e.target.value) })}>{Array.from({ length: maxYear[form.current_level] }, (_, i) => <option key={i} value={i + 1}>{i + 1}</option>)}</select></label>
      </div>
      <fieldset className="choice-grid"><legend>Preferred subjects</legend>{refs?.subjects.filter(s => s.level === form.current_level || form.preferred_subject_ids.includes(s.subject_id)).map(s => <label key={s.subject_id} className="checkbox-label"><input type="checkbox" checked={form.preferred_subject_ids.includes(s.subject_id)} onChange={() => toggle("preferred_subject_ids", s.subject_id)}/>{s.subject_name}</label>)}</fieldset>
      <fieldset className="choice-grid"><legend>Preferred CCAs</legend>{refs?.ccas.map(c => <label key={c.cca_id} className="checkbox-label"><input type="checkbox" checked={form.preferred_cca_ids.includes(c.cca_id)} onChange={() => toggle("preferred_cca_ids", c.cca_id)}/>{c.cca_name}</label>)}</fieldset>
      <div className="form-actions"><button className="button button-primary">Save profile</button>{profiles.length > 0 && <button type="button" className="button button-secondary" onClick={() => setEditing(null)}>Cancel</button>}</div>
    </form>}
  </>;
}
