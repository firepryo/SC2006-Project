// Public landing page (signed out). Signed-in visitors go straight to their home page.
import { useEffect } from "react";
import { Link, Navigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { BrandMark } from "../components/Icon";
import { ThemeToggle } from "../components/ThemeToggle";

const tickerWords = ["Subjects", "CCAs", "Distance from home", "Affiliations", "Shortlists", "Applications", "Deadlines", "Reminders"];

const steps = [
  { title: "Search", text: "Find schools by name, then narrow by level, zone, subject or co-curricular activity." },
  { title: "Compare", text: "Line up to five schools. Rows that differ are flagged, so you read the differences first." },
  { title: "Shortlist", text: "Each child keeps their own shortlist, so siblings’ searches never get mixed up." },
  { title: "Apply on time", text: "Track each application from draft to offer, with a reminder seven days before every deadline." },
];

// A small static example of the comparison view, using the app's fictional sample schools.
const preview = {
  schools: ["Cedarbrook Secondary", "Greenhaven Secondary", "Dover Grove Secondary"],
  distance: ["2.4", "1.8", "4.6"],
  subjects: [["English", "Mathematics", "Computing", "History"], ["English", "Mathematics", "Art", "Computing"], ["English", "Mathematics", "Biology", "Geography"]],
  shared: ["English", "Mathematics"],
};

export default function LandingUI() {
  const { user, ready } = useAuth();
  useEffect(() => { document.title = "Schoolwise: every school, side by side"; }, []);
  if (ready && user) return <Navigate to="/home" replace />;

  return <div className="landing">
    <a className="skip-link" href="#landing-main">Skip to content</a>
    <header className="landing-header page-width">
      <Link to="/" className="brand" aria-label="Schoolwise home"><BrandMark/><span>Schoolwise</span></Link>
      <nav className="landing-nav" aria-label="Main navigation">
        <a href="#how" className="landing-nav-link">How it works</a>
        <a href="#compare" className="landing-nav-link">Compare</a>
        <Link to="/login" className="landing-nav-link">Log in</Link>
        <Link to="/register" className="button button-primary button-small">Create account</Link>
        <ThemeToggle/>
      </nav>
    </header>

    <main id="landing-main">
      <section className="hero page-width" aria-labelledby="hero-title">
        <p className="kicker">— Primary 1 to junior college / Singapore</p>
        <h1 id="hero-title" className="hero-title">Every school,<br/>side by <em>side.</em></h1>
        <p className="hero-sub">Compare subjects, CCAs and distance from home across up to five schools at once. Keep a shortlist for each child, and get a reminder a week before every application deadline.</p>
        <div className="hero-actions">
          <Link to="/register" className="button button-primary">Create an account</Link>
          <Link to="/login" className="text-link">I already have one</Link>
        </div>
        <p className="scroll-cue" aria-hidden="true">Scroll to see</p>
        <p className="hero-numeral" aria-hidden="true"><span className="outline">05</span><small>schools, side by side</small></p>
      </section>

      <div className="ticker" aria-hidden="true"><div className="ticker-track">
        {[0, 1].map(copy => <span key={copy}>{tickerWords.map(word => <span key={word}>{word}<i>•</i></span>)}</span>)}
      </div></div>

      <section id="how" className="landing-section page-width" aria-labelledby="how-title">
        <p className="kicker">— How it works</p>
        <h2 id="how-title" className="section-title">From a long list<br/>to <em>one choice.</em></h2>
        <ol className="step-list">{steps.map((step, i) => <li key={step.title}>
          <span className="step-num" aria-hidden="true">{String(i + 1).padStart(2, "0")}</span>
          <h3>{step.title}</h3>
          <p>{step.text}</p>
        </li>)}</ol>
      </section>

      <section id="compare" className="landing-section preview page-width" aria-labelledby="compare-title">
        <div className="preview-copy">
          <p className="kicker">— The comparison</p>
          <h2 id="compare-title" className="section-title">The differences,<br/><em>flagged.</em></h2>
          <p>Rows that vary between schools are marked. Inside them, whatever every school shares fades back, so what sets one school apart is what you read first.</p>
        </div>
        <figure className="preview-card" aria-label="Example comparison of three sample schools">
          <div className="preview-grid" style={{ gridTemplateColumns: `minmax(92px, .8fr) repeat(${preview.schools.length}, minmax(0, 1fr))` }}>
            <span/>
            {preview.schools.map(name => <strong key={name} className="preview-school">{name}</strong>)}
            <span className="preview-label">Distance<em className="differs-tag">Differs</em></span>
            {preview.distance.map((km, i) => <span key={i} className="distance-value">{km}<span>km</span></span>)}
            <span className="preview-label">Subjects<em className="differs-tag">Differs</em></span>
            {preview.subjects.map((list, i) => <ul key={i} className="cell-list">{list.map(item => <li key={item} className={preview.shared.includes(item) ? "shared" : "unique"}>{item}</li>)}</ul>)}
          </div>
          <figcaption>An example comparison of three secondary schools.</figcaption>
        </figure>
      </section>

      <section className="closing page-width" aria-labelledby="closing-title">
        <h2 id="closing-title" className="closing-title">Every deadline,<br/><em>on time.</em></h2>
        <div className="closing-side">
          <p>Start with your child’s name and level. Everything after that is kept for them.</p>
          <Link to="/register" className="button button-primary">Create an account</Link>
        </div>
      </section>
    </main>

    <footer className="site-footer page-width"><span>School Comparison &amp; Shortlisting</span><span>Primary to junior college</span></footer>
  </div>;
}
