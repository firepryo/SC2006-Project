import { useEffect, useState, type ReactNode } from "react";
import { Link } from "react-router-dom";
import { useDirectory } from "../context/DirectoryContext";
import { useComparisonSelection, MAX_SCHOOLS } from "../context/ComparisonSelectionContext";
import { affiliationNames, isDemo, levelLabel, loadSchool } from "../data/schoolDirectory";
import { compareSchools } from "../api/client";
import type { DirectorySchool } from "../data/demoSchools";
import { useLoad } from "../hooks/useLoad";
import { EmptySelection, ErrorState, LoadingState } from "../components/PageState";
import { SaveButton } from "../components/SchoolActions";
import { Icon } from "../components/Icon";

// Items offered by every school are plain; items only some schools offer are highlighted.
// Shared items are matched by name: a subject has one row per level, so its id differs between levels.
function ItemList<T>({ items, id, name, shared }: { items: T[]; id: (item: T) => string; name: (item: T) => string; shared: Set<string> | null }) {
  if (!items.length) return <span className="unavailable">Not available</span>;
  return <ul className="cell-list">{items.map(item => <li key={id(item)} className={shared ? (shared.has(name(item)) ? "shared" : "unique") : undefined}>{name(item)}{shared && !shared.has(name(item)) && <span className="sr-only"> (not offered by every school)</span>}</li>)}</ul>;
}

// UC07a: the backend's Distance criterion is the OneMap road distance from home (straight line as a fallback).
interface DistanceValue { distance_km: number; travel_time_min: number | null; method: string }
type DistanceCell = { value: DistanceValue | null; note: string | null };

function DistanceCellView({ cell, fallbackKm }: { cell?: DistanceCell; fallbackKm?: number | null }) {
  if (isDemo) return fallbackKm != null ? <strong className="distance-value">{fallbackKm.toFixed(1)}<span>km</span></strong> : <span className="unavailable">Not available</span>;
  if (!cell) return <span className="muted">Loading…</span>;
  if (!cell.value) return <span className="unavailable">{cell.note === "Home location not set" ? <>Not available<span className="cell-note"><Link to="/home#home-location">Set home postal code</Link></span></> : "Not available"}</span>;
  const { distance_km, travel_time_min, method } = cell.value;
  return <><strong className="distance-value">{distance_km.toFixed(1)}<span>km</span></strong>
    <span className="cell-note">{method === "straight line" ? "straight line" : `by road${travel_time_min != null ? `, ~${travel_time_min} min` : ""}`} (OneMap)</span></>;
}

const intersect = (lists: string[][]) => lists.length ? new Set(lists.reduce((acc, list) => acc.filter(x => list.includes(x)))) : new Set<string>();

// UI-01 / UC07: aligned comparison, never synthetic personalised scores.
export default function SchoolComparisonUI() {
  const { searchPath } = useDirectory();
  const { selectedSchoolIds, removeSchool, clearSelection } = useComparisonSelection();
  const { data: schools = [], loading, error, retry } = useLoad(() => Promise.all(selectedSchoolIds.map(loadSchool)), [selectedSchoolIds.join(",")]);
  const [differencesOnly, setDifferencesOnly] = useState(false);
  const { data: distances = {} } = useLoad(async () => {
    if (isDemo || selectedSchoolIds.length < 2) return {} as Record<string, DistanceCell>;
    const result = await compareSchools(selectedSchoolIds);
    const cells = (result.rows[1] ?? []) as unknown as DistanceCell[];
    return Object.fromEntries(result.schools.map((s, i) => [s.school_id, cells[i]]));
  }, [selectedSchoolIds.join(",")]);
  useEffect(() => { window.scrollTo(0, 0); document.title = "Compare schools · Schoolwise"; }, []);

  const sharedSubjects = intersect(schools.map(s => s.subjects.map(x => x.subject_name)));
  const sharedCcas = intersect(schools.map(s => s.ccas.map(x => x.cca_name)));
  const rows: { label: string; key: (school: DirectorySchool) => string; render: (school: DirectorySchool, differs: boolean) => ReactNode }[] = [
    { label: "Education level", key: s => s.type, render: s => levelLabel[s.type] },
    { label: "Location", key: s => s.planning_area ?? "", render: s => <>{s.planning_area ?? "Not available"}<span className="cell-note">{s.zone} zone</span></> },
    { label: "Distance from home", key: s => String(isDemo ? s.distance_km : distances[s.school_id]?.value?.distance_km), render: s => <DistanceCellView cell={distances[s.school_id]} fallbackKm={s.distance_km}/> },
    { label: "Subjects offered", key: s => [...new Set(s.subjects.map(x => x.subject_name))].sort().join(","), render: (s, differs) => <ItemList items={s.subjects} id={x => x.subject_id} name={x => x.subject_name} shared={differs ? sharedSubjects : null}/> },
    { label: "Co-curricular activities", key: s => s.ccas.map(x => x.cca_id).sort().join(","), render: (s, differs) => <ItemList items={s.ccas} id={x => x.cca_id} name={x => x.cca_name} shared={differs ? sharedCcas : null}/> },
    { label: "Affiliated schools", key: s => affiliationNames(s).join(","), render: s => affiliationNames(s).length ? affiliationNames(s).join(", ") : <span className="muted">None recorded</span> },
  ];
  const withDiff = rows.map(row => ({ ...row, differs: new Set(schools.map(row.key)).size > 1 }));
  const visibleRows = differencesOnly ? withDiff.filter(row => row.differs) : withDiff;

  return <><Link className="back-link" to={searchPath}><Icon name="back" size={17}/>All schools</Link>
    <div className="page-heading heading-with-action"><h1>Compare schools</h1>{selectedSchoolIds.length > 0 && <button className="text-button muted-button" onClick={clearSelection}>Clear comparison</button>}</div>
    {selectedSchoolIds.length < 2 ? <>
      <EmptySelection title={selectedSchoolIds.length ? "Add one more school" : "Pick schools to compare"} searchPath={searchPath}>Choose 2 to 5 schools with the Compare button and they’ll line up here, side by side.</EmptySelection>
      {selectedSchoolIds.length === 1 && schools[0] && <div className="remaining-selection"><span>Selected so far: <strong>{schools[0].name}</strong></span><button className="text-button" onClick={() => removeSchool(schools[0].school_id)}>Remove</button></div>}
    </> : loading ? <LoadingState rows={3} label="Loading comparison"/> : error ? <ErrorState message={error} retry={retry}/> : <>
      <div className="comparison-toolbar">
        <span><strong>{schools.length} schools</strong> side by side</span>
        <div className="toolbar-end">
          <label className="checkbox-label"><input type="checkbox" checked={differencesOnly} onChange={event => setDifferencesOnly(event.target.checked)}/>Show only differences</label>
          {selectedSchoolIds.length < MAX_SCHOOLS && <Link className="text-link" to={searchPath}><Icon name="plus" size={16}/>Add a school</Link>}
        </div>
      </div>
      <p className="comparison-key">Rows marked “Differs” vary between these schools. In those rows, subjects and activities every school offers are dimmed, so the <span className="unique">ones that set a school apart</span> stand out.</p>
      <div className="comparison-scroll" tabIndex={0} role="region" aria-label="School comparison table">
        <table className="comparison-table" style={{ minWidth: 190 + schools.length * 240 }}>
          <caption className="sr-only">Comparison of {schools.map(s => s.name).join(", ")}</caption>
          <thead><tr>
            <th scope="col" className="criteria-header"><span>{visibleRows.length} of {rows.length} details</span></th>
            {schools.map(school => <th scope="col" key={school.school_id}>
              <div className="compare-school-top"><Link className="compare-school-name" to={`/schools/${school.school_id}`}>{school.name}</Link>
                <button className="icon-button" aria-label={`Remove ${school.name} from comparison`} onClick={() => removeSchool(school.school_id)}><Icon name="close" size={17}/></button></div>
              <span className="compare-school-level">{levelLabel[school.type]}, {school.planning_area}</span>
              <SaveButton id={school.school_id} name={school.name}/>
            </th>)}
          </tr></thead>
          <tbody>{visibleRows.length ? visibleRows.map(row => <tr key={row.label} className={row.differs ? "differs" : undefined}>
            <th scope="row">{row.label}{row.differs && <span className="differs-tag">Differs</span>}</th>
            {schools.map(school => <td key={school.school_id}>{row.render(school, row.differs)}</td>)}
          </tr>) : <tr><th scope="row">No differences</th><td colSpan={schools.length}>These schools match on every detail shown.</td></tr>}</tbody>
        </table>
      </div>
    </>}
  </>;
}
