// Class diagram: ApplicationStatusUI «boundary» (UC10). Dialog map DM-66, DM-67, status machine in DM-65.
// Only the next allowed statuses are offered; each change is confirmed before saving.
import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import type { ApplicationStatus } from "../api/types";
import { backend, nextStatuses, statusLabel } from "../data/backend";
import { useLoad } from "../hooks/useLoad";
import { Icon } from "../components/Icon";
import { StatusBadge } from "../components/StatusBadge";

export default function ApplicationStatusUI() {
  const { applicationId = "" } = useParams();
  const navigate = useNavigate();
  const { data: app } = useLoad(() => backend.getApplication(applicationId), [applicationId]);
  const [pending, setPending] = useState<ApplicationStatus | null>(null);
  const [error, setError] = useState("");
  useEffect(() => { document.title = "Update status · Schoolwise"; }, []);
  if (!app) return null;
  const options = nextStatuses[app.status];

  const confirm = async () => {
    try {
      await backend.updateApplicationStatus(applicationId, pending!);
      navigate(`/applications/${applicationId}`, { state: { message: `Status changed to ${statusLabel[pending!]}.` } });
    } catch (e) { setError((e as Error).message); setPending(null); }
  };

  return <>
    <Link className="back-link" to={`/applications/${applicationId}`}><Icon name="back" size={17}/>{app.school.name}</Link>
    <div className="page-heading"><h1>Update status</h1></div>
    <div className="panel form-panel narrow">
      <p className="current-status">Current status <StatusBadge status={app.status}/></p>
      {error && <p className="form-error" role="alert">{error}</p>}
      {!options.length ? <p className="muted">{statusLabel[app.status]} is a final status.</p>
        : pending ? <div className="confirm-box">
            <p>Change the status from <strong>{statusLabel[app.status]}</strong> to <strong>{statusLabel[pending]}</strong>?</p>
            <div className="form-actions"><button className="button button-primary" onClick={confirm}>Change to {statusLabel[pending]}</button><button className="button button-secondary" onClick={() => setPending(null)}>Cancel</button></div>
          </div>
        : <><h2>Change status to</h2><div className="form-actions">{options.map(s => <button key={s} className="button button-secondary" onClick={() => setPending(s)}>{statusLabel[s]}</button>)}</div></>}
    </div>
  </>;
}
