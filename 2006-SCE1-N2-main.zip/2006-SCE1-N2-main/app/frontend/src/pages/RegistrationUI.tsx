// Class diagram: RegistrationUI «boundary» (UC01). Dialog map DM-02 to DM-04.
// On success (DM-04) continue to /login; the account stays signed out (UC01 postcondition).
import { useEffect, useState, type FormEvent } from "react";
import { Link, useNavigate } from "react-router-dom";
import { backend } from "../data/backend";
import { AuthLayout } from "../components/AuthLayout";

export default function RegistrationUI() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: "", email: "", password: "", preferred_postal_code: "", notification_opt_in: true });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  useEffect(() => { document.title = "Create account · Schoolwise"; }, []);
  const set = (key: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm({ ...form, [key]: e.target.type === "checkbox" ? e.target.checked : e.target.value });

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    if (form.password.length < 8) return setError("Password must be at least 8 characters.");
    if (form.preferred_postal_code && !/^\d{6}$/.test(form.preferred_postal_code)) return setError("Postal code must be 6 digits.");
    setBusy(true); setError("");
    try {
      await backend.registerAccount(form);
      navigate("/login", { state: { registered: form.email } });
    } catch (e) { setError((e as Error).message); setBusy(false); }
  };

  return <AuthLayout>
    <h1>Create account</h1>
    {error && <p className="form-error" role="alert">{error}</p>}
    <form onSubmit={submit} className="form-stack">
      <label className="field"><span>Name</span><input required value={form.name} onChange={set("name")} autoComplete="name"/></label>
      <label className="field"><span>Email</span><input type="email" required value={form.email} onChange={set("email")} autoComplete="email"/></label>
      <label className="field"><span>Password</span><input type="password" required value={form.password} onChange={set("password")} autoComplete="new-password"/><small>At least 8 characters</small></label>
      <label className="field"><span>Home postal code <em>optional</em></span><input inputMode="numeric" value={form.preferred_postal_code} onChange={set("preferred_postal_code")}/><small>Used to show how far each school is from home</small></label>
      <label className="checkbox-label"><input type="checkbox" checked={form.notification_opt_in} onChange={set("notification_opt_in")}/>Remind me about application deadlines</label>
      <button className="button button-primary" disabled={busy}>{busy ? "Creating account…" : "Create account"}</button>
    </form>
    <p className="auth-switch">Already have an account? <Link to="/login">Log in</Link></p>
  </AuthLayout>;
}
