import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { useSearchParams } from "react-router-dom";
import type { EducationLevel, SearchCriteria } from "../api/types";
import { useDirectory } from "../context/DirectoryContext";
import { useComparisonSelection } from "../context/ComparisonSelectionContext";
import { findSchools, levelLabel, loadCcas, loadSubjects, zoneOptions } from "../data/schoolDirectory";
import { useLoad } from "../hooks/useLoad";
import { SchoolRow } from "../components/SchoolRow";
import { ErrorState, LoadingState } from "../components/PageState";
import { Icon } from "../components/Icon";
import { useCountUp } from "../hooks/useCountUp";

const PAGE_SIZE = 6;

// Page buttons to show: always the first and last page, plus one either side of the current page;
// gaps become "…". Short ranges (7 pages or fewer) are shown in full.
function pageItems(page: number, total: number): (number | "gap")[] {
  if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);
  const start = Math.max(2, Math.min(page - 1, total - 4));
  const end = Math.min(total - 1, Math.max(page + 1, 5));
  const items: (number | "gap")[] = [1];
  if (start > 2) items.push("gap");
  for (let n = start; n <= end; n++) items.push(n);
  if (end < total - 1) items.push("gap");
  items.push(total);
  return items;
}
// UI-01 / UC04–UC05: URL-backed filters preserve the search through the discovery flow.
export default function SchoolSearchUI() {
  const [params, setParams] = useSearchParams();
  const { rememberSearch } = useDirectory();
  const { selectedSchoolIds } = useComparisonSelection();
  const restore = useRef(true);
  const query = params.get("q") ?? "";
  const level = params.get("level") ?? "";
  const zone = params.get("zone") ?? "";
  const subject = params.get("subject_id") ?? "";
  const cca = params.get("cca_id") ?? "";
  const sort = params.get("sort") ?? "az";
  const criteria: SearchCriteria = { q: query, level: level as EducationLevel || undefined, zone, subject_id: subject, cca_id: cca };
  const { data: schools = [], loading, error, retry } = useLoad(() => findSchools(criteria), [query, level, zone, subject, cca]);
  const references = useLoad(async () => { const [subjects, ccas] = await Promise.all([loadSubjects(), loadCcas()]); return { subjects, ccas }; }, []);
  const totalPages = Math.max(1, Math.ceil(schools.length / PAGE_SIZE));
  const page = Math.min(Math.max(1, Number(params.get("page")) || 1), totalPages);
  const hasDistances = schools.some(s => s.distance_km != null);
  const sorted = [...schools].sort((a, b) =>
    sort === "near" && hasDistances ? (a.distance_km ?? Infinity) - (b.distance_km ?? Infinity) || a.name.localeCompare(b.name)
    : sort === "za" ? b.name.localeCompare(a.name) : a.name.localeCompare(b.name));
  const visible = sorted.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);
  const filterCount = [level, zone, subject, cca].filter(Boolean).length;
  const [filtersOpen, setFiltersOpen] = useState(false);
  const animatedFilterCount = useCountUp(filterCount);
  const update = (key: string, value: string) => {
    const next = new URLSearchParams(params);
    if (value) next.set(key, value); else next.delete(key);
    if (key !== "page") next.delete("page");
    setParams(next, { replace: key === "q" });
  };
  const reset = () => { const next = new URLSearchParams(); if (query) next.set("q", query); setParams(next); };
  useEffect(() => rememberSearch(`/schools${params.toString() ? `?${params}` : ""}`), [params.toString()]);
  useEffect(() => { document.title = "Find schools · Schoolwise"; }, []);
  useLayoutEffect(() => {
    if (!loading && restore.current) { window.scrollTo(0, Number(sessionStorage.getItem("school-search-scroll") ?? 0)); restore.current = false; }
  }, [loading]);

  return <>
    <div className="page-heading"><h1>Find schools</h1></div>
    <div className="search-field"><Icon name="search" size={22}/><label htmlFor="school-search" className="sr-only">Search schools</label><input id="school-search" type="search" value={query} onChange={event => update("q", event.target.value)} placeholder="School name"/></div>
    <div className="directory-layout">
      <aside className={`filters ${filtersOpen ? "is-open" : ""}`} aria-label="Filter schools"><button className="button button-secondary filters-toggle" aria-expanded={filtersOpen} aria-controls="filters-body" onClick={() => setFiltersOpen(!filtersOpen)}><Icon name="filter" size={18}/>{filtersOpen ? "Hide filters" : "Filters"}{filterCount > 0 && <span className="filter-count">{filterCount}</span>}</button><div className="filters-body" id="filters-body"><div className="filter-heading"><h2>Filters{filterCount > 0 && <span className="filter-count">{animatedFilterCount}</span>}</h2><button className="text-button" disabled={!filterCount} onClick={reset}>Reset</button></div>
        <fieldset><legend>Education level</legend>{[["", "All levels"], ["Primary", "Primary"], ["Secondary", "Secondary"], ["JuniorCollege", "Junior college"]].map(([value, label]) => <label className="radio-row" key={value}><input type="radio" name="education-level" value={value} checked={level === value} onChange={() => update("level", value)}/><span>{label}</span></label>)}</fieldset>
        <div className="filter-group"><label htmlFor="zone">School zone</label><div className="select-wrapper"><select id="zone" value={zone} onChange={event => update("zone", event.target.value)}><option value="">All zones</option>{zoneOptions.map(value =><option key={value}>{value}</option>)}</select><Icon name="down" size={16}/></div></div>
        <div className="filter-group"><label htmlFor="subject">Subject offered</label><div className="select-wrapper"><select id="subject" value={subject} onChange={event => update("subject_id", event.target.value)}><option value="">Any subject</option>{references.data?.subjects.map(item => <option key={item.subject_id} value={item.subject_id}>{item.subject_name}</option>)}</select><Icon name="down" size={16}/></div></div>
        <div className="filter-group"><label htmlFor="cca">Co-curricular activity</label><div className="select-wrapper"><select id="cca" value={cca} onChange={event => update("cca_id", event.target.value)}><option value="">Any activity</option>{references.data?.ccas.map(item => <option key={item.cca_id} value={item.cca_id}>{item.cca_name}</option>)}</select><Icon name="down" size={16}/></div></div>
        {references.error && <div className="inline-error"><p>Subject and activity filters didn’t load.</p><button className="text-button" onClick={references.retry}>Retry filters</button></div>}
      </div></aside>
      <section className="results" aria-label="School results" aria-busy={loading}>
        <div className="results-toolbar"><p role="status"><strong>{loading ? "Finding schools…" : `${schools.length} ${schools.length === 1 ? "school" : "schools"}`}</strong></p><div className="sort-control"><label htmlFor="sort">Sort by</label><div className="select-wrapper"><select id="sort" value={sort} onChange={event => update("sort", event.target.value)}><option value="az">Name: A–Z</option><option value="za">Name: Z–A</option>{hasDistances && <option value="near">Nearest first</option>}</select><Icon name="down" size={15}/></div></div></div>
        {filterCount > 0 && <div className="active-filters">{[["level", level ? levelLabel[level] : ""], ["zone", zone], ["subject_id", subject ? references.data?.subjects.find(item => item.subject_id === subject)?.subject_name ?? subject : ""], ["cca_id", cca ? references.data?.ccas.find(item => item.cca_id === cca)?.cca_name ?? cca : ""]].filter(([, label]) => label).map(([key, label]) => <button key={key} className="filter-token" onClick={() => update(key!, "")} aria-label={`Remove ${label} filter`}>{label}<Icon name="close" size={14}/></button>)}</div>}
        {selectedSchoolIds.length === 5 && <p className="selection-notice" role="status"><Icon name="info" size={17}/>5 schools are in the comparison, the most it holds. Remove one below to add another.</p>}
        {loading ? <LoadingState label="Finding schools"/> : error ? <ErrorState message={error} retry={retry}/> : schools.length === 0 ? <div className="empty-state"><Icon name="search" size={32}/><h2>No schools match</h2><p>Try a different name, or remove a filter.</p><button className="button button-secondary" onClick={() => setParams({})}>Clear search and filters</button></div> : <>
          <div className="school-list">{visible.map(school => <SchoolRow key={school.school_id} school={school}/>)}</div>
          <div className="pagination"><p>Showing {(page - 1) * PAGE_SIZE + 1}–{Math.min(page * PAGE_SIZE, schools.length)} of {schools.length}</p><nav aria-label="Results pages"><button className="page-button" disabled={page === 1} aria-label="Previous page" onClick={() => { update("page", String(page - 1)); window.scrollTo(0, 0); }}><Icon name="back" size={17}/></button>{pageItems(page, totalPages).map((item, i) => item === "gap"
            ? <span key={`gap-${i}`} className="page-gap" aria-hidden="true">…</span>
            : <button key={item} className={`page-button ${page === item ? "current" : ""}`} aria-current={page === item ? "page" : undefined} aria-label={`Page ${item}`} onClick={() => { update("page", String(item)); window.scrollTo(0, 0); }}>{item}</button>)}<button className="page-button" disabled={page === totalPages} aria-label="Next page" onClick={() => { update("page", String(page + 1)); window.scrollTo(0, 0); }}><Icon name="arrow" size={17}/></button></nav></div>
        </>}
      </section>
    </div>
  </>;
}
