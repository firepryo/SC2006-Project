// Class diagram: ApplicationUI «boundary» (UC09). Dialog map DM-60 to DM-68.
// Without :applicationId this is the list (DM-60) or its empty state (DM-61); with it, the detail (DM-65).
import { useEffect, useState, type FormEvent } from "react";
import { Link, useLocation, useNavigate, useParams } from "react-router-dom";
import type { ApplicationStatus } from "../api/types";
import { useActiveStudent } from "../context/ActiveStudentContext";
import { useDirectory } from "../context/DirectoryContext";
import { backend, daysUntil, dueLabel, formatDate, formatDay, statusLabel } from "../data/backend";
import { findSchools, levelLabel } from "../data/schoolDirectory";
import { useLoad } from "../hooks/useLoad";
import { Icon } from "../components/Icon";
import { ErrorState, LoadingState } from "../components/PageState";
import { StatusBadge } from "../components/StatusBadge";

export default function ApplicationUI() {
  const { applicationId } = useParams();
  return applicationId ? <ApplicationDetail id={applicationId}/> : <ApplicationList/>;
}

function ApplicationList() {
  const { activeStudent } = useActiveStudent();
  const { entries } = useDirectory();
  const navigate = useNavigate();
  const studentId = activeStudent!.student_id;
  const { data: applications = [], loading } = useLoad(() => backend.listApplications(studentId), [studentId]);
  const { data: allSchools = [] } = useLoad(() => findSchools({}), []);
  const [creating, setCreating] = useState(false);
  const [schoolId, setSchoolId] = useState("");
  const [notes, setNotes] = useState("");
  const [error, setError] = useState("");
  useEffect(() => { document.title = "Applications · Schoolwise"; }, []);
  const taken = applications.map(a => a.school.school_id);
  const shortlisted = entries.map(e => e.school).filter(s => !taken.includes(s.school_id));
  const others = allSchools.filter(s =>!taken.includes(s.school_id) && !shortlisted.some(x => x.school_id === s.school_id));

  const create = async (event: FormEvent) => {
    event.preventDefault();
    try { navigate(`/applications/${(await backend.createApplication(studentId, schoolId, notes)).application_id}`, { state: { message: "Application created as a draft." } }); }
    catch (e) { setError((e as Error).message); }
  };

  return <>
    <div className="page-heading heading-with-action"><h1>{activeStudent!.name}’s applications</h1>{!creating && <button className="button button-primary" onClick={() => setCreating(true)}><Icon name="plus" size={17}/>New application</button>}</div>
    {creating && <form className="panel form-panel" onSubmit={create}>
      <h2>New application</h2>
      {error && <p className="form-error" role="alert">{error}</p>}
      <label className="field"><span>School</span><select required value={schoolId} onChange={e => setSchoolId(e.target.value)}>
        <option value="">Choose a school</option>
        {shortlisted.length > 0 && <optgroup label="Shortlisted">{shortlisted.map(s => <option key={s.school_id} value={s.school_id}>{s.name}</option>)}</optgroup>}
        <optgroup label="All schools">{others.map(s => <option key={s.school_id} value={s.school_id}>{s.name}</option>)}</optgroup>
      </select></label>
      <label className="field"><span>Notes <em>optional</em></span><textarea rows={3} value={notes} onChange={e => setNotes(e.target.value)}/></label>
      <div className="form-actions"><button className="button button-primary">Create draft</button><button type="button" className="button button-secondary" onClick={() => { setCreating(false); setError(""); }}>Cancel</button></div>
    </form>}
    {loading ? <LoadingState rows={2}/> : !applications.length ? !creating && <div className="empty-state"><Icon name="book" size={32}/><h2>No applications yet</h2><p>Start one here, or from any school on the shortlist.</p><button className="button button-primary" onClick={() => setCreating(true)}>New application</button></div>
      : <div className="table-wrap"><table className="data-table">
        <thead><tr><th>School</th><th>Level</th><th>Status</th><th>Submitted</th><th>Deadline</th><th>Last updated</th></tr></thead>
        <tbody>{applications.map(a => <tr key={a.application_id}>
          <td><Link className="table-link" to={`/applications/${a.application_id}`}>{a.school.name}</Link></td>
          <td data-label="Level">{levelLabel[a.school.type]}</td>
          <td data-label="Status"><StatusBadge status={a.status}/></td>
          <td data-label="Submitted">{formatDate(a.date_submitted)}</td>
          <td data-label="Deadline">{a.deadline ? <span className={daysUntil(a.deadline) >= 0 && daysUntil(a.deadline) <= 7 ? "due-soon" : ""}>{formatDate(a.deadline)}</span> : "—"}</td>
          <td data-label="Updated">{formatDate(a.updated_at)}</td>
        </tr>)}</tbody>
      </table></div>}
  </>;
}

const steps: ApplicationStatus[] = ["Draft", "Submitted", "UnderReview", "Offered", "Accepted"];

function ApplicationDetail({ id }: { id: string }) {
  const message = (useLocation().state as { message?: string } | null)?.message;
  const { data: app, loading, error, retry } = useLoad(() => backend.getApplication(id), [id]);
  const [notes, setNotes] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  useEffect(() => { document.title = `${app?.school.name ?? "Application"} · Schoolwise`; }, [app]);
  const back = <Link className="back-link" to="/applications"><Icon name="back" size={17}/>Applications</Link>;
  if (loading) return <>{back}<LoadingState rows={2}/></>;
  if (error || !app) return <>{back}<ErrorState message={error} retry={retry}/></>;

  const saveNotes = async (event: FormEvent) => {
    event.preventDefault();
    await backend.updateApplication(id, notes);
    setSaved(true); retry();
  };
  const reached = app.status === "Rejected" ? 3 : steps.indexOf(app.status);

  return <>{back}
    <div className="page-heading heading-with-action"><div><h1>{app.school.name}</h1><p>{levelLabel[app.school.type]}, {app.school.planning_area}</p></div><Link className="button button-secondary" to={`/schools/${app.school.school_id}`}>School details</Link></div>
    {message && <p className="form-success" role="status">{message}</p>}
    <ol className="status-steps" aria-label="Application progress">{steps.map((s, i) => {
      const label = s === "Offered" && app.status === "Rejected" ? "Rejected" : statusLabel[s];
      return <li key={s} className={i < reached ? "done" : i === reached ? (app.status === "Rejected" ? "current rejected" : "current") : ""}>{label}</li>;
    })}</ol>
    <div className="detail-layout">
      <div className="detail-main">
        <section className="detail-section">
          <div className="section-heading"><h2>Status</h2><Link className="button button-secondary button-small" to={`/applications/${id}/status`}>Update status</Link></div>
          <dl className="facts-grid">
            <div><dt>Current status</dt><dd><StatusBadge status={app.status}/></dd></div>
            <div><dt>Submitted</dt><dd>{formatDate(app.date_submitted)}</dd></div>
            <div><dt>Last updated</dt><dd>{formatDate(app.updated_at)}</dd></div>
          </dl>
        </section>
        <form className="detail-section" onSubmit={saveNotes}>
          <h2>Notes</h2>
          <label className="field"><span className="sr-only">Notes</span><textarea rows={5} value={notes ?? app.notes ?? ""} onChange={e => { setNotes(e.target.value); setSaved(false); }}/></label>
          <div className="form-actions"><button className="button button-primary" disabled={notes === null || notes === (app.notes ?? "")}>Save notes</button>{saved && <span className="saved-text"><Icon name="check" size={16}/>Saved</span>}</div>
        </form>
      </div>
      <aside className="contact-panel">
        <h2>Deadline</h2>
        {app.deadline ? <><p className="deadline-date">{formatDay(app.deadline)} {new Date(`${app.deadline}T00:00:00`).getFullYear()}</p><p className="deadline-days">{daysUntil(app.deadline) >= 0 ? <span className={daysUntil(app.deadline) <= 7 ? "due-soon" : ""}>Due {dueLabel(app.deadline)}</span> : <span className="muted">Passed {dueLabel(app.deadline)}</span>}</p></> : <p className="deadline-days muted">No deadline set. Add one to get a reminder a week before.</p>}
        <Link className="button button-secondary" to={`/applications/${id}/deadline`}>{app.deadline ? "Change deadline" : "Set deadline"}</Link>
      </aside>
    </div>
  </>;
}
