import { useEffect } from "react";
import { Link, useParams } from "react-router-dom";
import { useDirectory } from "../context/DirectoryContext";
import { loadSchool, affiliationNames, levelLabel, isDemo } from "../data/schoolDirectory";
import { getSchoolRoute } from "../api/client";
import { useAuth } from "../context/AuthContext";
import { OneMapView } from "../components/OneMapView";
import type { DirectorySchool } from "../data/demoSchools";
import { useLoad } from "../hooks/useLoad";
import { CompareButton, SaveButton } from "../components/SchoolActions";
import { ErrorState, LoadingState } from "../components/PageState";
import { Distance } from "../components/SchoolRow";
import { Icon } from "../components/Icon";

// "Getting there": OneMap road distance from home and a map of home, school and the route between them.
function GettingThere({ school }: { school: DirectorySchool }) {
  const { user } = useAuth();
  const { data: route, loading, error } = useLoad(
    () => isDemo ? Promise.resolve(null) : getSchoolRoute(school.school_id),
    [school.school_id, user?.preferred_postal_code],
  );
  if (isDemo) return <Distance km={school.distance_km}/>;
  if (loading) return <p className="distance unknown"><small>Finding the route on OneMap…</small></p>;
  if (error || !route) return <p className="distance unknown"><small>The map isn’t available right now.</small></p>;
  return <div className="getting-there">
    {route.distance_km != null
      ? <p className="distance"><strong>{route.distance_km.toFixed(1)}<span>km</span></strong>
          <small>by road from home{route.duration_min != null && <>, about {Math.round(route.duration_min)} min by car</>}</small></p>
      : route.home && route.straight_line_km != null
        ? <p className="distance"><strong>{route.straight_line_km.toFixed(1)}<span>km</span></strong><small>straight line from home (OneMap route unavailable)</small></p>
        : <div className="distance unknown"><small>Add your home postal code to see how far this school is.</small>
            <Link className="text-link" to="/home#home-location">Set home postal code</Link></div>}
    <OneMapView school={route.school} schoolName={school.name} home={route.home} path={route.path}/>
  </div>;
}

const ccaCategories: [string, string][] = [["Sports", "Sports"], ["PerformingArts", "Performing arts"], ["ClubSociety", "Clubs and societies"], ["UniformedGroup", "Uniformed groups"], ["Others", "Other activities"]];

// UI-01 / UC06: task-oriented information groups and explicit unavailable values.
export default function SchoolDetailsUI() {
  const { schoolId = "" } = useParams();
  const { searchPath } = useDirectory();
  const { data: school, loading, error, retry } = useLoad(() => loadSchool(schoolId), [schoolId]);
  useEffect(() => { window.scrollTo(0, 0); }, [schoolId]);
  useEffect(() => { document.title = `${school?.name ?? "School details"} · Schoolwise`; }, [school]);
  const back = <Link className="back-link" to={searchPath}><Icon name="back" size={17}/>All schools</Link>;
  if (loading) return <>{back}<LoadingState rows={3} label="Loading school"/></>;
  if (error || !school) return <>{back}<ErrorState message={error} retry={retry}/></>;
  const affiliations = affiliationNames(school);

  return <>{back}
    <div className="detail-heading">
      <div>
        <p className="school-meta"><span>{levelLabel[school.type]}</span></p>
        <h1>{school.name}</h1>
        <p><Icon name="pin" size={17}/>{school.planning_area}, {school.zone} zone</p>
      </div>
      <div className="detail-actions"><SaveButton id={school.school_id} name={school.name}/><CompareButton id={school.school_id} name={school.name}/></div>
    </div>
    <nav className="section-nav" aria-label="On this page"><a href="#overview">Overview</a><a href="#subjects">Subjects</a><a href="#activities">Co-curricular activities</a><a href="#affiliations">Affiliations</a></nav>
    <div className="detail-layout">
      <div className="detail-main">
        <section id="overview" className="detail-section"><h2>About the school</h2>
          <p>{school.description ?? "A description of this school isn’t available yet."}</p>
          <dl className="facts-grid">
            <div><dt>Education level</dt><dd>{levelLabel[school.type]}</dd></div>
            <div><dt>School zone</dt><dd>{school.zone ?? "Not available"}</dd></div>
            <div><dt>Planning area</dt><dd>{school.planning_area ?? "Not available"}</dd></div>
            <div><dt>Subjects</dt><dd>{school.subjects.length || "Not available"}</dd></div>
          </dl>
        </section>
        <section id="subjects" className="detail-section">
          <div className="section-heading"><h2>Subjects offered</h2><span>{school.subjects.length} subjects</span></div>
          {school.subjects.length ? <ul className="subjects-list">{school.subjects.map(item => <li key={item.subject_id}>{item.subject_name}</li>)}</ul> : <p className="muted">Subject information isn’t available for this school.</p>}
        </section>
        <section id="activities" className="detail-section">
          <div className="section-heading"><h2>Co-curricular activities</h2><span>{school.ccas.length ? `${school.ccas.length} activities` : ""}</span></div>
          {school.ccas.length ? <div className="cca-groups">{ccaCategories.map(([category, label]) => {
            const ccas = school.ccas.filter(item => item.category === category);
            return ccas.length ? <div key={category}><h3>{label}</h3><ul>{ccas.map(item => <li key={item.cca_id}>{item.cca_name}</li>)}</ul></div> : null;
          })}</div> : <p className="muted">Activity information isn’t available for this school.</p>}
        </section>
        <section id="affiliations" className="detail-section"><h2>Affiliated schools</h2>
          {affiliations.length ? <ul className="affiliation-list">{affiliations.map(name => <li key={name}>{name}</li>)}</ul> : <p className="muted">No affiliations recorded.</p>}
        </section>
      </div>
      <aside className="contact-panel" aria-label="Location and contact">
        <h2>Getting there</h2>
        <GettingThere school={school}/>
        <div className="contact-block"><h3>Address</h3><p>{school.address}<br/>{school.postal_code ? `Singapore ${school.postal_code}` : `${school.planning_area}, Singapore`}</p></div>
        <div className="contact-block"><h3>Phone</h3>{school.telephone ? <a href={`tel:${school.telephone}`}>{school.telephone}</a> : <p className="muted">Not provided</p>}</div>
        <div className="contact-block"><h3>Email</h3>{school.email ? <a href={`mailto:${school.email}`}>{school.email}</a> : <p className="muted">Not provided</p>}</div>
        {school.website && <a className="button button-secondary" href={school.website} target="_blank" rel="noreferrer">School website<Icon name="external" size={16}/></a>}
      </aside>
    </div>
  </>;
}
