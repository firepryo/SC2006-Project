// Class diagram: ApplicationDeadlineUI «boundary» (UC13). Dialog map DM-71 to DM-74.
import { useEffect, useState, type FormEvent } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { backend, formatDate } from "../data/backend";
import { useLoad } from "../hooks/useLoad";
import { Icon } from "../components/Icon";

export default function ApplicationDeadlineUI() {
  const { applicationId = "" } = useParams();
  const navigate = useNavigate();
  const { data: app } = useLoad(() => backend.getApplication(applicationId), [applicationId]);
  const [date, setDate] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [confirmClear, setConfirmClear] = useState(false);
  useEffect(() => { document.title = "Deadline · Schoolwise"; }, []);
  if (!app) return null;
  const value = date ?? app.deadline ?? "";
  const today = new Date().toLocaleDateString("en-CA");
  const done = (message: string) => navigate(`/applications/${applicationId}`, { state: { message } });

  const save = async (event: FormEvent) => {
    event.preventDefault();
    if (value < today) return setError("The deadline cannot be in the past."); // DM-72
    await backend.setDeadline(applicationId, value);
    done(`Deadline set to ${formatDate(value)}.`);
  };
  const clear = async () => { await backend.clearDeadline(applicationId); done("Deadline cleared."); };

  return <>
    <Link className="back-link" to={`/applications/${applicationId}`}><Icon name="back" size={17}/>{app.school.name}</Link>
    <div className="page-heading"><h1>{app.deadline ? "Change deadline" : "Set deadline"}</h1></div>
    <form className="panel form-panel narrow" onSubmit={save}>
      {error && <p className="form-error" role="alert">{error}</p>}
      <label className="field"><span>Application deadline</span><input type="date" required min={today} value={value} onChange={e => { setDate(e.target.value); setError(""); }}/><small>If reminders are on, you’ll get one 7 days before.</small></label>
      <div className="form-actions"><button className="button button-primary">Save deadline</button>
        {app.deadline && !confirmClear && <button type="button" className="text-button muted-button" onClick={() => setConfirmClear(true)}>Clear deadline</button>}
      </div>
      {confirmClear && <div className="confirm-box"><p>Clear the deadline of {formatDate(app.deadline)}? Its reminder will stop.</p><div className="form-actions"><button type="button" className="button button-danger" onClick={clear}>Clear deadline</button><button type="button" className="button button-secondary" onClick={() => setConfirmClear(false)}>Cancel</button></div></div>}
    </form>
  </>;
}
