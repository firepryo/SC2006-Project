// Class diagram: LoginUI «boundary» (UC02, NFR 3.5.1). Dialog map DM-05 to DM-08.
import { useEffect, useState, type FormEvent } from "react";
import { Link, Navigate, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { backend } from "../data/backend";
import { AuthLayout } from "../components/AuthLayout";

export default function LoginUI() {
  const { user, setUser } = useAuth();
  const navigate = useNavigate();
  const registered = (useLocation().state as { registered?: string } | null)?.registered;
  const [email, setEmail] = useState(registered ?? "");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [lockedUntil, setLockedUntil] = useState(0);
  const [busy, setBusy] = useState(false);
  const [now, setNow] = useState(Date.now());
  useEffect(() => { document.title = "Log in · Schoolwise"; }, []);
  useEffect(() => { if (lockedUntil) { const timer = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(timer); } }, [lockedUntil]);
  const remaining = Math.max(0, Math.ceil((lockedUntil - now) / 1000));
  if (user) return <Navigate to="/home" replace />;

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setBusy(true); setError("");
    try {
      setUser(await backend.login(email, password));
      navigate("/home");
    } catch (e) {
      const err = e as Error & { lockedUntil?: number };
      if (err.lockedUntil) { setLockedUntil(err.lockedUntil); setNow(Date.now()); } else setError(err.message);
      setPassword("");
    }
    setBusy(false);
  };

  return <AuthLayout>
    <h1>Log in</h1>
    {registered && !error && !remaining && <p className="form-success">Account created. Log in to continue.</p>}
    {error && <p className="form-error" role="alert">{error}</p>}
    {remaining > 0 && <p className="form-error" role="alert">Too many incorrect attempts. Try again in {Math.floor(remaining / 60)}:{String(remaining % 60).padStart(2, "0")}.</p>}
    <form onSubmit={submit} className="form-stack">
      <label className="field"><span>Email</span><input type="email" required value={email} onChange={e => setEmail(e.target.value)} autoComplete="email"/></label>
      <label className="field"><span>Password</span><input type="password" required value={password} onChange={e => setPassword(e.target.value)} autoComplete="current-password"/></label>
      <button className="button button-primary" disabled={busy || remaining > 0}>{busy ? "Logging in…" : "Log in"}</button>
    </form>
    <p className="auth-switch">New to Schoolwise? <Link to="/register">Create an account</Link></p>
  </AuthLayout>;
}
