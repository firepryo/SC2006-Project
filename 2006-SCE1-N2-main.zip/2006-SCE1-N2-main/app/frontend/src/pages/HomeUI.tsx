// Dialog map DM-10 Personalised home: active student, shortlist, applications and upcoming deadlines.
// The page opens on the student's "exercise book": a cover with a name label carrying the next deadline.
import { useEffect } from "react";
import { Link } from "react-router-dom";
import { useActiveStudent } from "../context/ActiveStudentContext";
import { useAuth } from "../context/AuthContext";
import { useDirectory } from "../context/DirectoryContext";
import { backend, daysUntil, dueLabel, formatDay } from "../data/backend";
import { levelLabel } from "../data/schoolDirectory";
import { useLoad } from "../hooks/useLoad";
import { StatusBadge } from "../components/StatusBadge";
import { Icon } from "../components/Icon";
import { HomeLocationCard } from "../components/HomeLocationCard";

export default function HomeUI() {
  const { user } = useAuth();
  const { activeStudent, profilesLoaded } = useActiveStudent();
  const { entries } = useDirectory();
  const studentId = activeStudent?.student_id;
  const { data: applications = [] } = useLoad(() => studentId ? backend.listApplications(studentId) : Promise.resolve([]), [studentId]);
  useEffect(() => { document.title = "Home · Schoolwise"; }, []);
  if (!profilesLoaded) return null;
  if (!activeStudent) return <>
    <div className="page-heading"><h1>Welcome, {user?.name}</h1></div>
    <div className="empty-state"><Icon name="book" size={32}/><h2>Add your child to get started</h2><p>Searches, shortlists and applications are kept separately for each child.</p><Link className="button button-primary" to="/profiles">Add student</Link></div>
    <HomeLocationCard/>
  </>;

  const upcoming = applications.filter(a => a.deadline && daysUntil(a.deadline) >= 0).sort((a, b) => a.deadline!.localeCompare(b.deadline!));
  const next = upcoming[0];
  const byDeadline = [...applications].sort((a, b) => (a.deadline ?? "9999").localeCompare(b.deadline ?? "9999"));
  const name = activeStudent.name ?? "Student";

  return <>
    <h1 className="sr-only">{name}</h1>
    <section className="cover" aria-label={`${name}’s overview`}>
      <dl className="label-lines">
        <div><dt>Name</dt><dd className="label-name">{name}</dd></div>
        <div className="label-inline">
          <div><dt>Level</dt><dd>{levelLabel[activeStudent.current_level]} {activeStudent.current_year}</dd></div>
          <div><dt>Shortlist</dt><dd>{entries.length} {entries.length === 1 ? "school" : "schools"}</dd></div>
          <div><dt>Applications</dt><dd>{applications.length}</dd></div>
        </div>
      </dl>
      <div className="cover-side">
        <dl className="next-deadline"><dt>Next deadline</dt><dd>{next
          ? <Link to={`/applications/${next.application_id}`}><span className="numeral">{formatDay(next.deadline)}</span><span className="due-text"><span className={daysUntil(next.deadline!) <= 7 ? "due-soon" : ""}>Due {dueLabel(next.deadline!)}</span><span className="muted">, {next.school.name}</span></span></Link>
          : <span className="muted">No deadlines set</span>}</dd></dl>
        <Link className="button button-primary" to="/schools">Find schools</Link>
      </div>
    </section>

    <div className="home-columns">
      <section className="home-section" aria-labelledby="home-applications">
        <header><h2 id="home-applications">Applications</h2><Link className="text-link" to="/applications">All applications</Link></header>
        {byDeadline.length ? <ul className="ruled-list">{byDeadline.map(a => {
          const soon = a.deadline && daysUntil(a.deadline) >= 0 && daysUntil(a.deadline) <= 7;
          return <li key={a.application_id}>
            <Link className="row-title" to={`/applications/${a.application_id}`}>{a.school.name}</Link>
            <span className="row-sub">{a.deadline ? <span className={soon ? "due-soon" : ""}>Due {formatDay(a.deadline)}, {dueLabel(a.deadline)}</span> : "No deadline set"}</span>
            <span className="row-end"><StatusBadge status={a.status}/></span>
          </li>;
        })}</ul> : <p className="list-empty">No applications yet. Start one from a school on the <Link to="/shortlist">shortlist</Link>.</p>}
      </section>
      <section className="home-section" aria-labelledby="home-shortlist">
        <header><h2 id="home-shortlist">Shortlist</h2><Link className="text-link" to="/shortlist">Open shortlist</Link></header>
        {entries.length ? <ul className="ruled-list">{entries.slice(0, 6).map(e => <li key={e.entry_id}>
          <Link className="row-title" to={`/schools/${e.school.school_id}`}>{e.school.name}</Link>
          <span className="row-sub">{levelLabel[e.school.type]}, {e.school.planning_area}</span>
        </li>)}</ul> : <p className="list-empty">Nothing saved yet. Use the bookmark on any school to keep it here.</p>}
      </section>
    </div>
    <HomeLocationCard/>
  </>;
}
