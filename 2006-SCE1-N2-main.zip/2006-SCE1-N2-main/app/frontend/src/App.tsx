// Routes: one per top-level dialog-map state (dialog map §1; ARC-02 §3.12).
import { Navigate, Outlet, Route, Routes } from "react-router-dom";
import ApplicationDeadlineUI from "./pages/ApplicationDeadlineUI";
import ApplicationStatusUI from "./pages/ApplicationStatusUI";
import ApplicationUI from "./pages/ApplicationUI";
import HomeUI from "./pages/HomeUI";
import LandingUI from "./pages/LandingUI";
import LoginUI from "./pages/LoginUI";
import NotificationPreferencesUI from "./pages/NotificationPreferencesUI";
import NotificationUI from "./pages/NotificationUI";
import RegistrationUI from "./pages/RegistrationUI";
import SchoolComparisonUI from "./pages/SchoolComparisonUI";
import SchoolDetailsUI from "./pages/SchoolDetailsUI";
import SchoolSearchUI from "./pages/SchoolSearchUI";
import ShortlistUI from "./pages/ShortlistUI";
import StudentProfileUI from "./pages/StudentProfileUI";
import { AppShell } from "./components/AppShell";
import { Icon } from "./components/Icon";
import { useAuth } from "./context/AuthContext";
import { useActiveStudent } from "./context/ActiveStudentContext";

function RequireAuth() {
  const { user, ready } = useAuth();
  if (!ready) return null;
  return user ? <Outlet /> : <Navigate to="/login" replace />;
}

// Dialog map §1: Find schools, Shortlist and Applications need a student profile first.
function RequireProfile() {
  const { profiles, profilesLoaded } = useActiveStudent();
  if (!profilesLoaded) return null;
  return profiles.length ? <Outlet /> : <Navigate to="/profiles" replace />;
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<LandingUI />} />
      <Route path="/register" element={<RegistrationUI />} />
      <Route path="/login" element={<LoginUI />} />
      <Route element={<RequireAuth />}>
        <Route element={<AppShell />}>
          <Route path="/home" element={<HomeUI />} />
          <Route path="/profiles" element={<StudentProfileUI />} />
          <Route path="/compare" element={<SchoolComparisonUI />} />
          <Route path="/notifications" element={<NotificationUI />} />
          <Route path="/notifications/preferences" element={<NotificationPreferencesUI />} />
          <Route element={<RequireProfile />}>
            <Route path="/schools" element={<SchoolSearchUI />} />
            <Route path="/schools/:schoolId" element={<SchoolDetailsUI />} />
            <Route path="/shortlist" element={<ShortlistUI />} />
            <Route path="/applications" element={<ApplicationUI />} />
            <Route path="/applications/:applicationId" element={<ApplicationUI />} />
            <Route path="/applications/:applicationId/status" element={<ApplicationStatusUI />} />
            <Route path="/applications/:applicationId/deadline" element={<ApplicationDeadlineUI />} />
          </Route>
          <Route path="*" element={<div className="empty-state"><Icon name="info" size={30}/><h2>Page not found</h2><p>This address does not match any page.</p><a className="button button-primary" href="/home">Go to home</a></div>} />
        </Route>
      </Route>
    </Routes>
  );
}
