# Schoolwise frontend

Desktop frontend for every screen in the dialog map, built with the existing React 18, TypeScript and Vite stack.

## Run locally

```sh
cd app/frontend
npm install
npm run dev -- --host 127.0.0.1
```

Open the address printed by Vite (normally `http://127.0.0.1:5173`). `npm run build` runs TypeScript checking and creates `dist/`; `npm run preview -- --host 127.0.0.1` serves that build.

## Screens

| Route | Screen | Dialog map |
| --- | --- | --- |
| `/` | Public landing page (signed-in visitors go to `/home`) | — |
| `/login`, `/register` | Log in (5 failures lock 15 min), create account | DM-02–DM-08 |
| `/home` | Active student, shortlist, applications, upcoming deadlines | DM-10 |
| `/profiles` | Student list, add/edit with subject and CCA preferences, set active, protected removal | DM-20–DM-28 |
| `/schools`, `/schools/:id` | Search, filters, details, add to shortlist, add to compare | DM-30–DM-39 |
| `/compare` | 2–5 schools side by side, differences only | DM-40–DM-45 |
| `/shortlist` | Active student's shortlist; start or open an application; remove with confirmation | DM-50–DM-53 |
| `/applications`, `/applications/:id` | List, create draft, detail with status steps and notes | DM-60–DM-68 |
| `/applications/:id/status` | Next allowed status only, confirmed before saving | DM-66–DM-67 |
| `/applications/:id/deadline` | Set, change or clear (confirmed) the deadline | DM-71–DM-74 |
| `/notifications`, `/notifications/preferences` | Reminders for deadlines within 7 days; reminders on/off | DM-69–DM-70 |

Everything except login and registration requires a signed-in account. Schools, shortlist and applications also require a student profile; without one the app opens `/profiles` first. The active student is chosen in the header. Not built: the session-expired state (DM-80) and the stale-data banner.

## Data and API boundary

Until the Flask API works, `src/data/localApi.ts` stands in for it: the same function signatures as `src/api/client.ts`, with accounts, profiles, shortlists, applications and reminder read state kept in `localStorage` (key `schoolwise-db`). Schools are the 18 fictional records in `src/data/demoSchools.ts`. Pages call `backend` from `src/data/backend.ts`; setting `VITE_DATA_SOURCE=api` in `.env.local` switches every call to the real API through the Vite `/api` proxy (Flask on port 5000). That path has not been tested against a running backend.

A seeded account with one student, a shortlist and two applications is created on first load. Its login is the `seed()` user at the top of `src/data/localApi.ts`. To reset all local data, run `localStorage.removeItem("schoolwise-db")` in the browser console and reload.

The interface does not show demo banners or notes (user decision, 2026-10-30). No real school contact details or personalised comparison scores are invented.

## Design and source layout

The visual concept is "blazer navy": a dark, tonal interface taken from the navy of a Singapore school blazer. Large rounded cards stay tonal, with no saturated fills inside them; colour appears only as soft text tints that carry meaning (coral for due soon and errors, mint for offered, amber for under review). Personality comes from type: Archivo set wide and heavy for headings and numbers, like a sports-day jersey number, with Atkinson Hyperlegible Next for body text. The exercise-book motif survives as faint ruled lines, a margin rule and a spine on the student's cover card (home and sign-in).

- Colour tokens and type settings are at the top of `src/styles.css`.
- Light and dark themes share the same tokens. With no saved choice the app follows the system setting; the sun/moon button in the header (and on the landing and sign-in pages) saves a choice in `localStorage` (`schoolwise-theme`). A small script in `index.html` applies it before first paint. Light mode is white with blazer-navy text.
- The landing page (`src/pages/LandingUI.tsx`) uses the same type and an amber accent, with a slow ticker that stops under `prefers-reduced-motion`.
- Fonts are self-hosted under `public/fonts/` with their SIL Open Font Licenses.
- On the comparison page, rows that vary are tagged "Differs"; within them, items every school shares are dimmed so unique ones stand out.
- All motion from the original build is kept and adapted to both themes (see the "Motion" section at the end of `src/styles.css`, plus `useLiveMotion` and `useCountUp`), except the ambient classroom background, which was removed so pages sit on plain white or plain navy. The landing ticker stops under `prefers-reduced-motion`; everything pauses while the tab is hidden.
- The active student is chosen from a custom menu in the header (`StudentSwitcher.tsx`), with arrow-key, Home/End and Escape support.
- The layout is responsive down to 390px wide: the navigation scrolls, filters collapse behind a button, and tables become stacked cards.

Source layout:

- `src/styles.css`: tokens, layout and component styles.
- `src/components/`: shell, comparison tray, school rows, auth layout and common controls.
- `src/pages/`: route components.
- `src/context/`: signed-in account, active student, comparison selection, shortlist.
- `src/data/`: fictional schools, the local API stand-in and the `backend` switch.

SVG interface icons and the brand mark are authored in `Icon.tsx`. No remote fonts or image services are needed at runtime.

The implementation record is `Official Technical Documentation/05-UI-Screens/Handoffs/UI-01-School-Discovery/HANDOFF.md` at the repository root.
