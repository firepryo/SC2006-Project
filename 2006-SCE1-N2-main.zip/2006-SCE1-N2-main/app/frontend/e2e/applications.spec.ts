import type { Page } from "@playwright/test";
import { type Application, dateInDays, expect, test } from "./support";

const detailPath = (application: Application) => `/applications/${application.application_id}`;

async function changeStatus(page: Page, application: Application, label: string) {
  await page.goto(`${detailPath(application)}/status`);
  await page.getByRole("button", { name: label, exact: true }).click();
  await page.getByRole("button", { name: `Change to ${label}` }).click();
  await expect(page.getByRole("status")).toContainText(`Status changed to ${label}.`);
}

test.describe("applications", () => {
  test.beforeEach(async ({ student }) => {
    expect(student.student_id).toBeTruthy();
  });

  test("the list starts empty", async ({ page }) => {
    await page.goto("/applications");
    await expect(page.getByRole("heading", { name: "No applications yet" })).toBeVisible();
  });

  test("the list shows existing applications", async ({ page, api, student, schools }) => {
    await api.createApplication(student, schools[0]);
    await page.goto("/applications");
    const row = page.getByRole("row", { name: new RegExp(schools[0].name) });
    await expect(row).toContainText("Draft");
    await row.getByRole("link", { name: schools[0].name }).click();
    await expect(page).toHaveURL(/\/applications\/[0-9a-f-]{36}$/);
  });

  test("a draft can be created from a shortlisted school", async ({ page, api, student, schools }) => {
    await api.addToShortlist(student, schools[0]);
    await page.goto("/applications");
    await page.getByRole("button", { name: "New application" }).first().click();
    await page.getByRole("combobox", { name: "School" }).selectOption({ label: schools[0].name });
    await page.getByRole("textbox", { name: "Notes" }).fill("Open house in March");
    await page.getByRole("button", { name: "Create draft" }).click();
    await expect(page.getByRole("status")).toContainText("Application created as a draft.");
    await expect(page.getByRole("heading", { level: 1, name: schools[0].name })).toBeVisible();
    await expect(page.getByRole("textbox", { name: "Notes" })).toHaveValue("Open house in March");
  });

  test("the new application form only offers real schools", async ({ page, schools }) => {
    await page.goto("/applications");
    await page.getByRole("button", { name: "New application" }).first().click();
    const options = page.getByRole("combobox", { name: "School" }).locator("optgroup[label='All schools'] option");
    await expect(options).toHaveCount(schools.length);
    const offered = await options.evaluateAll(items => items.map(item => (item as HTMLOptionElement).value));
    expect(offered.sort()).toEqual(schools.map(school => school.school_id).sort());
  });

  test("a draft can be created from any real school", async ({ page, schools }) => {
    await page.goto("/applications");
    await page.getByRole("button", { name: "New application" }).first().click();
    await page.getByRole("combobox", { name: "School" }).selectOption(schools[0].school_id);
    await page.getByRole("button", { name: "Create draft" }).click();
    await expect(page.getByRole("status")).toContainText("Application created as a draft.");
    await expect(page.getByRole("heading", { level: 1, name: schools[0].name })).toBeVisible();
  });

  test("schools already applied to are not offered again", async ({ page, api, student, schools }) => {
    await api.createApplication(student, schools[0]);
    await page.goto("/applications");
    await page.getByRole("button", { name: "New application" }).first().click();
    const options = page.getByRole("combobox", { name: "School" }).locator("optgroup[label='All schools'] option");
    await expect(options).toHaveCount(schools.length - 1);
    await expect(options.filter({ hasText: schools[0].name })).toHaveCount(0);
  });

  test("notes can be saved", async ({ page, api, student, schools }) => {
    const application = await api.createApplication(student, schools[0]);
    await page.goto(detailPath(application));
    await page.getByRole("textbox", { name: "Notes" }).fill("Bring the report book");
    await page.getByRole("button", { name: "Save notes" }).click();
    await expect(page.getByText("Saved", { exact: true })).toBeVisible();
    await page.reload();
    await expect(page.getByRole("textbox", { name: "Notes" })).toHaveValue("Bring the report book");
  });

  test("an unknown application shows an error", async ({ page }) => {
    await page.goto("/applications/00000000-0000-4000-8000-000000000000");
    await expect(page.getByRole("heading", { name: "This information didn’t load" })).toBeVisible();
  });
});

test.describe("application status", () => {
  test.beforeEach(async ({ student }) => {
    expect(student.student_id).toBeTruthy();
  });

  test("a draft can only move to submitted", async ({ page, api, student, schools }) => {
    const application = await api.createApplication(student, schools[0]);
    await page.goto(`${detailPath(application)}/status`);
    await expect(page.locator(".form-actions").getByRole("button")).toHaveText(["Submitted"]);
  });

  test("a change can be cancelled", async ({ page, api, student, schools }) => {
    const application = await api.createApplication(student, schools[0]);
    await page.goto(`${detailPath(application)}/status`);
    await page.getByRole("button", { name: "Submitted", exact: true }).click();
    await page.getByRole("button", { name: "Cancel" }).click();
    await expect(page.getByRole("button", { name: "Submitted", exact: true })).toBeVisible();
    await expect(page.locator(".current-status")).toContainText("Draft");
  });

  test("submitting records the date", async ({ page, api, student, schools }) => {
    const application = await api.createApplication(student, schools[0]);
    await changeStatus(page, application, "Submitted");
    await expect(page.getByRole("list", { name: "Application progress" }).locator("li.current")).toHaveText("Submitted");
    await expect(page.locator(".facts-grid")).not.toContainText("Submitted—");
  });

  test("under review offers both outcomes", async ({ page, api, student, schools }) => {
    const application = await api.createApplication(student, schools[0]);
    await api.setStatus(application, "Submitted");
    await api.setStatus(application, "UnderReview");
    await page.goto(`${detailPath(application)}/status`);
    await expect(page.locator(".form-actions").getByRole("button")).toHaveText(["Offered", "Rejected"]);
  });

  test("the full path ends at accepted", async ({ page, api, student, schools }) => {
    const application = await api.createApplication(student, schools[0]);
    for (const label of ["Submitted", "Under review", "Offered", "Accepted"]) await changeStatus(page, application, label);
    await page.goto(`${detailPath(application)}/status`);
    await expect(page.getByText("Accepted is a final status.")).toBeVisible();
  });

  test("a rejected application is final and shown in the progress", async ({ page, api, student, schools }) => {
    const application = await api.createApplication(student, schools[0]);
    await api.setStatus(application, "Submitted");
    await api.setStatus(application, "UnderReview");
    await changeStatus(page, application, "Rejected");
    await expect(page.getByRole("list", { name: "Application progress" }).locator("li.current.rejected")).toHaveText("Rejected");
    await page.goto(`${detailPath(application)}/status`);
    await expect(page.getByText("Rejected is a final status.")).toBeVisible();
  });
});

test.describe("application deadline", () => {
  test.beforeEach(async ({ student }) => {
    expect(student.student_id).toBeTruthy();
  });

  test("a deadline can be set", async ({ page, api, student, schools }) => {
    const application = await api.createApplication(student, schools[0]);
    await page.goto(`${detailPath(application)}/deadline`);
    await page.getByLabel("Application deadline").fill(dateInDays(3));
    await page.getByRole("button", { name: "Save deadline" }).click();
    await expect(page.getByRole("status")).toContainText("Deadline set to");
    await expect(page.locator(".deadline-days")).toHaveText("Due in 3 days");
  });

  test("past dates are not offered", async ({ page, api, student, schools }) => {
    const application = await api.createApplication(student, schools[0]);
    await page.goto(`${detailPath(application)}/deadline`);
    await expect(page.getByLabel("Application deadline")).toHaveAttribute("min", dateInDays(0));
  });

  test("a deadline can be changed", async ({ page, api, student, schools }) => {
    const application = await api.createApplication(student, schools[0]);
    await api.setDeadline(application, dateInDays(3));
    await page.goto(`${detailPath(application)}/deadline`);
    await expect(page.getByRole("heading", { name: "Change deadline" })).toBeVisible();
    await page.getByLabel("Application deadline").fill(dateInDays(10));
    await page.getByRole("button", { name: "Save deadline" }).click();
    await expect(page.locator(".deadline-days")).toHaveText("Due in 10 days");
  });

  test("clearing a deadline asks for confirmation", async ({ page, api, student, schools }) => {
    const application = await api.createApplication(student, schools[0]);
    await api.setDeadline(application, dateInDays(3));
    await page.goto(`${detailPath(application)}/deadline`);
    await page.getByRole("button", { name: "Clear deadline" }).click();
    await page.getByRole("button", { name: "Cancel" }).click();
    await page.getByRole("button", { name: "Clear deadline" }).click();
    await page.locator(".confirm-box").getByRole("button", { name: "Clear deadline" }).click();
    await expect(page.getByRole("status")).toContainText("Deadline cleared.");
    await expect(page.getByRole("link", { name: "Set deadline" })).toBeVisible();
  });

  test("the home page shows the next deadline", async ({ page, api, student, schools }) => {
    const application = await api.createApplication(student, schools[0]);
    await api.setDeadline(application, dateInDays(3));
    await page.goto("/home");
    await expect(page.getByRole("region", { name: `${student.name}’s overview` })).toContainText("Due in 3 days");
  });
});
