import { addToComparison, comparisonRow, expect, REAL_POSTAL_CODE, type School, schoolOfType, schoolRows, test } from "./support";

test.describe("school comparison", () => {
  test.beforeEach(async ({ student }) => {
    expect(student.student_id).toBeTruthy();
  });

  test("the page explains how to start when empty", async ({ page }) => {
    await page.goto("/compare");
    await expect(page.getByRole("heading", { name: "Pick schools to compare" })).toBeVisible();
  });

  test("one school asks for another", async ({ page, schools }) => {
    await addToComparison(page, schools[0]);
    await page.goto("/compare");
    await expect(page.getByRole("heading", { name: "Add one more school" })).toBeVisible();
    await expect(page.getByText(`Selected so far: ${schools[0].name}`)).toBeVisible();
  });

  test("two schools line up side by side", async ({ page, schools }) => {
    await addToComparison(page, schools[0]);
    await addToComparison(page, schools[1]);
    await page.getByRole("link", { name: "Compare schools" }).click();
    await expect(page.getByText("2 schools")).toBeVisible();
    for (const school of schools.slice(0, 2)) await expect(page.getByRole("link", { name: school.name, exact: true })).toBeVisible();
    for (const label of ["Education level", "Location", "Distance from home", "Subjects offered", "Co-curricular activities", "Affiliated schools"]) {
      await expect(comparisonRow(page, label)).toHaveCount(1);
    }
  });

  test("subjects shared across levels are not marked as different", async ({ page, api, schools }) => {
    const primary = schoolOfType(schools, "Primary");
    const secondary = schoolOfType(schools, "Secondary");
    const [primaryDetails, secondaryDetails] = await Promise.all([api.schoolDetails(primary), api.schoolDetails(secondary)]);
    const namesOf = (details: typeof primaryDetails) => details.subjects.map(subject => subject.subject_name);
    const common = namesOf(primaryDetails).filter(name => namesOf(secondaryDetails).includes(name));
    expect(common.length).toBeGreaterThan(0);

    await addToComparison(page, primary);
    await addToComparison(page, secondary);
    await page.goto("/compare");
    const cells = comparisonRow(page, "Subjects offered").getByRole("cell");
    await expect(cells.first().locator("li.shared")).toHaveCount(common.length);
    await expect(cells.nth(1).locator("li.shared")).toHaveCount(common.length);
    const unique = await cells.first().locator("li.unique").allTextContents();
    for (const name of common) expect(unique.map(text => text.replace(" (not offered by every school)", ""))).not.toContain(name);
  });

  test("schools at the same level do not differ on level", async ({ page, schools }) => {
    await addToComparison(page, schoolOfType(schools, "Primary", 0));
    await addToComparison(page, schoolOfType(schools, "Primary", 1));
    await page.goto("/compare");
    await expect(comparisonRow(page, "Education level")).not.toContainText("Differs");
  });

  test("only differences can be shown", async ({ page, schools }) => {
    await addToComparison(page, schoolOfType(schools, "Primary", 0));
    await addToComparison(page, schoolOfType(schools, "Primary", 1));
    await page.goto("/compare");
    await page.getByLabel("Show only differences").check();
    await expect(comparisonRow(page, "Education level")).toHaveCount(0);
  });

  test("without a home location the distance links to the home form", async ({ page, schools }) => {
    await addToComparison(page, schools[0]);
    await addToComparison(page, schools[1]);
    await page.goto("/compare");
    await expect(comparisonRow(page, "Distance from home").getByRole("link", { name: "Set home postal code" })).toHaveCount(2);
  });

  test("with a home location the distance comes from OneMap", async ({ page, api, schools }) => {
    test.skip(!(await api.trySetHome(REAL_POSTAL_CODE)), "OneMap is unavailable or its token has expired");
    await addToComparison(page, schools[0]);
    await addToComparison(page, schools[1]);
    await page.goto("/compare");
    await expect(comparisonRow(page, "Distance from home").getByRole("cell").first()).toContainText(/by road|straight line/);
  });

  test("a school can be removed from the table", async ({ page, schools }) => {
    const chosen: School[] = schools.slice(0, 3);
    for (const school of chosen) await addToComparison(page, school);
    await page.goto("/compare");
    await page.getByRole("button", { name: `Remove ${chosen[0].name} from comparison`, exact: true }).click();
    await expect(page.getByText("2 schools")).toBeVisible();
    await expect(page.getByRole("link", { name: chosen[0].name, exact: true })).toHaveCount(0);
  });

  test("the comparison can be cleared", async ({ page, schools }) => {
    await addToComparison(page, schools[0]);
    await addToComparison(page, schools[1]);
    await page.goto("/compare");
    await page.getByRole("button", { name: "Clear comparison" }).click();
    await expect(page.getByRole("heading", { name: "Pick schools to compare" })).toBeVisible();
  });

  test("the tray stops at five schools", async ({ page }) => {
    await page.goto("/schools");
    const rows = schoolRows(page);
    for (let index = 0; index < 5; index++) await rows.nth(index).getByRole("button", { name: /to comparison$/ }).click();
    const tray = page.getByRole("region", { name: "Comparison selection" });
    await expect(tray).toContainText("5 of 5 schools");
    await expect(tray).toContainText("Remove one to add another");
    await expect(rows.nth(5).getByRole("button", { name: /to comparison$/ })).toBeDisabled();
  });

  test("the tray needs two schools before comparing", async ({ page, schools }) => {
    await addToComparison(page, schools[0]);
    const tray = page.getByRole("region", { name: "Comparison selection" });
    await expect(tray).toContainText("Add one more to compare");
    await expect(tray.getByRole("button", { name: "Compare schools" })).toBeDisabled();
  });
});
