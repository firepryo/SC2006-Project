import { expect, REAL_POSTAL_CODE, test } from "./support";

interface Subject {
  subject_name: string;
  level: string;
}

test.describe("student profiles", () => {
  test("an account without students is sent to the profile form", async ({ page, signedIn }) => {
    expect(signedIn.email).toBeTruthy();
    await page.goto("/schools");
    await expect(page).toHaveURL(/\/profiles$/);
    await expect(page.getByRole("heading", { name: "Add your first student" })).toBeVisible();
  });

  test("saving the first student opens school search", async ({ page, signedIn }) => {
    expect(signedIn.email).toBeTruthy();
    await page.goto("/profiles");
    await page.getByLabel("Name", { exact: true }).fill("Asha");
    await page.getByLabel("Current level").selectOption("Secondary");
    await page.getByLabel("Year").selectOption("2");
    await page.getByRole("button", { name: "Save profile" }).click();
    await expect(page).toHaveURL(/\/schools$/);
    await expect(page.getByRole("banner")).toContainText("Asha");
  });

  for (const [level, years] of [["Primary", 6], ["Secondary", 5], ["JuniorCollege", 2]] as const) {
    test(`${level} offers ${years} years`, async ({ page, signedIn }) => {
      expect(signedIn.email).toBeTruthy();
      await page.goto("/profiles");
      await page.getByLabel("Current level").selectOption(level);
      await expect(page.getByLabel("Year").locator("option")).toHaveCount(years);
    });
  }

  test("preferred subjects follow the chosen level", async ({ page, api, signedIn }) => {
    expect(signedIn.email).toBeTruthy();
    const subjects = await api.get<Subject[]>("/subjects");
    const countFor = (level: string) => subjects.filter(subject => subject.level === level).length;
    await page.goto("/profiles");
    const choices = page.getByRole("group", { name: "Preferred subjects" }).getByRole("checkbox");
    await expect(choices).toHaveCount(countFor("Primary"));
    await page.getByLabel("Current level").selectOption("Secondary");
    await expect(choices).toHaveCount(countFor("Secondary"));
  });

  test("real CCAs are offered", async ({ page, api, signedIn }) => {
    expect(signedIn.email).toBeTruthy();
    const ccas = await api.get<unknown[]>("/ccas");
    await page.goto("/profiles");
    await expect(page.getByRole("group", { name: "Preferred CCAs" }).getByRole("checkbox")).toHaveCount(ccas.length);
  });

  test("a student can be edited", async ({ page, student }) => {
    await page.goto("/profiles");
    await page.getByRole("row", { name: new RegExp(student.name) }).getByRole("button", { name: "Edit" }).click();
    await page.getByLabel("Name", { exact: true }).fill("Renamed Child");
    await page.getByRole("button", { name: "Save profile" }).click();
    await expect(page.getByRole("status")).toContainText("Renamed Child saved and selected.");
    await expect(page.getByRole("row", { name: /Renamed Child/ })).toBeVisible();
  });

  test("a second student can be added and selected", async ({ page, api, student }) => {
    await api.createStudent("Second Child");
    await page.goto("/profiles");
    await expect(page.getByRole("row", { name: new RegExp(student.name) })).toContainText("Selected");
    const second = page.getByRole("row", { name: /Second Child/ });
    await second.getByRole("button", { name: "Select" }).click();
    await expect(second).toContainText("Selected");
    await expect(page.getByRole("banner")).toContainText("Second Child");
  });

  test("removing a student asks for confirmation", async ({ page, api, student }) => {
    await api.createStudent("Second Child");
    await page.goto("/profiles");
    const row = page.getByRole("row", { name: new RegExp(student.name) });
    await row.getByRole("button", { name: "Remove" }).click();
    await row.getByRole("button", { name: "Cancel" }).click();
    await expect(row).toBeVisible();
    await row.getByRole("button", { name: "Remove" }).click();
    await row.getByRole("button", { name: "Remove" }).click();
    await expect(page.getByRole("status")).toContainText(`${student.name} removed.`);
    await expect(page.getByRole("row", { name: new RegExp(student.name) })).toHaveCount(0);
  });

  test("a student with a shortlisted school cannot be removed", async ({ page, api, student, schools }) => {
    await api.addToShortlist(student, schools[0]);
    await page.goto("/profiles");
    const row = page.getByRole("row", { name: new RegExp(student.name) });
    await row.getByRole("button", { name: "Remove" }).click();
    await row.getByRole("button", { name: "Remove" }).click();
    await expect(page.getByRole("alert")).toContainText("still has shortlisted schools");
    await expect(row).toBeVisible();
  });
});

test.describe("home page", () => {
  test("shows the active student with no deadlines", async ({ page, student }) => {
    await page.goto("/home");
    await expect(page.getByRole("region", { name: `${student.name}’s overview` })).toContainText("No deadlines set");
  });

  test("shows the shortlist and applications", async ({ page, api, student, schools }) => {
    await api.addToShortlist(student, schools[0]);
    await api.createApplication(student, schools[1]);
    await page.goto("/home");
    await expect(page.getByRole("region", { name: "Shortlist" })).toContainText(schools[0].name);
    await expect(page.getByRole("region", { name: "Applications" })).toContainText(schools[1].name);
  });

  test("a malformed home postal code is rejected", async ({ page, signedIn }) => {
    expect(signedIn.email).toBeTruthy();
    await page.goto("/home");
    await page.getByRole("textbox", { name: /^Postal code/ }).fill("12345");
    await page.getByRole("button", { name: "Save" }).click();
    await expect(page.getByRole("alert")).toHaveText("Postal code must be 6 digits.");
  });

  test("a real home postal code is saved through OneMap", async ({ page, api, signedIn }) => {
    expect(signedIn.email).toBeTruthy();
    test.skip(!(await api.trySetHome(REAL_POSTAL_CODE)), "OneMap is unavailable or its token has expired");
    await api.trySetHome("");
    await page.goto("/home");
    await page.getByRole("textbox", { name: /^Postal code/ }).fill(REAL_POSTAL_CODE);
    await page.getByRole("button", { name: "Save" }).click();
    await expect(page.getByRole("status")).toContainText("Distances are now measured from this postal code.");
  });
});
