import { test as base, expect, type Locator, type Page } from "@playwright/test";

export { expect };

export const PASSWORD = "CorrectHorse1";
export const MIN_REAL_SCHOOLS = 300;
export const REAL_POSTAL_CODE = "119077";
export const LOAD_ERROR = "This information didn’t load";

export interface Account {
  name: string;
  email: string;
  password: string;
}

export interface Student {
  student_id: string;
  name: string;
}

export interface School {
  school_id: string;
  name: string;
  type: string;
  zone: string | null;
  planning_area: string | null;
}

export interface SchoolDetails extends School {
  subjects: { subject_id: string; subject_name: string; level: string }[];
  ccas: { cca_id: string; cca_name: string }[];
}

export interface Application {
  application_id: string;
}

export interface ShortlistEntry {
  entry_id: string;
}

export const uniqueEmail = () => `user-${crypto.randomUUID().slice(0, 12)}@e2e-test.local`;

export const newAccount = (name = "E2E Parent"): Account => ({ name, email: uniqueEmail(), password: PASSWORD });

export const dateInDays = (days: number) => {
  const date = new Date();
  date.setDate(date.getDate() + days);
  return date.toLocaleDateString("en-CA");
};

export class Api {
  constructor(private readonly page: Page) {}

  private async headers() {
    const cookies = await this.page.context().cookies();
    const csrf = cookies.find(cookie => cookie.name === "csrf_access_token");
    return csrf ? { "X-CSRF-TOKEN": csrf.value } : undefined;
  }

  private async send<T>(method: "post" | "put" | "patch", path: string, data?: unknown): Promise<T> {
    const response = await this.page.request[method](`/api${path}`, { data, headers: await this.headers() });
    expect(response.ok(), `${method.toUpperCase()} ${path} answered ${response.status()}`).toBe(true);
    return response.json();
  }

  async get<T>(path: string): Promise<T> {
    const response = await this.page.request.get(`/api${path}`);
    expect(response.ok(), `GET ${path} answered ${response.status()}`).toBe(true);
    return response.json();
  }

  register(account: Account, extra: Record<string, unknown> = {}) {
    return this.send("post", "/auth/register", { ...account, ...extra });
  }

  login(account: Account) {
    return this.send("post", "/auth/login", { email: account.email, password: account.password });
  }

  createStudent(name: string, level = "Secondary", year = 1) {
    return this.send<Student>("post", "/profiles", { name, current_level: level, current_year: year });
  }

  addToShortlist(student: Student, school: School) {
    return this.send<ShortlistEntry>("post", `/profiles/${student.student_id}/shortlist/entries`, { school_id: school.school_id });
  }

  createApplication(student: Student, school: School) {
    return this.send<Application>("post", "/applications", { student_id: student.student_id, school_id: school.school_id });
  }

  setDeadline(application: Application, deadline: string) {
    return this.send("put", `/applications/${application.application_id}/deadline`, { deadline });
  }

  setStatus(application: Application, status: string) {
    return this.send("patch", `/applications/${application.application_id}/status`, { status });
  }

  schoolDetails(school: School) {
    return this.get<SchoolDetails>(`/schools/${school.school_id}`);
  }

  async trySetHome(postalCode: string) {
    const response = await this.page.request.patch("/api/users/me", {
      data: { preferred_postal_code: postalCode },
      headers: await this.headers(),
    });
    return response.ok();
  }
}

interface Fixtures {
  api: Api;
  account: Account;
  signedIn: Account;
  student: Student;
  schools: School[];
}

export const test = base.extend<Fixtures>({
  api: async ({ page }, use) => {
    await use(new Api(page));
  },
  account: async ({ api }, use) => {
    const account = newAccount();
    await api.register(account);
    await use(account);
  },
  signedIn: async ({ api, account }, use) => {
    await api.login(account);
    await use(account);
  },
  student: async ({ api, signedIn }, use) => {
    expect(signedIn.email).toBeTruthy();
    await use(await api.createStudent("Test Child"));
  },
  schools: async ({ api, signedIn }, use) => {
    expect(signedIn.email).toBeTruthy();
    const schools = await api.get<School[]>("/schools");
    expect(schools.length, "Run flask sync-schools first").toBeGreaterThanOrEqual(MIN_REAL_SCHOOLS);
    await use(schools);
  },
});

export const schoolOfType = (schools: School[], type: string, offset = 0) => schools.filter(school => school.type === type)[offset];

export const resultCount = (page: Page) => page.locator(".results-toolbar").getByRole("status");

export const schoolRows = (page: Page) => page.locator("article.school-row");

export const comparisonRow = (page: Page, label: string): Locator =>
  page.locator("table.comparison-table tbody tr", { has: page.getByRole("rowheader", { name: label }) });

export async function addToComparison(page: Page, school: School) {
  await page.goto(`/schools?q=${encodeURIComponent(school.name)}`);
  await page.getByRole("button", { name: `Add ${school.name} to comparison`, exact: true }).click();
  await expect(page.getByRole("button", { name: `Remove ${school.name} from comparison`, exact: true }).first()).toBeVisible();
}
