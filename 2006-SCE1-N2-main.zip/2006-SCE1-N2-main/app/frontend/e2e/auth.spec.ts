import { expect, newAccount, PASSWORD, test } from "./support";

async function fillRegistration(page: import("@playwright/test").Page, account: { name: string; email: string; password: string }, postal = "") {
  await page.goto("/register");
  await page.getByLabel("Name").fill(account.name);
  await page.getByLabel("Email").fill(account.email);
  await page.getByLabel("Password").fill(account.password);
  if (postal) await page.getByLabel("Home postal code").fill(postal);
  await page.getByRole("button", { name: "Create account" }).click();
}

async function logIn(page: import("@playwright/test").Page, email: string, password: string) {
  await page.getByLabel("Email").fill(email);
  await page.getByLabel("Password").fill(password);
  await page.getByRole("button", { name: "Log in" }).click();
}

test.describe("public pages", () => {
  test("landing page is public and links to registration", async ({ page }) => {
    await page.goto("/");
    await expect(page.getByRole("heading", { level: 1 })).toContainText("Every school");
    await page.getByRole("link", { name: "Create an account" }).first().click();
    await expect(page).toHaveURL(/\/register$/);
  });

  test("landing page links to login", async ({ page }) => {
    await page.goto("/");
    await page.getByRole("link", { name: "I already have one" }).click();
    await expect(page).toHaveURL(/\/login$/);
  });

  for (const path of ["/home", "/profiles", "/schools", "/compare", "/shortlist", "/applications", "/notifications"]) {
    test(`${path} redirects to login without a session`, async ({ page }) => {
      await page.goto(path);
      await expect(page).toHaveURL(/\/login$/);
    });
  }
});

test.describe("registration", () => {
  test("a new account continues to login with the email filled in", async ({ page }) => {
    const account = newAccount();
    await fillRegistration(page, account);
    await expect(page).toHaveURL(/\/login$/);
    await expect(page.getByText("Account created. Log in to continue.")).toBeVisible();
    await expect(page.getByLabel("Email")).toHaveValue(account.email);
  });

  test("a short password is rejected", async ({ page }) => {
    await fillRegistration(page, { ...newAccount(), password: "short" });
    await expect(page.getByRole("alert")).toHaveText("Password must be at least 8 characters.");
    await expect(page).toHaveURL(/\/register$/);
  });

  test("a malformed postal code is rejected", async ({ page }) => {
    await fillRegistration(page, newAccount(), "12345");
    await expect(page.getByRole("alert")).toHaveText("Postal code must be 6 digits.");
  });

  test("a duplicate email is rejected", async ({ page, account }) => {
    await fillRegistration(page, { ...newAccount(), email: account.email });
    await expect(page.getByRole("alert")).toContainText("already exists");
    await expect(page).toHaveURL(/\/register$/);
  });
});

test.describe("login", () => {
  test("correct credentials open the home page", async ({ page, account }) => {
    await page.goto("/login");
    await logIn(page, account.email, account.password);
    await expect(page).toHaveURL(/\/home$/);
    await expect(page.getByRole("heading", { name: `Welcome, ${account.name}` })).toBeVisible();
  });

  test("a wrong password shows an error and clears the field", async ({ page, account }) => {
    await page.goto("/login");
    await logIn(page, account.email, "WrongPassword1");
    await expect(page.getByRole("alert")).toContainText("Incorrect email or password");
    await expect(page.getByLabel("Password")).toHaveValue("");
    await expect(page).toHaveURL(/\/login$/);
  });

  test("an unknown email shows the same error", async ({ page }) => {
    await page.goto("/login");
    await logIn(page, newAccount().email, PASSWORD);
    await expect(page.getByRole("alert")).toContainText("Incorrect email or password");
  });

  test("five wrong passwords lock the account", async ({ page, account }) => {
    await page.goto("/login");
    for (let attempt = 1; attempt <= 4; attempt++) {
      await logIn(page, account.email, "WrongPassword1");
      await expect(page.getByRole("alert")).toContainText("Incorrect email or password");
    }
    await logIn(page, account.email, "WrongPassword1");
    await expect(page.getByRole("alert")).toContainText(/too many/i);
  });

  test("the session survives a reload", async ({ page, signedIn }) => {
    await page.goto("/home");
    await page.reload();
    await expect(page.getByRole("heading", { name: `Welcome, ${signedIn.name}` })).toBeVisible();
  });

  test("a signed-in visitor to the login page goes home", async ({ page, signedIn }) => {
    expect(signedIn.email).toBeTruthy();
    await page.goto("/login");
    await expect(page).toHaveURL(/\/home$/);
  });

  test("logging out ends the session", async ({ page, signedIn }) => {
    expect(signedIn.email).toBeTruthy();
    await page.goto("/home");
    await page.getByRole("button", { name: "Log out" }).click();
    await expect(page).toHaveURL(/\/$/);
    await page.goto("/home");
    await expect(page).toHaveURL(/\/login$/);
  });
});
