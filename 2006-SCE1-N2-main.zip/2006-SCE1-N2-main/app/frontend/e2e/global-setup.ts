const backendUrl = process.env.E2E_BACKEND_URL ?? "http://localhost:5000";

export default async function globalSetup() {
  let status: number;
  try {
    status = (await fetch(`${backendUrl}/api/subjects`)).status;
  } catch {
    throw new Error(`The backend is not reachable at ${backendUrl}. Start the Flask API and sync the schools first.`);
  }
  if (status !== 401) {
    throw new Error(`Expected ${backendUrl}/api/subjects to answer 401 without a session, but it answered ${status}.`);
  }
}
