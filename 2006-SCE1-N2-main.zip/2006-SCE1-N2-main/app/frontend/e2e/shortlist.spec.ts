import { expect, test } from "./support";

test.describe("shortlist", () => {
  test.beforeEach(async ({ student }) => {
    expect(student.student_id).toBeTruthy();
  });

  test("starts empty", async ({ page, student }) => {
    await page.goto("/shortlist");
    await expect(page.getByRole("heading", { name: `${student.name}’s shortlist` })).toBeVisible();
    await expect(page.getByRole("heading", { name: "Nothing on the shortlist yet" })).toBeVisible();
  });

  test("the bookmark adds a school", async ({ page, student, schools }) => {
    await page.goto(`/schools?q=${encodeURIComponent(schools[0].name)}`);
    await page.getByRole("button", { name: `Add ${schools[0].name} to ${student.name}'s shortlist`, exact: true }).click();
    await expect(page.getByRole("button", { name: `Remove ${schools[0].name} from ${student.name}'s shortlist`, exact: true })).toBeVisible();
    await expect(page.getByRole("navigation", { name: "Main navigation" }).getByLabel("1 saved")).toBeVisible();
    await page.goto("/shortlist");
    await expect(page.getByRole("row", { name: new RegExp(schools[0].name) })).toBeVisible();
  });

  test("the bookmark removes a saved school", async ({ page, api, student, schools }) => {
    await api.addToShortlist(student, schools[0]);
    await page.goto(`/schools?q=${encodeURIComponent(schools[0].name)}`);
    await page.getByRole("button", { name: `Remove ${schools[0].name} from ${student.name}'s shortlist`, exact: true }).click();
    await expect(page.getByRole("button", { name: `Add ${schools[0].name} to ${student.name}'s shortlist`, exact: true })).toBeVisible();
  });

  test("removing from the list asks for confirmation", async ({ page, api, student, schools }) => {
    await api.addToShortlist(student, schools[0]);
    await page.goto("/shortlist");
    const row = page.getByRole("row", { name: new RegExp(schools[0].name) });
    await row.getByRole("button", { name: "Remove", exact: true }).click();
    await row.getByRole("button", { name: "Cancel" }).click();
    await expect(row).toBeVisible();
    await row.getByRole("button", { name: "Remove", exact: true }).click();
    await row.getByRole("button", { name: "Remove", exact: true }).click();
    await expect(page.getByRole("heading", { name: "Nothing on the shortlist yet" })).toBeVisible();
  });

  test("shortlists belong to the selected student", async ({ page, api, student, schools }) => {
    await api.addToShortlist(student, schools[0]);
    const second = await api.createStudent("Second Child");
    await page.goto("/profiles");
    await page.getByRole("row", { name: new RegExp(second.name) }).getByRole("button", { name: "Select" }).click();
    await page.getByRole("link", { name: "Shortlist" }).click();
    await expect(page.getByRole("heading", { name: `${second.name}’s shortlist` })).toBeVisible();
    await expect(page.getByRole("heading", { name: "Nothing on the shortlist yet" })).toBeVisible();
  });

  test("an application can be started from the list", async ({ page, api, student, schools }) => {
    await api.addToShortlist(student, schools[0]);
    await page.goto("/shortlist");
    await page.getByRole("button", { name: "Start application" }).click();
    await expect(page).toHaveURL(/\/applications\/[0-9a-f-]{36}$/);
    await expect(page.getByRole("heading", { level: 1, name: schools[0].name })).toBeVisible();
    await page.goto("/shortlist");
    await expect(page.getByRole("button", { name: "Start application" })).toHaveCount(0);
    await expect(page.getByRole("row", { name: new RegExp(schools[0].name) })).toContainText("Draft");
  });
});
