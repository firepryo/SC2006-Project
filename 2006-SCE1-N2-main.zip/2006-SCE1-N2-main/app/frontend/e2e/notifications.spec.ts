import { execSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { dateInDays, expect, newAccount, test } from "./support";

const repositoryRoot = fileURLToPath(new URL("../../..", import.meta.url));
const checkDeadlinesCommand = process.env.E2E_CHECK_DEADLINES_COMMAND;

test.describe("notifications", () => {
  test("nothing due shows the empty state", async ({ page, signedIn }) => {
    expect(signedIn.email).toBeTruthy();
    await page.goto("/notifications");
    await expect(page.getByRole("heading", { name: "Nothing due in the next 7 days" })).toBeVisible();
  });

  test("opted-out accounts are told reminders are off", async ({ page, api }) => {
    const account = newAccount();
    await api.register(account, { notification_opt_in: false });
    await api.login(account);
    await page.goto("/notifications");
    await expect(page.getByRole("heading", { name: "Deadline reminders are off" })).toBeVisible();
  });

  test("reminders can be turned off and on", async ({ page, signedIn }) => {
    expect(signedIn.email).toBeTruthy();
    await page.goto("/notifications/preferences");
    await page.getByRole("radio", { name: "Off" }).click();
    await expect(page.getByRole("status")).toContainText("Deadline reminders turned off.");
    await page.goto("/notifications");
    await expect(page.getByRole("heading", { name: "Deadline reminders are off" })).toBeVisible();
    await page.getByRole("link", { name: "Turn on reminders" }).click();
    await page.getByRole("radio", { name: /^On/ }).click();
    await expect(page.getByRole("status")).toContainText("Deadline reminders turned on.");
    await page.goto("/notifications");
    await expect(page.getByRole("heading", { name: "Nothing due in the next 7 days" })).toBeVisible();
  });

  test("the reminder job creates a notification that opening marks as read", async ({ page, api, student, schools }) => {
    test.skip(!checkDeadlinesCommand, "Set E2E_CHECK_DEADLINES_COMMAND to run the reminder job");
    const application = await api.createApplication(student, schools[0]);
    await api.setDeadline(application, dateInDays(3));
    execSync(checkDeadlinesCommand!, { cwd: repositoryRoot, stdio: "pipe" });

    await page.goto("/notifications");
    const item = page.locator(".notification-list li", { hasText: schools[0].name });
    await expect(item).toContainText("New");
    await expect(item).toContainText("Application deadline in 3 days");
    await expect(page.getByRole("navigation", { name: "Main navigation" }).getByLabel("1 unread")).toBeVisible();

    await item.getByRole("button", { name: "Open application" }).click();
    await expect(page).toHaveURL(new RegExp(`/applications/${application.application_id}$`));

    await page.goto("/notifications");
    await expect(page.locator(".notification-list li", { hasText: schools[0].name })).not.toContainText("New");
    await expect(page.getByRole("navigation", { name: "Main navigation" }).getByLabel("1 unread")).toHaveCount(0);
  });
});
