import { expect, LOAD_ERROR, REAL_POSTAL_CODE, resultCount, type School, schoolRows, test } from "./support";

const countText = (count: number) => `${count} ${count === 1 ? "school" : "schools"}`;

test.describe("school search", () => {
  test.beforeEach(async ({ student }) => {
    expect(student.student_id).toBeTruthy();
  });

  test("lists every real school", async ({ page, schools }) => {
    await page.goto("/schools");
    await expect(resultCount(page)).toHaveText(countText(schools.length));
    await expect(schoolRows(page)).toHaveCount(6);
  });

  test("zone filter offers exactly the backend zones", async ({ page }) => {
    await page.goto("/schools");
    await expect(page.getByLabel("School zone").locator("option")).toHaveText(["All zones", "East", "North", "South", "West"]);
  });

  for (const zone of ["East", "North", "South", "West"]) {
    test(`${zone} zone shows its real schools`, async ({ page, schools }) => {
      const expected = schools.filter(school => school.zone === zone.toUpperCase());
      expect(expected.length).toBeGreaterThan(0);
      await page.goto("/schools");
      await page.getByLabel("School zone").selectOption(zone);
      await expect(resultCount(page)).toHaveText(countText(expected.length));
      await expect(page.getByText(LOAD_ERROR)).toHaveCount(0);
    });
  }

  test("the search box only promises what the backend searches", async ({ page }) => {
    await page.goto("/schools");
    await expect(page.getByRole("searchbox", { name: "Search schools" })).toHaveAttribute("placeholder", "School name");
  });

  test("searching by name narrows the results", async ({ page, schools }) => {
    const expected = schools.filter(school => school.name.toLowerCase().includes("raffles"));
    await page.goto("/schools");
    await page.getByRole("searchbox", { name: "Search schools" }).fill("raffles");
    await expect(resultCount(page)).toHaveText(countText(expected.length));
    for (const school of expected) await expect(page.getByRole("link", { name: school.name, exact: true })).toBeVisible();
  });

  test("a search with no match can be cleared", async ({ page, schools }) => {
    await page.goto("/schools?q=zzz-no-such-school");
    await expect(page.getByRole("heading", { name: "No schools match" })).toBeVisible();
    await page.getByRole("button", { name: "Clear search and filters" }).click();
    await expect(resultCount(page)).toHaveText(countText(schools.length));
  });

  for (const [label, level] of [["Primary", "Primary"], ["Secondary", "Secondary"], ["Junior college", "JuniorCollege"]]) {
    test(`${label} filter matches the API`, async ({ page, api }) => {
      const expected = await api.get<School[]>(`/schools?level=${level}`);
      await page.goto("/schools");
      await page.getByRole("radio", { name: label }).check();
      await expect(resultCount(page)).toHaveText(countText(expected.length));
    });
  }

  test("subject filter matches the API", async ({ page, api }) => {
    const subjects = await api.get<{ subject_id: string; subject_name: string }[]>("/subjects");
    const subject = subjects.find(item => item.subject_name === "Additional Mathematics") ?? subjects[0];
    const expected = await api.get<School[]>(`/schools?subject_id=${subject.subject_id}`);
    await page.goto("/schools");
    await page.getByLabel("Subject offered").selectOption(subject.subject_id);
    await expect(resultCount(page)).toHaveText(countText(expected.length));
  });

  test("activity filter matches the API", async ({ page, api }) => {
    const ccas = await api.get<{ cca_id: string }[]>("/ccas");
    const expected = await api.get<School[]>(`/schools?cca_id=${ccas[0].cca_id}`);
    await page.goto("/schools");
    await page.getByLabel("Co-curricular activity").selectOption(ccas[0].cca_id);
    await expect(resultCount(page)).toHaveText(countText(expected.length));
  });

  test("an active filter can be removed from its token", async ({ page, schools }) => {
    await page.goto("/schools?zone=North");
    await page.getByRole("button", { name: "Remove North filter" }).click();
    await expect(resultCount(page)).toHaveText(countText(schools.length));
    await expect(page).not.toHaveURL(/zone=/);
  });

  test("reset clears the filters and keeps the search text", async ({ page }) => {
    await page.goto("/schools?q=raffles&zone=South");
    await page.getByRole("button", { name: "Reset" }).click();
    await expect(page).toHaveURL(/\/schools\?q=raffles$/);
  });

  test("results are paginated", async ({ page, schools }) => {
    await page.goto("/schools");
    await expect(page.getByText(`Showing 1–6 of ${schools.length}`)).toBeVisible();
    await page.getByRole("button", { name: "Next page" }).click();
    await expect(page.getByText(`Showing 7–12 of ${schools.length}`)).toBeVisible();
    await expect(page.getByRole("button", { name: "Page 2", exact: true })).toHaveAttribute("aria-current", "page");
  });

  test("results can be sorted Z to A", async ({ page, schools }) => {
    const last = [...schools].sort((a, b) => b.name.localeCompare(a.name))[0];
    await page.goto("/schools");
    await page.getByLabel("Sort by").selectOption("za");
    await expect(schoolRows(page).first()).toContainText(last.name);
  });

  test("without a home location the distance is requested", async ({ page }) => {
    await page.goto("/schools");
    await expect(schoolRows(page).first()).toContainText("Set your home postal code to see distance");
  });

  test("with a home location the distance is shown", async ({ page, api }) => {
    test.skip(!(await api.trySetHome(REAL_POSTAL_CODE)), "OneMap is unavailable or its token has expired");
    await page.goto("/schools");
    await expect(schoolRows(page).first()).toContainText("from home, straight line");
  });
});

test.describe("school details", () => {
  test.beforeEach(async ({ student }) => {
    expect(student.student_id).toBeTruthy();
  });

  test("opens from the results with its real data", async ({ page, api, schools }) => {
    const details = await api.schoolDetails(schools[0]);
    await page.goto("/schools");
    await page.getByRole("link", { name: schools[0].name, exact: true }).click();
    await expect(page.getByRole("heading", { level: 1, name: schools[0].name })).toBeVisible();
    await expect(page.locator("#subjects")).toContainText(`${details.subjects.length} subjects`);
    await expect(page.locator("#activities")).toContainText(`${details.ccas.length} activities`);
  });

  test("the back link returns to the same search", async ({ page }) => {
    await page.goto("/schools?q=raffles");
    await schoolRows(page).first().getByRole("link").click();
    await page.getByRole("link", { name: "All schools" }).click();
    await expect(page).toHaveURL(/\/schools\?q=raffles$/);
  });

  test("an unknown school shows an error", async ({ page }) => {
    await page.goto("/schools/00000000-0000-4000-8000-000000000000");
    await expect(page.getByRole("heading", { name: LOAD_ERROR })).toBeVisible();
  });

  test("the route is shown when a home location exists", async ({ page, api, schools }) => {
    test.skip(!(await api.trySetHome(REAL_POSTAL_CODE)), "OneMap is unavailable or its token has expired");
    await page.goto(`/schools/${schools[0].school_id}`);
    await expect(page.getByRole("complementary", { name: "Location and contact" })).toContainText(/km/);
  });
});
