"""Account and profile tables (DATA-01 §3.3 "Account and profile")."""
import uuid
from datetime import datetime

from geoalchemy2 import Geography, WKBElement
from sqlalchemy import CHAR, CheckConstraint, DateTime, Enum, ForeignKey, SmallInteger, String, Text, func, text, true
from sqlalchemy.dialects.postgresql import CITEXT, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.extensions import db
from app.models.enums import EducationLevel


class UserAccount(db.Model):
    """Table: user_account (DATA-01 §3.3)."""

    __tablename__ = "user_account"
    __table_args__ = (CheckConstraint("failed_login_count >= 0"),)  # NFR 3.5.1

    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, server_default=func.gen_random_uuid())
    name: Mapped[str] = mapped_column(String(100))
    email: Mapped[str] = mapped_column(CITEXT, unique=True)  # FR 1.4
    password_hash: Mapped[str] = mapped_column(Text)
    failed_login_count: Mapped[int] = mapped_column(SmallInteger, server_default=text("0"))  # NFR 3.5.1
    locked_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))  # NFR 3.5.1
    preferred_postal_code: Mapped[str | None] = mapped_column(CHAR(6))
    home_location: Mapped[WKBElement | None] = mapped_column(
        Geography("POINT", srid=4326, spatial_index=False)  # geocoded from postal code
    )
    notification_opt_in: Mapped[bool] = mapped_column(server_default=true())  # FR 11.2
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class StudentProfile(db.Model):
    """Table: student_profile (DATA-01 §3.3)."""

    __tablename__ = "student_profile"
    __table_args__ = (CheckConstraint("current_year BETWEEN 1 AND 6"),)

    student_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, server_default=func.gen_random_uuid())
    user_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("user_account.user_id", ondelete="CASCADE"), index=True)  # ondelete="CASCADE": deleting a user_account row also deletes its student_profile rows
    name: Mapped[str | None] = mapped_column(String(100))
    current_level: Mapped[EducationLevel] = mapped_column(Enum(EducationLevel, name="education_level"))  # FR 3.4
    current_year: Mapped[int] = mapped_column(SmallInteger)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class StudentPreferredSubject(db.Model):
    """Table: student_preferred_subject (DATA-01 §3.3)."""

    __tablename__ = "student_preferred_subject"

    student_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("student_profile.student_id", ondelete="CASCADE"), primary_key=True)
    subject_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("subject.subject_id", ondelete="CASCADE"), primary_key=True)


class StudentPreferredCca(db.Model):
    """Table: student_preferred_cca (DATA-01 §3.3)."""

    __tablename__ = "student_preferred_cca"

    student_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("student_profile.student_id", ondelete="CASCADE"), primary_key=True)
    cca_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("cca.cca_id", ondelete="CASCADE"), primary_key=True)
