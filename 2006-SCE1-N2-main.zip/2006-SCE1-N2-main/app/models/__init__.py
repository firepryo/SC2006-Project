"""All DATA-01 tables. Importing this package registers every model on db.metadata."""
from app.models.account import StudentPreferredCca, StudentPreferredSubject, StudentProfile, UserAccount
from app.models.application import Application, ComparisonCriterion, DeadlineReminder, Shortlist, ShortlistEntry
from app.models.enums import ApplicationStatus, CcaCategory, EducationLevel, SchoolType, SyncStatus
from app.models.school import Affiliation, Cca, School, SchoolCca, SchoolSubject, SchoolSyncLog, Subject

__all__ = [
    "Affiliation",
    "Application",
    "ApplicationStatus",
    "Cca",
    "CcaCategory",
    "ComparisonCriterion",
    "DeadlineReminder",
    "EducationLevel",
    "School",
    "SchoolCca",
    "SchoolSubject",
    "SchoolSyncLog",
    "SchoolType",
    "Shortlist",
    "ShortlistEntry",
    "StudentPreferredCca",
    "StudentPreferredSubject",
    "StudentProfile",
    "Subject",
    "SyncStatus",
    "UserAccount",
]
