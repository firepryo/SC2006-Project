"""Enums from DATA-01 §3.2. Member names equal the values stored in PostgreSQL."""
import enum


class EducationLevel(enum.Enum):
    """Enum: education_level (DATA-01 §3.2)."""

    Primary = "Primary"
    Secondary = "Secondary"
    JuniorCollege = "JuniorCollege"


class SchoolType(enum.Enum):
    """Enum: school_type (DATA-01 §3.2, ADR-002)."""

    Primary = "Primary"
    Secondary = "Secondary"
    JuniorCollege = "JuniorCollege"
    MixedLevels = "MixedLevels"


class CcaCategory(enum.Enum):
    """Enum: cca_category (DATA-01 §3.2, ADR-006)."""

    Sports = "Sports"
    PerformingArts = "PerformingArts"
    UniformedGroup = "UniformedGroup"
    ClubSociety = "ClubSociety"
    Others = "Others"


class ApplicationStatus(enum.Enum):
    """Enum: application_status (DATA-01 §3.2)."""

    Draft = "Draft"
    Submitted = "Submitted"
    UnderReview = "UnderReview"
    Offered = "Offered"
    Rejected = "Rejected"
    Accepted = "Accepted"


class SyncStatus(enum.Enum):
    """Enum: sync_status (DATA-01 §3.2)."""

    Success = "Success"
    Failed = "Failed"
    Partial = "Partial"
