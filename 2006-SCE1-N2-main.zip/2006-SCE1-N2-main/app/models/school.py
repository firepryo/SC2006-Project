"""School catalogue tables, synced from data.gov.sg (DATA-01 §3.3 "School catalogue")."""
import uuid
from datetime import datetime

from geoalchemy2 import Geography, WKBElement
from sqlalchemy import (
    BigInteger,
    CHAR,
    CheckConstraint,
    DateTime,
    Enum,
    ForeignKey,
    String,
    Text,
    UniqueConstraint,
    false,
    func,
    text,
    true,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.extensions import db
from app.models.enums import CcaCategory, EducationLevel, SchoolType, SyncStatus


class School(db.Model):
    """Table: school (DATA-01 §3.3; field mapping in §3.8)."""

    __tablename__ = "school"
    __table_args__ = (CheckConstraint("postal_code ~ '^[0-9]{6}$'"),)

    school_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, server_default=func.gen_random_uuid())
    name: Mapped[str] = mapped_column(String(150), unique=True)  # sync upsert key (ADR-001)
    type: Mapped[SchoolType] = mapped_column(Enum(SchoolType, name="school_type"), index=True)  # ADR-002
    main_level: Mapped[str] = mapped_column(String(50))  # raw mainlevel_code
    address: Mapped[str] = mapped_column(Text)
    postal_code: Mapped[str | None] = mapped_column(CHAR(6))
    location: Mapped[WKBElement | None] = mapped_column(
        Geography("POINT", srid=4326, spatial_index=True)  # GiST index; geocoded via OneMap (ADR-003)
    )
    zone: Mapped[str | None] = mapped_column(String(10), index=True)  # FR 5.1
    planning_area: Mapped[str | None] = mapped_column(String(50), index=True)  # FR 5.1
    funding_type: Mapped[str | None] = mapped_column(String(50))
    gender_type: Mapped[str | None] = mapped_column(String(20))
    session_type: Mapped[str | None] = mapped_column(String(20))
    website: Mapped[str | None] = mapped_column(Text)
    telephone: Mapped[str | None] = mapped_column(String(20))
    email: Mapped[str | None] = mapped_column(String(254))
    mrt_desc: Mapped[str | None] = mapped_column(Text)
    bus_desc: Mapped[str | None] = mapped_column(Text)
    description: Mapped[str | None] = mapped_column(Text)
    is_active: Mapped[bool] = mapped_column(server_default=true())
    last_synced_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class Subject(db.Model):
    """Table: subject (DATA-01 §3.3)."""

    __tablename__ = "subject"
    __table_args__ = (UniqueConstraint("subject_name", "level"),)

    subject_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, server_default=func.gen_random_uuid())
    subject_name: Mapped[str] = mapped_column(String(150))
    level: Mapped[EducationLevel] = mapped_column(Enum(EducationLevel, name="education_level"))
    is_special_programme: Mapped[bool] = mapped_column(server_default=false())


class Cca(db.Model):
    """Table: cca (DATA-01 §3.3)."""

    __tablename__ = "cca"
    __table_args__ = (UniqueConstraint("cca_name", "category"),)

    cca_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, server_default=func.gen_random_uuid())
    cca_name: Mapped[str] = mapped_column(String(150))
    category: Mapped[CcaCategory] = mapped_column(Enum(CcaCategory, name="cca_category"))


class SchoolSubject(db.Model):
    """Table: school_subject (DATA-01 §3.3)."""

    __tablename__ = "school_subject"

    school_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("school.school_id", ondelete="CASCADE"), primary_key=True)
    subject_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("subject.subject_id", ondelete="CASCADE"), primary_key=True, index=True  # FR 5.1
    )


class SchoolCca(db.Model):
    """Table: school_cca (DATA-01 §3.3)."""

    __tablename__ = "school_cca"

    school_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("school.school_id", ondelete="CASCADE"), primary_key=True)
    cca_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("cca.cca_id", ondelete="CASCADE"), primary_key=True, index=True)


class Affiliation(db.Model):
    """Table: affiliation (DATA-01 §3.3)."""

    __tablename__ = "affiliation"
    __table_args__ = (
        UniqueConstraint("feeder_school_id", "receiving_school_id"),
        CheckConstraint("feeder_school_id <> receiving_school_id"),
    )

    affiliation_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, server_default=func.gen_random_uuid())
    feeder_school_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("school.school_id", ondelete="CASCADE"))
    receiving_school_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("school.school_id", ondelete="CASCADE"), index=True)
    priority_description: Mapped[str | None] = mapped_column(Text)


class SchoolSyncLog(db.Model):
    """Table: school_sync_log (DATA-01 §3.3)."""

    __tablename__ = "school_sync_log"

    sync_id: Mapped[int] = mapped_column(BigInteger, primary_key=True)  # bigserial
    dataset: Mapped[str] = mapped_column(String(50))
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    status: Mapped[SyncStatus] = mapped_column(Enum(SyncStatus, name="sync_status"))
    records_updated: Mapped[int] = mapped_column(server_default=text("0"))
    error_message: Mapped[str | None] = mapped_column(Text)  # FR 12.5
