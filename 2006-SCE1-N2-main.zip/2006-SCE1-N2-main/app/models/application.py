"""Shortlist, application and comparison tables (DATA-01 §3.3 "Shortlist and application")."""
import uuid
from datetime import date, datetime

from sqlalchemy import (
    Boolean,
    CheckConstraint,
    Date,
    DateTime,
    Enum,
    ForeignKey,
    Index,
    SmallInteger,
    String,
    Text,
    UniqueConstraint,
    func,
    text,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.extensions import db
from app.models.enums import ApplicationStatus


class Shortlist(db.Model):
    """Table: shortlist (DATA-01 §3.3)."""

    __tablename__ = "shortlist"

    shortlist_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, server_default=func.gen_random_uuid())
    student_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("student_profile.student_id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(100), server_default="My shortlist")
    date_created: Mapped[date] = mapped_column(Date, server_default=text("CURRENT_DATE"))
    notes: Mapped[str | None] = mapped_column(Text)


class ShortlistEntry(db.Model):
    """Table: shortlist_entry (DATA-01 §3.3). No duplicate school in a shortlist."""

    __tablename__ = "shortlist_entry"
    __table_args__ = (
        UniqueConstraint("shortlist_id", "school_id"),
        CheckConstraint("rank > 0"),
    )

    entry_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, server_default=func.gen_random_uuid())
    shortlist_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("shortlist.shortlist_id", ondelete="CASCADE"))
    school_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("school.school_id", ondelete="RESTRICT"))
    date_added: Mapped[date] = mapped_column(Date, server_default=text("CURRENT_DATE"))
    rank: Mapped[int | None] = mapped_column(SmallInteger)


class Application(db.Model):
    """Table: application (DATA-01 §3.3; FR 9.3, FR 10.5, FR 11.1, UC13)."""

    __tablename__ = "application"
    __table_args__ = (
        UniqueConstraint("student_id", "school_id"),  # FR 10.5
        CheckConstraint("status = 'Draft' OR date_submitted IS NOT NULL"),
        Index("ix_application_deadline", "deadline", postgresql_where=text("deadline IS NOT NULL")),  # FR 11.1
    )

    application_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, server_default=func.gen_random_uuid())
    student_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("student_profile.student_id", ondelete="CASCADE"))
    school_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("school.school_id", ondelete="RESTRICT"))
    status: Mapped[ApplicationStatus] = mapped_column(
        Enum(ApplicationStatus, name="application_status"), server_default="Draft"
    )
    date_submitted: Mapped[date | None] = mapped_column(Date)
    deadline: Mapped[date | None] = mapped_column(Date)  # UC13; NULL = no reminder
    notes: Mapped[str | None] = mapped_column(Text)  # FR 9.3
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class DeadlineReminder(db.Model):
    """Table: deadline_reminder (DATA-01 §3.3). Never remind twice for the same deadline."""

    __tablename__ = "deadline_reminder"
    __table_args__ = (UniqueConstraint("application_id", "remind_for_deadline"),)

    reminder_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, server_default=func.gen_random_uuid())
    application_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("application.application_id", ondelete="CASCADE"))
    remind_for_deadline: Mapped[date] = mapped_column(Date)
    channel: Mapped[str] = mapped_column(String(20), server_default="email")
    sent_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    # DATA-01 v1.1 (ARC-02 Q1): set by PATCH /api/notifications/<id>/read; a new reminder starts unread.
    is_read: Mapped[bool] = mapped_column(Boolean, server_default=text("false"))


class ComparisonCriterion(db.Model):
    """Table: comparison_criterion (DATA-01 §3.3). Rows are seeded by the first migration (§3.6)."""

    __tablename__ = "comparison_criterion"

    criterion_id: Mapped[int] = mapped_column(SmallInteger, primary_key=True, autoincrement=False)
    criterion_name: Mapped[str] = mapped_column(String(50), unique=True)
