"""Domain exceptions raised by control classes, and their JSON error responses (ARC-02 §4.2, §5)."""
from flask import Flask, jsonify
from werkzeug.exceptions import HTTPException

from app.extensions import db, jwt


class DomainError(Exception):
    """Base class. Each subclass fixes the HTTP status and the `error` code of the response body."""

    status_code = 500
    error_code = "internal_error"

    def __init__(self, message: str, details: dict | None = None):
        super().__init__(message)
        self.message = message
        self.details = details or {}


class ValidationError(DomainError):
    """Bad input, bad comparison count, invalid date (ARC-02 §5)."""

    status_code = 400
    error_code = "validation_failed"


class InvalidCredentialsError(DomainError):
    """Wrong email or password (UC02 alt flow 2)."""

    status_code = 401
    error_code = "invalid_credentials"


class NotFoundError(DomainError):
    """Missing record, or one owned by another user (ARC-02 §3.9.3)."""

    status_code = 404
    error_code = "not_found"


class ConflictError(DomainError):
    """Duplicate email/entry/application, blocked profile removal, invalid status transition (ARC-02 §5)."""

    status_code = 409
    error_code = "conflict"


class AccountLockedError(DomainError):
    """Account locked after 5 failed logins; details carry remaining_seconds (UC02, NFR 3.5.1)."""

    status_code = 423
    error_code = "account_locked"


class ExternalServiceError(DomainError):
    """data.gov.sg or OneMap unavailable (FR 12.5, NFR 3.2.2)."""

    status_code = 503
    error_code = "external_unavailable"


def error_response(status_code: int, error_code: str, message: str, details: dict | None = None):
    """Build the §4.2 body {"error", "message", "details"} with its status code; details only when non-empty."""
    body = {"error": error_code, "message": message}
    if details:
        body["details"] = details
    return jsonify(body), status_code


def register_error_handlers(app: Flask) -> None:
    """Turn every DomainError, every HTTP error and expired or missing JWTs into the §4.2 JSON body.

    Inputs: the Flask app. Call it after boundary.register_blueprints(), so this HTTPException handler
    replaces the one flask-smorest's Api.init_app registers (body {"code", "status"}; ARC-02 §3.12 changelog).
    Output: none; handlers are registered on the app.
    Errors: none.
    """

    @app.errorhandler(DomainError)
    def handle_domain_error(error: DomainError):
        # A failed write must not leave the session half-applied for the next request.
        db.session.rollback()
        return error_response(error.status_code, error.error_code, error.message, error.details)

    @app.errorhandler(HTTPException)
    def handle_http_exception(error: HTTPException):
        # flask-smorest/webargs reject a request body or query that fails its schema with 422 and
        # the field errors in error.data["messages"]; ARC-02 §5 calls this 400 validation_failed.
        if error.code == 422:
            messages = getattr(error, "data", {}).get("messages", {})
            return error_response(400, ValidationError.error_code, "The request has invalid fields.", messages)
        # Unknown URL (404), wrong method (405) and so on: keep the status, name it in snake_case.
        error_code = (error.name or "http_error").lower().replace(" ", "_").replace("'", "")
        return error_response(error.code or 500, error_code, error.description or error.name)

    @app.errorhandler(Exception)
    def handle_unexpected_error(error: Exception):
        # Anything a controller did not turn into a DomainError: log it, never show the traceback.
        db.session.rollback()
        app.logger.exception("Unhandled error: %s", error)
        return error_response(500, DomainError.error_code, "Something went wrong on the server.")

    # Sessions (ARC-02 §3.9.2): Flask-JWT-Extended calls these instead of its own {"msg": ...} bodies.
    @jwt.expired_token_loader
    def handle_expired_token(_jwt_header, _jwt_payload):
        return error_response(401, "session_expired", "Your session has expired. Please log in again.")

    @jwt.unauthorized_loader
    def handle_missing_token(reason: str):
        # No cookie, or the X-CSRF-TOKEN header is missing or wrong.
        return error_response(401, "unauthorised", "Please log in to continue.", {"reason": reason})

    @jwt.invalid_token_loader
    def handle_invalid_token(reason: str):
        # Tampered or malformed cookie.
        return error_response(401, "unauthorised", "Please log in to continue.", {"reason": reason})
