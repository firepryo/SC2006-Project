#!/bin/sh
# Container start-up: bring the schema up to date, then run the given command (Gunicorn by default).
# Keep LF line endings (.gitattributes); the Dockerfile also strips CRs.
set -e

cd /srv
echo "Applying database migrations..."
flask --app "app.app:create_app()" db upgrade

exec "$@"
