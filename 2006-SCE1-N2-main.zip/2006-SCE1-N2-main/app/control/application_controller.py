"""Class diagram: ApplicationController «control» (UC09; M6 Applications, ARC-02 §3.4)."""
import uuid

from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError

from app.control.access_control import require_application_owner, require_profile_owner
from app.errors import ConflictError, NotFoundError
from app.extensions import db
from app.models import Application, School, StudentProfile


def attach_school(application: Application) -> Application:
    """Set `application.school`, which ApplicationSchema dumps (SchoolSummary). Shared by the M6 controllers."""
    application.school = db.session.get(School, application.school_id)
    return application


def touch(application: Application) -> None:
    """Record that the application changed now (application.updated_at).

    Uses the database's now(), the same clock as the column default on insert; Python's clock can differ
    from the database server's, which would make an edit look older than the create.
    """
    application.updated_at = func.now()


class ApplicationController:
    """Creates and edits application records. Status and deadline changes go through UC10 and UC13 controllers."""

    def list_applications(self, user_id: uuid.UUID, student_id: uuid.UUID | None = None) -> list[Application]:
        """All applications of the user's profiles, or of one owned profile. Errors: NotFoundError for a foreign profile.

        Output: most recently changed first, each with `.school` attached (DM-60).
        """
        query = (
            select(Application, School)
            .join(School, School.school_id == Application.school_id)
            .join(StudentProfile, StudentProfile.student_id == Application.student_id)
            .where(StudentProfile.user_id == user_id)
            .order_by(Application.updated_at.desc(), School.name)
        )
        if student_id is not None:
            require_profile_owner(user_id, student_id)
            query = query.where(Application.student_id == student_id)

        applications = []
        for application, school in db.session.execute(query):
            application.school = school
            applications.append(application)
        return applications

    def create_application(
        self, user_id: uuid.UUID, student_id: uuid.UUID, school_id: uuid.UUID, notes: str | None = None
    ) -> Application:
        """Class diagram: createApplication(studentID, schoolID). Save a record with status Draft (UC09 steps 1–5).

        Errors: NotFoundError for an unknown school or foreign profile; ConflictError if one already exists
            for that student and school (FR 10.5, UC09 alt flow 2).
        """
        require_profile_owner(user_id, student_id)
        school = db.session.get(School, school_id)
        if school is None or not school.is_active:
            # A retired school (is_active = false) cannot get new applications, the same rule as the shortlist.
            raise NotFoundError("School not found.", {"school_id": str(school_id)})

        existing = db.session.scalar(
            select(Application.application_id).where(
                Application.student_id == student_id, Application.school_id == school_id
            )
        )
        if existing is not None:
            raise ConflictError(
                "This student already has an application for this school.", {"application_id": str(existing)}
            )

        # status, date_submitted and updated_at come from the column defaults: Draft, NULL, now().
        application = Application(student_id=student_id, school_id=school_id, notes=notes)
        db.session.add(application)
        try:
            db.session.commit()
        except IntegrityError as exc:  # a double-submitted create lost the race (unique student_id, school_id)
            db.session.rollback()
            raise ConflictError("This student already has an application for this school.") from exc
        db.session.refresh(application)
        application.school = school
        return application

    def get_application(self, user_id: uuid.UUID, application_id: uuid.UUID) -> Application:
        """Class diagram: getApplication(applicationID). Errors: NotFoundError (ARC-02 §3.9.3)."""
        return attach_school(require_application_owner(user_id, application_id))

    def update_application(self, user_id: uuid.UUID, application_id: uuid.UUID, notes: str | None) -> Application:
        """Class diagram: updateApplication(application). Edit the notes only (FR 9.3, UC09 alt flow 1).

        Errors: NotFoundError.
        """
        application = require_application_owner(user_id, application_id)
        application.notes = notes
        touch(application)
        db.session.commit()
        return attach_school(application)
