"""«control» classes: all business rules (ARC-02 §3.2 rule 3, §3.4). One file per class-diagram controller."""
from app.control.application_controller import ApplicationController
from app.control.application_deadline_controller import ApplicationDeadlineController
from app.control.application_status_controller import ApplicationStatusController
from app.control.login_controller import LoginController
from app.control.notification_preference_controller import NotificationPreferenceController
from app.control.registration_controller import RegistrationController
from app.control.reminder_controller import ReminderController
from app.control.school_comparison_controller import SchoolComparisonController
from app.control.school_data_sync_controller import SchoolDataSyncController
from app.control.school_details_controller import SchoolDetailsController
from app.control.school_search_controller import SchoolSearchController
from app.control.shortlist_controller import ShortlistController
from app.control.student_profile_controller import StudentProfileController

__all__ = [
    "ApplicationController",
    "ApplicationDeadlineController",
    "ApplicationStatusController",
    "LoginController",
    "NotificationPreferenceController",
    "RegistrationController",
    "ReminderController",
    "SchoolComparisonController",
    "SchoolDataSyncController",
    "SchoolDetailsController",
    "SchoolSearchController",
    "ShortlistController",
    "StudentProfileController",
]
