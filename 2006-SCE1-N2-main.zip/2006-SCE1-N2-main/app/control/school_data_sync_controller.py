"""Class diagram: SchoolDataSyncController «control» (UC12, FR 12, NFR 3.2.2; M8 School data, ARC-02 §3.7.5).

Implements the DATA-01 §3.8 mapping and sync rules for the school dataset, plus the CCA dataset (ADR-006).
data.gov.sg is the main source. MOE SchoolFinder then only supplements what it lacks: extra subjects, and
contact details where data.gov.sg has none (user decision 2026-11-07).
"""
import re
import time
import uuid
from datetime import datetime, timezone

from flask import current_app
from geoalchemy2.elements import WKTElement
from sqlalchemy import delete, func, select, update
from sqlalchemy.exc import SQLAlchemyError

from app.errors import ExternalServiceError, ValidationError
from app.extensions import db
from app.gateway import ExternalSchoolDataGateway, OneMapGateway
from app.gateway.external_school_data_gateway import SCHOOL_CCA_DATASET, SCHOOL_GENERAL_INFO_DATASET
from app.gateway.moe_school_finder_gateway import LEVEL_PAGES, MoeSchoolFinderGateway
from app.models import Cca, School, SchoolCca, SchoolSubject, SchoolSyncLog, Subject
from app.models.enums import CcaCategory, EducationLevel, SchoolType, SyncStatus

_P, _S, _J = EducationLevel.Primary, EducationLevel.Secondary, EducationLevel.JuniorCollege

# DATA-01 §3.8 "Main level → type and levels" (ADR-002)
MAIN_LEVEL_MAP: dict[str, tuple[SchoolType, tuple[EducationLevel, ...]]] = {
    "PRIMARY": (SchoolType.Primary, (_P,)),
    "SECONDARY (S1-S4)": (SchoolType.Secondary, (_S,)),
    "SECONDARY (S1-S5)": (SchoolType.Secondary, (_S,)),
    "JUNIOR COLLEGE": (SchoolType.JuniorCollege, (_J,)),
    "CENTRALISED INSTITUTE": (SchoolType.JuniorCollege, (_J,)),
    "MIXED LEVEL (P1-S4)": (SchoolType.MixedLevels, (_P, _S)),
    "MIXED LEVEL (S1-JC2)": (SchoolType.MixedLevels, (_S, _J)),
    "MIXED LEVEL (S1-S5, JC1-JC2)": (SchoolType.MixedLevels, (_S, _J)),
}

# Dataset field → school column, copied after value cleaning (DATA-01 §3.8)
SCHOOL_COLUMNS = {
    "address": "address",
    "zone_code": "zone",
    "dgp_code": "planning_area",
    "type_code": "funding_type",
    "nature_code": "gender_type",
    "session_code": "session_type",
    "url_address": "website",
    "telephone_no": "telephone",
    "email_address": "email",
    "mrt_desc": "mrt_desc",
    "bus_desc": "bus_desc",
}

# Programme flags stored as special-programme subjects (ADR-004)
PROGRAMME_FLAGS = {
    "sap_ind": "Special Assistance Plan (SAP)",
    "autonomous_ind": "Autonomous School",
    "gifted_ind": "Gifted Education Programme",
    "ip_ind": "Integrated Programme",
}
MOTHER_TONGUE_FIELDS = ("mothertongue1_code", "mothertongue2_code", "mothertongue3_code")
LANGUAGE_SUBJECTS = ("Chinese Language", "Malay Language", "Tamil Language")
# The 21 seeded subjects the sync owns links to: 7 names × 3 levels (DATA-01 §3.6, §3.8 rule 3)
DATASET_SUBJECT_NAMES = (*PROGRAMME_FLAGS.values(), *LANGUAGE_SUBJECTS)

# CCA dataset cca_generic_name → cca_category (ADR-006)
CCA_CATEGORY_MAP = {
    "PHYSICAL SPORTS": CcaCategory.Sports,
    "VISUAL AND PERFORMING ARTS": CcaCategory.PerformingArts,
    "UNIFORMED GROUPS": CcaCategory.UniformedGroup,
    "CLUBS AND SOCIETIES": CcaCategory.ClubSociety,
    "OTHERS": CcaCategory.Others,
}

MOE_SCHOOL_FINDER_DATASET = "moe-schoolfinder"  # school_sync_log.dataset for the supplement pass
# Contact columns the supplement may fill when data.gov.sg left them empty, with their column lengths.
SUPPLEMENT_CONTACT_COLUMNS = {"telephone": 20, "email": 254, "website": None}
LEVEL_SUFFIX = re.compile(r"\s*\((Primary|Secondary|Junior College)\)\s*$", re.IGNORECASE)

GEOCODE_DELAY_SECONDS = 0.25  # stay well under OneMap's 250 requests per minute
MAX_ERROR_MESSAGE_LENGTH = 4000


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _clean(value) -> str | None:
    """DATA-01 §3.8 value cleaning: trim whitespace; "na" or an empty string becomes NULL."""
    if value is None:
        return None
    text = str(value).strip()
    return None if text == "" or text.lower() == "na" else text


def _name_key(name: str) -> str:
    """School name for matching across sources: upper case, "&" as AND, punctuation and extra spaces dropped."""
    text = name.upper().replace("&", " AND ").replace("'", "").replace("\u2019", "")
    return " ".join(re.sub(r"[^A-Z0-9]+", " ", text).split())


def _summarise(problems: list[str]) -> str:
    """Join skipped-record reasons into one error_message, cut to a safe length."""
    text = f"{len(problems)} record(s) skipped: " + "; ".join(problems)
    return text[:MAX_ERROR_MESSAGE_LENGTH]


class SchoolDataSyncController:
    """Keeps the local school catalogue in step with data.gov.sg; a failed batch never changes stored data."""

    def __init__(
        self,
        school_data_gateway: ExternalSchoolDataGateway | None = None,
        onemap_gateway: OneMapGateway | None = None,
        school_finder_gateway: MoeSchoolFinderGateway | None = None,
    ):
        self.school_data_gateway = school_data_gateway or ExternalSchoolDataGateway()
        self.onemap_gateway = onemap_gateway or OneMapGateway()
        self.school_finder_gateway = school_finder_gateway or MoeSchoolFinderGateway()

    # ------------------------------------------------------------------ schools (DATA-01 §3.8)

    def synchronise_school_data(self) -> SchoolSyncLog:
        """Class diagram: synchroniseSchoolData(). One sync run (UC12 main flow).

        Output: the finished school_sync_log row (Success, Partial or Failed, records_updated).
        Errors: none raised; failures are rolled back and recorded (UC12 alt flows 1–2).
        Afterwards the CCA dataset is synced as its own run with its own log row (ADR-006), and then the
        MOE SchoolFinder supplement runs, also with its own log row.
        """
        log = SchoolSyncLog(dataset=SCHOOL_GENERAL_INFO_DATASET, started_at=_now(), status=SyncStatus.Failed)
        try:
            records = self.school_data_gateway.fetch_all(SCHOOL_GENERAL_INFO_DATASET)
            self._validate_school_data(records)
            subject_ids = self._load_dataset_subjects()

            updated, problems, to_geocode = self._upsert_schools(records, subject_ids)
            # Rule 2: only after a complete fetch. Skipped records still count as present.
            self._retire_missing_schools({_clean(r.get("school_name")) for r in records} - {None})
            not_geocoded = self._geocode_schools(to_geocode)

            log.status = SyncStatus.Partial if problems else SyncStatus.Success
            log.records_updated = updated
            notes = [_summarise(problems)] if problems else []
            if not_geocoded:
                notes.append(f"{len(not_geocoded)} school(s) not geocoded: {', '.join(not_geocoded)}")
            log.error_message = (" | ".join(notes))[:MAX_ERROR_MESSAGE_LENGTH] or None
            log.finished_at = _now()
            db.session.add(log)
            db.session.commit()
        except Exception as exc:  # UC12 alt flow 1: roll back everything, record the failure
            db.session.rollback()
            current_app.logger.exception("School data sync failed")
            self._record_sync_failure(log, exc)
            return log

        self.synchronise_cca_data()
        self.supplement_from_school_finder()
        return log

    def _validate_school_data(self, records: list[dict]) -> None:
        """Class diagram: validateSchoolData(data). Check required fields and identifiers (UC12 step 3, FR 12.3).

        Errors: ValidationError for an empty or invalid batch; an empty response never deletes rows (UC12 alt flow 2).
        """
        if not records:
            raise ValidationError("data.gov.sg returned no school records; nothing was changed.")
        required = {"school_name", "mainlevel_code", "address", "postal_code"}
        missing = required - set(records[0].keys())
        if missing:
            raise ValidationError(
                "The school dataset no longer has the expected fields; nothing was changed.",
                {"missing_fields": sorted(missing)},
            )
        names = [_clean(r.get("school_name")) for r in records]
        if any(name is None for name in names):
            raise ValidationError("A school record has no school_name, the upsert key (ADR-001).")
        if len(set(names)) != len(names):
            raise ValidationError("Duplicate school names in the dataset; the upsert key must be unique (ADR-001).")

    def _record_sync_failure(self, log: SchoolSyncLog, error: Exception) -> None:
        """Class diagram: recordSyncFailure(). Set status Failed, finished_at and error_message (FR 12.5)."""
        log.status = SyncStatus.Failed
        log.records_updated = 0
        log.finished_at = _now()
        message = getattr(error, "message", None) or str(error) or type(error).__name__
        log.error_message = f"{type(error).__name__}: {message}"[:MAX_ERROR_MESSAGE_LENGTH]
        db.session.add(log)
        db.session.commit()

    def get_last_successful_sync(self) -> datetime | None:
        """finished_at of the newest Success row; drives the "data last updated" notice (dialog map §4)."""
        query = select(func.max(SchoolSyncLog.finished_at)).where(
            SchoolSyncLog.dataset == SCHOOL_GENERAL_INFO_DATASET,
            SchoolSyncLog.status == SyncStatus.Success,
        )
        return db.session.scalar(query)

    def _load_dataset_subjects(self) -> dict[tuple[str, EducationLevel], uuid.UUID]:
        """The 21 seeded subjects, keyed by (name, level). They are created by the first migration (DATA-01 §3.6)."""
        rows = db.session.execute(
            select(Subject.subject_name, Subject.level, Subject.subject_id).where(
                Subject.subject_name.in_(DATASET_SUBJECT_NAMES)
            )
        )
        subject_ids = {(name, level): subject_id for name, level, subject_id in rows}
        expected = len(DATASET_SUBJECT_NAMES) * len(EducationLevel)
        if len(subject_ids) != expected:
            raise ValidationError(
                f"Found {len(subject_ids)} of the {expected} seeded dataset subjects; run the migrations first "
                "(DATA-01 §3.6)."
            )
        return subject_ids

    def _upsert_schools(
        self, records: list[dict], subject_ids: dict[tuple[str, EducationLevel], uuid.UUID]
    ) -> tuple[int, list[str], list[School]]:
        """Rules 1, 3 and 5. Each record runs in its own savepoint, so one bad record is skipped, not fatal.

        Output: (schools written, skipped-record reasons, schools that need geocoding).
        """
        existing = {school.name: school for school in db.session.scalars(select(School))}
        all_dataset_subject_ids = list(subject_ids.values())
        synced_at = _now()
        updated, problems, to_geocode = 0, [], []

        for record in records:
            name = _clean(record.get("school_name"))
            try:
                with db.session.begin_nested():
                    main_level = _clean(record.get("mainlevel_code"))
                    if main_level not in MAIN_LEVEL_MAP:
                        raise ValueError(f"unknown mainlevel_code {main_level!r}")  # ADR-002: log, don't guess
                    school_type, levels = MAIN_LEVEL_MAP[main_level]

                    school = existing.get(name)
                    if school is None:
                        school = School(name=name)
                        db.session.add(school)
                    old_postal_code = school.postal_code

                    school.type = school_type
                    school.main_level = main_level
                    for field, column in SCHOOL_COLUMNS.items():
                        setattr(school, column, _clean(record.get(field)))
                    postal_code = _clean(record.get("postal_code"))
                    school.postal_code = postal_code.zfill(6) if postal_code else None  # ADR-003
                    school.is_active = True
                    school.last_synced_at = synced_at
                    db.session.flush()

                    # Rule 3: replace links to the 21 dataset subjects only.
                    db.session.execute(
                        delete(SchoolSubject).where(
                            SchoolSubject.school_id == school.school_id,
                            SchoolSubject.subject_id.in_(all_dataset_subject_ids),
                        )
                    )
                    for subject_name in self._subjects_offered(record):
                        for level in levels:
                            db.session.add(
                                SchoolSubject(school_id=school.school_id, subject_id=subject_ids[(subject_name, level)])
                            )
                    db.session.flush()
            except (ValueError, SQLAlchemyError) as exc:  # rule 5: skip and log
                # The savepoint rollback undoes this record only; a new School is discarded with it.
                problems.append(f"{name}: {exc.__class__.__name__}: {str(exc).splitlines()[0][:200]}")
                continue

            existing[name] = school
            updated += 1
            # ADR-003: geocode only when there is no location yet or the postal code changed.
            if school.postal_code and (school.location is None or school.postal_code != old_postal_code):
                to_geocode.append(school)
        return updated, problems, to_geocode

    @staticmethod
    def _subjects_offered(record: dict) -> set[str]:
        """Dataset subject names this record links to: programme flags = "Yes", plus mother tongues offered."""
        offered = {name for field, name in PROGRAMME_FLAGS.items() if _clean(record.get(field)) == "Yes"}
        for field in MOTHER_TONGUE_FIELDS:
            value = _clean(record.get(field))
            if value:
                language = f"{value.title()} Language"
                if language in LANGUAGE_SUBJECTS:
                    offered.add(language)
        return offered

    def _retire_missing_schools(self, dataset_names: set[str]) -> None:
        """Rule 2: schools no longer in the dataset become inactive. Never deleted (shortlists, applications)."""
        db.session.execute(
            update(School)
            .where(School.is_active.is_(True), School.name.not_in(dataset_names))
            .values(is_active=False)
        )

    def _geocode_schools(self, schools: list[School]) -> list[str]:
        """Rule 4 / ADR-003. A failed lookup leaves location NULL and does not fail the sync.

        Output: names of the schools that could not be geocoded.
        """
        failed = []
        for index, school in enumerate(schools):
            if index:
                time.sleep(GEOCODE_DELAY_SECONDS)
            try:
                coordinates = self.onemap_gateway.geocode_postal_code(school.postal_code)
            except ExternalServiceError:
                coordinates = None
            if coordinates is None:
                failed.append(school.name)
                continue
            latitude, longitude = coordinates
            school.location = WKTElement(f"POINT({longitude} {latitude})", srid=4326)  # WKT is (lon lat)
        return failed

    # ------------------------------------------------------------------ CCAs (ADR-006)

    def synchronise_cca_data(self) -> SchoolSyncLog:
        """Sync CCAs and school–CCA links from the CCA dataset; logged as its own run.

        Each school's CCA links are replaced by the dataset's list; schools not in the CCA dataset keep theirs.
        CCA names are stored as given in `cca_grouping_desc` (MOE's standard name), category from
        `cca_generic_name`. Records for schools not in the catalogue are skipped (status Partial).
        Errors: none raised; failures are rolled back and recorded.
        """
        log = SchoolSyncLog(dataset=SCHOOL_CCA_DATASET, started_at=_now(), status=SyncStatus.Failed)
        try:
            records = self.school_data_gateway.fetch_all(SCHOOL_CCA_DATASET)
            if not records:
                raise ValidationError("data.gov.sg returned no CCA records; nothing was changed.")
            missing = {"School_name", "cca_generic_name", "cca_grouping_desc"} - set(records[0].keys())
            if missing:
                raise ValidationError("The CCA dataset no longer has the expected fields.", {"missing": sorted(missing)})

            school_ids = {name.upper(): sid for name, sid in db.session.execute(select(School.name, School.school_id))}
            ccas = {(c.cca_name, c.category): c for c in db.session.scalars(select(Cca))}
            wanted: dict[uuid.UUID, set[tuple[str, CcaCategory]]] = {}
            unknown_schools: set[str] = set()
            bad_records = 0

            for record in records:
                school_name = _clean(record.get("School_name"))
                category = CCA_CATEGORY_MAP.get((_clean(record.get("cca_generic_name")) or "").upper())
                cca_name = _clean(record.get("cca_grouping_desc"))
                if not school_name or category is None or not cca_name:
                    bad_records += 1
                    continue
                school_id = school_ids.get(school_name.upper())
                if school_id is None:
                    unknown_schools.add(school_name)
                    continue
                key = (cca_name[:150], category)
                if key not in ccas:
                    ccas[key] = Cca(cca_name=key[0], category=category)
                    db.session.add(ccas[key])
                wanted.setdefault(school_id, set()).add(key)
            db.session.flush()

            links = 0
            for school_id, keys in wanted.items():
                db.session.execute(delete(SchoolCca).where(SchoolCca.school_id == school_id))
                for key in keys:
                    db.session.add(SchoolCca(school_id=school_id, cca_id=ccas[key].cca_id))
                    links += 1

            notes = []
            if bad_records:
                notes.append(f"{bad_records} record(s) skipped: missing school, category or CCA name")
            if unknown_schools:
                notes.append(
                    f"{len(unknown_schools)} school name(s) not in the school catalogue: "
                    + ", ".join(sorted(unknown_schools))
                )
            log.status = SyncStatus.Partial if notes else SyncStatus.Success
            log.records_updated = links
            log.error_message = (" | ".join(notes))[:MAX_ERROR_MESSAGE_LENGTH] or None
            log.finished_at = _now()
            db.session.add(log)
            db.session.commit()
        except Exception as exc:
            db.session.rollback()
            current_app.logger.exception("CCA data sync failed")
            self._record_sync_failure(log, exc)
        return log

    # ------------------------------------------------------------------ MOE SchoolFinder supplement

    def supplement_from_school_finder(self) -> SchoolSyncLog:
        """Add what data.gov.sg lacks from MOE SchoolFinder; logged as its own run.

        - Schools are matched to the data.gov.sg catalogue by name; SchoolFinder never creates a school.
        - Subjects: adds (name, level) rows and school links that are missing. Links from data.gov.sg and the
          21 seeded dataset subjects are never removed or re-pointed; names the data.gov.sg sync owns are skipped.
        - Contacts: fills telephone, email or website only where the data.gov.sg value is empty.
        Output: the finished log row; Partial when a level page failed or some names did not match.
        Errors: none raised; on failure nothing is changed and the log row says why.
        """
        log = SchoolSyncLog(dataset=MOE_SCHOOL_FINDER_DATASET, started_at=_now(), status=SyncStatus.Failed)
        try:
            fetched, page_failures = {}, []
            for level in LEVEL_PAGES:
                try:
                    fetched[level] = self.school_finder_gateway.fetch_schools(level)
                except ExternalServiceError as exc:
                    page_failures.append(f"{level.value}: {exc.message}")
            if not fetched:
                raise ExternalServiceError("No SchoolFinder page could be read: " + "; ".join(page_failures))

            schools = {_name_key(s.name): s for s in db.session.scalars(select(School).where(School.is_active.is_(True)))}
            # Keyed case-insensitively: schools type the same subject as "BIOLOGY" and "Biology".
            subjects = {(s.subject_name.casefold(), s.level): s for s in db.session.scalars(select(Subject))}
            owned = {name.casefold() for name in DATASET_SUBJECT_NAMES}
            links = {tuple(row) for row in db.session.execute(select(SchoolSubject.school_id, SchoolSubject.subject_id))}
            unmatched: set[str] = set()
            added_links = filled_contacts = 0

            for level, moe_schools in fetched.items():
                for moe in moe_schools:
                    # Mixed-level schools are listed per level, e.g. "Catholic High School (Secondary)".
                    school = schools.get(_name_key(moe.name)) or schools.get(
                        _name_key(LEVEL_SUFFIX.sub("", moe.name))
                    )
                    # Same name but not a level this school teaches: not the same school, leave it alone.
                    if school is None or level not in MAIN_LEVEL_MAP.get(school.main_level, (None, ()))[1]:
                        unmatched.add(moe.name)
                        continue
                    for column, max_length in SUPPLEMENT_CONTACT_COLUMNS.items():
                        value = getattr(moe, column)
                        if value and not getattr(school, column):
                            setattr(school, column, value[:max_length] if max_length else value)
                            filled_contacts += 1
                    for name in sorted(moe.subjects):
                        key = (name.casefold(), level)
                        if key[0] in owned:
                            continue  # owned by the data.gov.sg sync (rule 3)
                        subject = subjects.get(key)
                        if subject is None:
                            display = name.title() if name.isupper() and len(name) > 4 else name  # "BIOLOGY" -> "Biology"
                            subject = Subject(subject_name=display, level=level, is_special_programme=False)
                            db.session.add(subject)
                            db.session.flush()
                            subjects[key] = subject
                        if (school.school_id, subject.subject_id) not in links:
                            db.session.add(SchoolSubject(school_id=school.school_id, subject_id=subject.subject_id))
                            links.add((school.school_id, subject.subject_id))
                            added_links += 1

            notes = list(page_failures)
            if unmatched:
                notes.append(
                    f"{len(unmatched)} SchoolFinder school(s) not in the data.gov.sg catalogue: "
                    + ", ".join(sorted(unmatched))
                )
            log.status = SyncStatus.Partial if notes else SyncStatus.Success
            log.records_updated = added_links + filled_contacts
            log.error_message = (" | ".join(notes))[:MAX_ERROR_MESSAGE_LENGTH] or None
            log.finished_at = _now()
            db.session.add(log)
            db.session.commit()
            current_app.logger.info(
                "SchoolFinder supplement: %d subject links added, %d contacts filled, %d unmatched",
                added_links, filled_contacts, len(unmatched),
            )
        except Exception as exc:
            db.session.rollback()
            current_app.logger.exception("SchoolFinder supplement failed")
            self._record_sync_failure(log, exc)
        return log
