"""Class diagram: SchoolComparisonController «control» (UC07, UC07a–d; M4 Comparison, ARC-02 §3.7.3).

Facade over the four criterion strategies in comparison_criteria.py (ARC-02 §3.10). The class diagram's
calculateDistance, matchSubjects, matchCCAs and evaluateAffiliations are those strategies' evaluate().
"""
import uuid
from dataclasses import dataclass, field

from sqlalchemy import func, select

from app.control.access_control import require_profile_owner
from app.control.comparison_criteria import (
    AffiliationCriterion,
    CcaMatchCriterion,
    ComparisonContext,
    ComparisonCriterionStrategy,
    CriterionResult,
    DistanceCriterion,
    SubjectMatchCriterion,
)
from app.control.school_details_controller import SchoolDetailsController
from app.errors import NotFoundError, ValidationError
from app.extensions import db
from app.models import Affiliation, School, StudentPreferredCca, StudentPreferredSubject, UserAccount


@dataclass
class ComparisonResult:
    """Side-by-side table: one column per school, one row per criterion (UC07 step 4)."""

    schools: list[School]
    rows: dict[int, list[CriterionResult]] = field(default_factory=dict)  # criterion_id -> one result per school
    personalised: bool = False  # False when no student profile was given (UC07 alt flow 3)


class SchoolComparisonController:
    """Compares 2 to 5 distinct schools (FR 7, NFR 3.3.3)."""

    MIN_SCHOOLS = 2
    MAX_SCHOOLS = 5

    def __init__(self, criteria: list[ComparisonCriterionStrategy] | None = None):
        self.criteria = criteria or [
            DistanceCriterion(),
            SubjectMatchCriterion(),
            CcaMatchCriterion(),
            AffiliationCriterion(),
        ]

    def compare_schools(
        self, user_id: uuid.UUID, school_ids: list[uuid.UUID], student_id: uuid.UUID | None = None
    ) -> ComparisonResult:
        """Class diagram: compareSchools(schoolIDs). Build the comparison (UC07 main flow).

        Inputs: logged-in user id; 2–5 school ids; optional owned student profile for personalised matches.
        Output: ComparisonResult; a criterion with missing data is a "Not available" cell (UC07 alt flow 2).
        Errors: ValidationError for a bad count or duplicates; NotFoundError for an unknown school or
            a profile not owned by the user (UC07 alt flow 1).
        """
        self._validate_selection(school_ids)

        found = {
            school.school_id: school
            for school in db.session.scalars(
                select(School).where(School.school_id.in_(school_ids), School.is_active.is_(True))
            )
        }
        missing = [str(school_id) for school_id in school_ids if school_id not in found]
        if missing:
            raise NotFoundError("School not found.", {"school_ids": missing})
        schools = [found[school_id] for school_id in school_ids]  # keep the user's column order

        context = ComparisonContext(home_coordinates=self._home_coordinates(user_id))
        if student_id is not None:
            require_profile_owner(user_id, student_id)
            context.preferred_subject_ids = set(
                db.session.scalars(
                    select(StudentPreferredSubject.subject_id).where(StudentPreferredSubject.student_id == student_id)
                )
            )
            context.preferred_cca_ids = set(
                db.session.scalars(
                    select(StudentPreferredCca.cca_id).where(StudentPreferredCca.student_id == student_id)
                )
            )
        self._load_school_data(context, school_ids)

        rows = {
            criterion.criterion_id: [criterion.evaluate(school, context) for school in schools]
            for criterion in self.criteria
        }
        return ComparisonResult(schools=schools, rows=rows, personalised=student_id is not None)

    def _validate_selection(self, school_ids: list[uuid.UUID]) -> None:
        """Errors: ValidationError unless MIN_SCHOOLS <= distinct count <= MAX_SCHOOLS (UC07 step 2)."""
        if len(set(school_ids)) != len(school_ids):
            raise ValidationError("Each school can be selected only once.", {"school_ids": "duplicates"})
        if not self.MIN_SCHOOLS <= len(school_ids) <= self.MAX_SCHOOLS:
            raise ValidationError(
                f"Select between {self.MIN_SCHOOLS} and {self.MAX_SCHOOLS} schools to compare.",
                {"school_ids": f"{len(school_ids)} selected"},
            )

    @staticmethod
    def _home_coordinates(user_id: uuid.UUID) -> tuple[float, float] | None:
        """The user's geocoded home location as (latitude, longitude), or None if not set (UC07a)."""
        row = db.session.execute(
            select(func.ST_Y(func.geometry(UserAccount.home_location)), func.ST_X(func.geometry(UserAccount.home_location)))
            .where(UserAccount.user_id == user_id, UserAccount.home_location.is_not(None))
        ).first()
        return (row[0], row[1]) if row else None

    @staticmethod
    def _load_school_data(context: ComparisonContext, school_ids: list[uuid.UUID]) -> None:
        """Coordinates, subjects, CCAs and affiliations for every compared school, one query each (NFR 3.3.3)."""
        for school_id, latitude, longitude in db.session.execute(
            select(
                School.school_id,
                func.ST_Y(func.geometry(School.location)),
                func.ST_X(func.geometry(School.location)),
            ).where(School.school_id.in_(school_ids), School.location.is_not(None))
        ):
            context.school_coordinates[school_id] = (latitude, longitude)

        context.school_subjects = SchoolDetailsController.load_subjects(school_ids)
        context.school_ccas = SchoolDetailsController.load_ccas(school_ids)
        context.affiliation_data_available = db.session.scalar(select(Affiliation.affiliation_id).limit(1)) is not None
        if context.affiliation_data_available:
            context.school_affiliations = SchoolDetailsController.load_affiliations(school_ids)
            other_ids = {
                other
                for affiliations in context.school_affiliations.values()
                for a in affiliations
                for other in (a.feeder_school_id, a.receiving_school_id)
            }
            context.school_names = dict(
                db.session.execute(select(School.school_id, School.name).where(School.school_id.in_(other_ids)))
            )
