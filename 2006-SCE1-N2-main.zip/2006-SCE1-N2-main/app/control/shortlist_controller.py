"""Class diagram: ShortlistController «control» (UC08; M5 Shortlist, ARC-02 §3.4)."""
import uuid

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError

from app.control.access_control import require_profile_owner
from app.errors import ConflictError, NotFoundError
from app.extensions import db
from app.models import School, Shortlist, ShortlistEntry


class ShortlistController:
    """View, add and remove schools in one student's shortlist (FR 8).

    Each student profile has one shortlist, created on first use. The returned objects carry the extra
    attributes the response schemas need: `shortlist.entries` and `entry.school`.
    """

    def get_shortlist(self, user_id: uuid.UUID, student_id: uuid.UUID) -> Shortlist:
        """Class diagram: getShortlist(studentID). The profile's shortlist with entries ordered by rank, then date_added.

        Errors: NotFoundError if the profile is not owned by the user (UC08 precondition).
        """
        require_profile_owner(user_id, student_id)
        shortlist = self._get_or_create_shortlist(student_id)
        rows = db.session.execute(
            select(ShortlistEntry, School)
            .join(School, School.school_id == ShortlistEntry.school_id)
            .where(ShortlistEntry.shortlist_id == shortlist.shortlist_id)
            .order_by(ShortlistEntry.rank.asc().nulls_last(), ShortlistEntry.date_added, School.name)
        )
        entries = []
        for entry, school in rows:
            entry.school = school
            entries.append(entry)
        shortlist.entries = entries
        return shortlist

    def add_school_to_shortlist(self, user_id: uuid.UUID, student_id: uuid.UUID, school_id: uuid.UUID) -> ShortlistEntry:
        """Class diagram: addSchoolToShortlist(schoolID, studentID). Add one school (UC08 steps 2–5).

        Errors: NotFoundError for an unknown school or profile; ConflictError if already shortlisted (UC08 alt flow 2).
        """
        require_profile_owner(user_id, student_id)
        school = db.session.get(School, school_id)
        if school is None or not school.is_active:
            raise NotFoundError("School not found.", {"school_id": str(school_id)})

        shortlist = self._get_or_create_shortlist(student_id)
        already = db.session.scalar(
            select(ShortlistEntry.entry_id).where(
                ShortlistEntry.shortlist_id == shortlist.shortlist_id, ShortlistEntry.school_id == school_id
            )
        )
        if already is not None:
            raise ConflictError("This school is already in the shortlist.", {"entry_id": str(already)})

        entry = ShortlistEntry(shortlist_id=shortlist.shortlist_id, school_id=school_id)
        db.session.add(entry)
        try:
            db.session.commit()
        except IntegrityError as exc:  # a parallel request added it first (unique shortlist_id, school_id)
            db.session.rollback()
            raise ConflictError("This school is already in the shortlist.") from exc
        entry.school = school
        return entry

    def remove_school_from_shortlist(self, user_id: uuid.UUID, student_id: uuid.UUID, entry_id: uuid.UUID) -> None:
        """Class diagram: removeSchoolFromShortlist(entryID). Remove one entry; applications are kept (UC08 alt flow 1).

        Errors: NotFoundError if the entry is not in that profile's shortlist.
        """
        require_profile_owner(user_id, student_id)
        entry = db.session.scalar(
            select(ShortlistEntry)
            .join(Shortlist, Shortlist.shortlist_id == ShortlistEntry.shortlist_id)
            .where(ShortlistEntry.entry_id == entry_id, Shortlist.student_id == student_id)
        )
        if entry is None:
            raise NotFoundError("Shortlist entry not found.", {"entry_id": str(entry_id)})
        db.session.delete(entry)
        db.session.commit()

    @staticmethod
    def _get_or_create_shortlist(student_id: uuid.UUID) -> Shortlist:
        """The profile's shortlist (the oldest, if there were ever several); created when missing."""
        shortlist = db.session.scalar(
            select(Shortlist)
            .where(Shortlist.student_id == student_id)
            .order_by(Shortlist.date_created, Shortlist.shortlist_id)
            .limit(1)
        )
        if shortlist is None:
            shortlist = Shortlist(student_id=student_id)
            db.session.add(shortlist)
            db.session.commit()
        return shortlist
