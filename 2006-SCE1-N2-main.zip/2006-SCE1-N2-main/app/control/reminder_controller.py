"""Class diagram: ReminderController «control» (UC11; M7 Notifications, ARC-02 §3.7.4).

The class diagram's Notification entity is stored in the DATA-01 table deadline_reminder.
"""
import uuid
from datetime import date, timedelta

from flask import current_app
from sqlalchemy import exists, select
from sqlalchemy.exc import IntegrityError

from app.control.application_status_controller import singapore_today
from app.errors import NotFoundError
from app.extensions import db
from app.models import Application, DeadlineReminder, StudentProfile, UserAccount


class ReminderController:
    """Daily deadline check and the user's stored reminders."""

    REMINDER_WINDOW_DAYS = 7  # UC11 step 1: today to today + 7, Asia/Singapore

    def check_deadlines(self, today: date | None = None) -> int:
        """Class diagram: checkDeadlines(). Run by the daily job and `flask check-deadlines` (UC11 steps 1–3).

        Inputs: the Singapore date to check from; defaults to today in Asia/Singapore.
        Output: number of reminders created. Safe to run twice (unique application_id, remind_for_deadline).
        Errors: none raised; a failure for one application is logged and retried on the next run (UC11 alt flow 2).
        """
        today = today or singapore_today()
        last_day = today + timedelta(days=self.REMINDER_WINDOW_DAYS)
        # UC11 steps 1–2: upcoming deadlines (uses the partial index ix_application_deadline), with each owner.
        # A past deadline is outside the window, so it is never reminded (UC13 alt flow 2).
        candidates = db.session.execute(
            select(Application, UserAccount)
            .join(StudentProfile, StudentProfile.student_id == Application.student_id)
            .join(UserAccount, UserAccount.user_id == StudentProfile.user_id)
            .where(Application.deadline.is_not(None), Application.deadline.between(today, last_day))
            .order_by(Application.deadline, Application.application_id)
        ).all()

        created = 0
        for application, user in candidates:
            # UC11 step 3 and postcondition: no reminder when notifications are off; never twice per deadline.
            if not self._is_notification_opted_in(user) or self._is_reminder_already_generated(application):
                continue
            try:
                with db.session.begin_nested():  # one application's failure must not undo the others
                    self.generate_reminder(application)
                created += 1
            except IntegrityError:
                # Another run inserted the same (application, deadline) first: already reminded.
                continue
            except Exception:
                current_app.logger.exception(
                    "Deadline reminder failed for application %s; it is retried on the next run.",
                    application.application_id,
                )
        db.session.commit()
        return created

    def generate_reminder(self, application: Application) -> DeadlineReminder:
        """Class diagram: generateReminder(application). Insert one deadline_reminder for the current deadline."""
        # channel and sent_at take the column defaults ('email', now()). Email sending itself is open
        # question ARC-02 Q2; until then the reminder is shown in the app through GET /api/notifications.
        reminder = DeadlineReminder(
            application_id=application.application_id, remind_for_deadline=application.deadline
        )
        db.session.add(reminder)
        db.session.flush()
        return reminder

    def list_notifications(self, user_id: uuid.UUID) -> list[DeadlineReminder]:
        """Stored reminders for the user's applications, newest first (UC11 step 4)."""
        query = (
            select(DeadlineReminder)
            .join(Application, Application.application_id == DeadlineReminder.application_id)
            .join(StudentProfile, StudentProfile.student_id == Application.student_id)
            .where(StudentProfile.user_id == user_id)
            .order_by(DeadlineReminder.sent_at.desc(), DeadlineReminder.remind_for_deadline)
        )
        return list(db.session.scalars(query))

    def mark_as_read(self, user_id: uuid.UUID, reminder_id: uuid.UUID) -> DeadlineReminder:
        """Class diagram: Notification.markAsRead(). Set deadline_reminder.is_read (DATA-01 v1.1, ARC-02 Q1).

        Inputs: logged-in user id, reminder id.
        Output: the reminder, now read. Marking a read reminder again changes nothing.
        Errors: NotFoundError if the reminder does not exist or belongs to another user.
        """
        query = (
            select(DeadlineReminder)
            .join(Application, Application.application_id == DeadlineReminder.application_id)
            .join(StudentProfile, StudentProfile.student_id == Application.student_id)
            .where(DeadlineReminder.reminder_id == reminder_id, StudentProfile.user_id == user_id)
        )
        reminder = db.session.scalar(query)
        if reminder is None:
            # Same answer whether it is missing or someone else's (ARC-02 §3.9.3).
            raise NotFoundError("Notification not found.", {"reminder_id": str(reminder_id)})
        if not reminder.is_read:
            reminder.is_read = True
            db.session.commit()
        return reminder

    def _is_notification_opted_in(self, user: UserAccount) -> bool:
        """Class diagram: isNotificationOptedIn(user). Reads notification_opt_in (UC11 step 2)."""
        return bool(user.notification_opt_in)

    def _is_reminder_already_generated(self, application: Application) -> bool:
        """Class diagram: isReminderAlreadyGenerated(application). True if a row exists for (application, deadline)."""
        return bool(
            db.session.scalar(
                select(
                    exists().where(
                        DeadlineReminder.application_id == application.application_id,
                        DeadlineReminder.remind_for_deadline == application.deadline,
                    )
                )
            )
        )
