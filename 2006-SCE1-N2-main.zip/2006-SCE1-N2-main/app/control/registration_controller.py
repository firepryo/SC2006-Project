"""Class diagram: RegistrationController «control» (UC01; M1 Accounts, ARC-02 §3.4)."""
import re
import uuid

from flask import current_app
from geoalchemy2.elements import WKTElement
from sqlalchemy import exists, select
from werkzeug.security import generate_password_hash

from app.errors import ConflictError, DomainError, NotFoundError, ValidationError
from app.extensions import db
from app.gateway import OneMapGateway
from app.models import UserAccount

POSTAL_CODE_PATTERN = re.compile(r"^[0-9]{6}$")
EMAIL_PATTERN = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
MIN_PASSWORD_LENGTH = 8
MAX_NAME_LENGTH = 100  # user_account.name is varchar(100)


class RegistrationController:
    """Creates accounts and keeps the user's home location (used by UC07a)."""

    def __init__(self, onemap_gateway: OneMapGateway | None = None):
        self.onemap_gateway = onemap_gateway or OneMapGateway()

    def register_account(
        self,
        name: str,
        email: str,
        password: str,
        preferred_postal_code: str | None = None,
        notification_opt_in: bool = True,
    ) -> UserAccount:
        """Class diagram: registerAccount(). Create a signed-out account (UC01 main flow 1–4).

        Inputs: name, email, password; optional postal code and opt-in (UC01 step 1).
        Output: the new UserAccount (password stored only as a hash, ARC-02 §3.9.4).
        Errors: ValidationError for missing or malformed fields; ConflictError if the email is registered.
            A geocoding failure does not fail registration; home_location stays NULL (ARC-02 §5).
        """
        name = (name or "").strip()
        email = (email or "").strip()
        postal_code = (preferred_postal_code or "").strip() or None
        self._validate_account_information(name, email, password, postal_code)
        if self._is_email_registered(email):
            raise ConflictError("An account with this email already exists.", {"email": "already registered"})

        account = UserAccount(
            name=name,
            email=email,
            password_hash=generate_password_hash(password),
            preferred_postal_code=postal_code,
            notification_opt_in=notification_opt_in,
        )
        if postal_code:
            account.home_location = self._geocode_or_none(postal_code)
        db.session.add(account)
        db.session.commit()
        return account

    def update_home_location(self, user_id: uuid.UUID, preferred_postal_code: str) -> UserAccount:
        """Set or correct the home postal code and its coordinates (UC07a alt flow 1).

        Inputs: logged-in user id, six-digit postal code; an empty value clears the home location.
        Output: the updated UserAccount.
        Errors: ValidationError for a malformed or unknown postal code; ExternalServiceError if OneMap is down.
        """
        account = db.session.get(UserAccount, user_id)
        if account is None:
            raise NotFoundError("Account not found.")
        postal_code = (preferred_postal_code or "").strip()
        if not postal_code:
            account.preferred_postal_code = None
            account.home_location = None
            db.session.commit()
            return account
        if not POSTAL_CODE_PATTERN.match(postal_code):
            raise ValidationError("Postal code must be 6 digits.", {"preferred_postal_code": "must be 6 digits"})
        coordinates = self.onemap_gateway.geocode_postal_code(postal_code)  # ExternalServiceError propagates (503)
        if coordinates is None:
            raise ValidationError(
                "OneMap could not find this postal code.", {"preferred_postal_code": "not found in OneMap"}
            )
        account.preferred_postal_code = postal_code
        account.home_location = _point(coordinates)
        db.session.commit()
        return account

    def _validate_account_information(self, name: str, email: str, password: str, preferred_postal_code: str | None) -> None:
        """Class diagram: validateAccountInformation(). Errors: ValidationError with per-field details (FR 1.3)."""
        errors: dict[str, str] = {}
        if not name:
            errors["name"] = "required"
        elif len(name) > MAX_NAME_LENGTH:
            errors["name"] = f"at most {MAX_NAME_LENGTH} characters"
        if not EMAIL_PATTERN.match(email or ""):
            errors["email"] = "not a valid email address"
        if not password or len(password) < MIN_PASSWORD_LENGTH:
            errors["password"] = f"at least {MIN_PASSWORD_LENGTH} characters"
        if preferred_postal_code and not POSTAL_CODE_PATTERN.match(preferred_postal_code):
            errors["preferred_postal_code"] = "must be 6 digits"
        if errors:
            raise ValidationError("Some account details are missing or invalid.", errors)

    def _is_email_registered(self, email: str) -> bool:
        """Class diagram: isEmailRegistered(email). Case-insensitive via citext (FR 1.4)."""
        return bool(db.session.scalar(select(exists().where(UserAccount.email == email))))

    def _geocode_or_none(self, postal_code: str) -> WKTElement | None:
        """Registration never fails on OneMap: an unknown code or an outage leaves home_location NULL."""
        try:
            coordinates = self.onemap_gateway.geocode_postal_code(postal_code)
        except DomainError as exc:
            current_app.logger.warning("Geocoding %s at registration failed: %s", postal_code, exc)
            return None
        return _point(coordinates) if coordinates else None


def _point(coordinates: tuple[float, float]) -> WKTElement:
    latitude, longitude = coordinates
    return WKTElement(f"POINT({longitude} {latitude})", srid=4326)  # WKT is (lon lat)
