"""Class diagram: LoginController «control» (UC02, NFR 3.5.1; M1 Accounts, ARC-02 §3.7.2)."""
import math
import uuid
from datetime import datetime, timedelta, timezone

from sqlalchemy import select
from werkzeug.security import check_password_hash

from app.errors import AccountLockedError, InvalidCredentialsError, NotFoundError
from app.extensions import db
from app.models import UserAccount


class LoginController:
    """Checks credentials and applies the lockout rule. Issuing the JWT cookie is the route's job (ARC-02 §3.2 rule 3)."""

    MAX_FAILED_ATTEMPTS = 5  # NFR 3.5.1
    LOCKOUT_DURATION = timedelta(minutes=15)  # NFR 3.5.1

    def login(self, email: str, password: str) -> UserAccount:
        """Class diagram: login(email, password). Authenticate a user (UC02 main flow 1–3).

        Inputs: email, password.
        Output: the authenticated UserAccount; failed_login_count reset to 0.
        Errors: AccountLockedError (details: remaining_seconds) if locked_until is in the future;
            InvalidCredentialsError for an unknown email or a wrong password.
        """
        account = db.session.scalar(select(UserAccount).where(UserAccount.email == (email or "").strip()))
        if account is None:
            raise InvalidCredentialsError("Incorrect email or password.")
        self._raise_if_locked(account)
        if not self._validate_credentials(account, password):
            self._handle_failed_attempt(account)
            db.session.commit()
            self._raise_if_locked(account)  # the fifth failure locks straight away
            raise InvalidCredentialsError("Incorrect email or password.")
        account.failed_login_count = 0
        account.locked_until = None
        db.session.commit()
        return account

    def logout(self, user_id: uuid.UUID) -> None:
        """End the session (UC02 postcondition). The route clears the JWT cookie; nothing is stored server-side."""
        return None

    def get_current_user(self, user_id: uuid.UUID) -> UserAccount:
        """Return the logged-in user for GET /api/auth/me. Errors: NotFoundError if the account was deleted."""
        account = db.session.get(UserAccount, user_id)
        if account is None:
            raise NotFoundError("Account not found.")
        return account

    def _validate_credentials(self, account: UserAccount, password: str) -> bool:
        """Class diagram: validateCredentials(). Compare against password_hash."""
        try:
            return check_password_hash(account.password_hash, password or "")
        except ValueError:  # not a werkzeug hash (e.g. a test row)
            return False

    def _handle_failed_attempt(self, account: UserAccount) -> None:
        """Class diagram: handleFailedAttempt(). Count the failure; at 5, set locked_until = now + 15 minutes."""
        account.failed_login_count = (account.failed_login_count or 0) + 1
        if account.failed_login_count >= self.MAX_FAILED_ATTEMPTS:
            account.locked_until = datetime.now(timezone.utc) + self.LOCKOUT_DURATION
            account.failed_login_count = 0

    @staticmethod
    def _raise_if_locked(account: UserAccount) -> None:
        if account.locked_until and account.locked_until > datetime.now(timezone.utc):
            remaining = math.ceil((account.locked_until - datetime.now(timezone.utc)).total_seconds())
            raise AccountLockedError(
                "Too many failed attempts. Try again later.",
                {"remaining_seconds": remaining, "locked_until": account.locked_until.isoformat()},
            )
