"""Ownership checks used by every controller that takes a profile or application id (ARC-02 §3.9.3)."""
import uuid

from flask_jwt_extended import get_jwt_identity
from sqlalchemy import select

from app.errors import NotFoundError
from app.extensions import db
from app.models import Application, StudentProfile


def current_user_id() -> uuid.UUID:
    """The logged-in user's id, for routes to pass to controllers.

    Inputs: none; reads the verified JWT, so call it only inside a jwt_required() route.
    Output: user_account.user_id. The JWT identity is str(user_id), set at login (UC02).
    Errors: RuntimeError if called outside a jwt_required() request.
    """
    return uuid.UUID(get_jwt_identity())


def require_profile_owner(user_id: uuid.UUID, student_id: uuid.UUID) -> StudentProfile:
    """Return the student profile only if it belongs to the user.

    Inputs: logged-in user id, student profile id.
    Output: the StudentProfile.
    Errors: NotFoundError if the profile does not exist or belongs to another user.
    """
    query = select(StudentProfile).where(
        StudentProfile.student_id == student_id,
        StudentProfile.user_id == user_id,
    )
    profile = db.session.scalar(query)
    if profile is None:
        # Same answer whether it is missing or someone else's, so other users' ids are never revealed.
        raise NotFoundError("Student profile not found.", {"student_id": str(student_id)})
    return profile


def require_application_owner(user_id: uuid.UUID, application_id: uuid.UUID) -> Application:
    """Return the application only if its student profile belongs to the user.

    Inputs: logged-in user id, application id.
    Output: the Application.
    Errors: NotFoundError if the application does not exist or belongs to another user (UC11 alt flow 3).
    """
    query = (
        select(Application)
        .join(StudentProfile, Application.student_id == StudentProfile.student_id)
        .where(
            Application.application_id == application_id,
            StudentProfile.user_id == user_id,
        )
    )
    application = db.session.scalar(query)
    if application is None:
        raise NotFoundError("Application not found.", {"application_id": str(application_id)})
    return application
