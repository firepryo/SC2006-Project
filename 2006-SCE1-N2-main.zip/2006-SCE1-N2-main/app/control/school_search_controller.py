"""Class diagram: SchoolSearchController «control» (UC04, UC05; M3 School discovery, ARC-02 §3.4)."""
import uuid
from dataclasses import dataclass

from sqlalchemy import Select, exists, func, select

from app.control.school_data_sync_controller import MAIN_LEVEL_MAP
from app.errors import ValidationError
from app.extensions import db
from app.models import Cca, EducationLevel, School, SchoolCca, SchoolSubject, Subject, UserAccount

ZONES = ("NORTH", "SOUTH", "EAST", "WEST")  # zone_code values in the school dataset (DATA-01 §3.8)
MAX_QUERY_LENGTH = 150  # school.name is varchar(150)


@dataclass
class SearchCriteria:
    """Search text plus optional filters (UC04 step 1, UC05 step 1). All None means "all in-scope schools"."""

    q: str | None = None
    level: EducationLevel | None = None
    zone: str | None = None
    planning_area: str | None = None
    subject_id: uuid.UUID | None = None
    cca_id: uuid.UUID | None = None


class SchoolSearchController:
    """Finds schools in the local synchronised copy; never calls data.gov.sg on the request path (ARC-02 §5)."""

    def search_schools(self, criteria: SearchCriteria, user_id: uuid.UUID | None = None) -> list[School]:
        """Class diagram: searchSchools(criteria). Name search, then UC05 filters if any are set (UC04 main flow).

        Inputs: criteria; the logged-in user, whose geocoded home (UC07a) gives each result a distance.
        Output: active schools that match, ordered by name; may be empty (UC04 alt flow 2). Each school has
            distance_km: the straight-line distance from home in km, or None without a home location.
            (Road distance needs one OneMap call per school, so it is used only for details and comparison.)
        Errors: ValidationError for invalid filter values (UC05 alt flow 1).
        """
        query = select(School).where(School.is_active.is_(True))
        text = (criteria.q or "").strip()
        if len(text) > MAX_QUERY_LENGTH:
            raise ValidationError("Search text is too long.", {"q": f"at most {MAX_QUERY_LENGTH} characters"})
        if text:
            # Escape LIKE wildcards so "%" or "_" typed by the user match literally.
            escaped = text.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
            query = query.where(School.name.ilike(f"%{escaped}%", escape="\\"))
        query = self.filter_schools(query, criteria)
        schools = list(db.session.scalars(query.order_by(School.name)))
        distances = self._distances_from_home(user_id, [s.school_id for s in schools]) if user_id else {}
        for school in schools:
            school.distance_km = distances.get(school.school_id)
        return schools

    @staticmethod
    def _distances_from_home(user_id: uuid.UUID, school_ids: list[uuid.UUID]) -> dict[uuid.UUID, float]:
        """Straight-line km from the user's home to each school (PostGIS geography distance, metres / 1000)."""
        home = select(UserAccount.home_location).where(
            UserAccount.user_id == user_id, UserAccount.home_location.is_not(None)
        ).scalar_subquery()
        rows = db.session.execute(
            select(School.school_id, func.ST_Distance(School.location, home) / 1000.0).where(
                School.school_id.in_(school_ids), School.location.is_not(None)
            )
        )
        return {school_id: round(km, 2) for school_id, km in rows if km is not None}

    def filter_schools(self, query: Select, criteria: SearchCriteria) -> Select:
        """Class diagram: filterSchools(criteria). UC05 extension point: validate and apply the set filters."""
        errors: dict[str, str] = {}
        if criteria.zone and criteria.zone.strip().upper() not in ZONES:
            errors["zone"] = f"must be one of {', '.join(z.title() for z in ZONES)}"
        if criteria.subject_id and db.session.get(Subject, criteria.subject_id) is None:
            errors["subject_id"] = "unknown subject"
        if criteria.cca_id and db.session.get(Cca, criteria.cca_id) is None:
            errors["cca_id"] = "unknown CCA"
        if errors:
            raise ValidationError("Invalid search filters.", errors)
        return self._apply_filters(query, criteria)

    def _apply_filters(self, query: Select, criteria: SearchCriteria) -> Select:
        """Class diagram: applyFilters(schools). Add one WHERE/JOIN per set filter (indexes in DATA-01 §3.6)."""
        if criteria.level:
            # A mixed-level school counts for every level it teaches (ADR-002 mapping).
            main_levels = [code for code, (_, levels) in MAIN_LEVEL_MAP.items() if criteria.level in levels]
            query = query.where(School.main_level.in_(main_levels))
        if criteria.zone:
            query = query.where(School.zone == criteria.zone.strip().upper())
        if criteria.planning_area and criteria.planning_area.strip():
            query = query.where(func.upper(School.planning_area) == criteria.planning_area.strip().upper())
        if criteria.subject_id:
            query = query.where(
                exists().where(
                    SchoolSubject.school_id == School.school_id, SchoolSubject.subject_id == criteria.subject_id
                )
            )
        if criteria.cca_id:
            query = query.where(
                exists().where(SchoolCca.school_id == School.school_id, SchoolCca.cca_id == criteria.cca_id)
            )
        return query

    def list_subjects(self) -> list[Subject]:
        """All subjects, for the profile form and the subject filter (UC03, UC05).

        Output: every subject row, ordered by level then name; empty if none are seeded yet.
        """
        query = select(Subject).order_by(Subject.level, Subject.subject_name)
        return list(db.session.scalars(query))

    def list_ccas(self) -> list[Cca]:
        """All CCAs, for the profile form and the CCA filter (UC03, UC05).

        Output: every CCA row, ordered by category then name; empty before the first sync.
        """
        query = select(Cca).order_by(Cca.category, Cca.cca_name)
        return list(db.session.scalars(query))
