"""Class diagram: SchoolDetailsController «control» (UC06; M3 School discovery, ARC-02 §3.4)."""
import uuid
from dataclasses import dataclass, field

from flask import current_app
from sqlalchemy import func, or_, select

from app.errors import DomainError, NotFoundError
from app.extensions import db
from app.gateway import OneMapGateway
from app.models import Affiliation, Cca, School, SchoolCca, SchoolSubject, Subject, UserAccount


@dataclass
class SchoolDetails:
    """Everything the details screen shows (UC06 steps 2–3)."""

    school: School
    subjects: list[Subject] = field(default_factory=list)
    ccas: list[Cca] = field(default_factory=list)
    affiliations: list[Affiliation] = field(default_factory=list)


@dataclass
class SchoolRoute:
    """Where the school is relative to home, for the "Getting there" map (UC06, UC07a)."""

    school: dict  # {"lat", "lng"}
    home: dict | None = None  # None until the user sets a home postal code
    distance_km: float | None = None  # OneMap road distance
    duration_min: float | None = None
    straight_line_km: float | None = None
    path: list[list[float]] = field(default_factory=list)  # [[lat, lng], ...] from OneMap
    route_type: str = OneMapGateway.ROUTE_TYPE
    note: str | None = None  # why distance is missing, shown by the UI


class SchoolDetailsController:
    """Loads one school with its offerings."""

    def __init__(self, onemap_gateway: OneMapGateway | None = None):
        self.onemap_gateway = onemap_gateway or OneMapGateway()

    def retrieve_school_route(self, user_id: uuid.UUID, school_id: uuid.UUID) -> SchoolRoute:
        """The school's location, the user's home and the OneMap route between them.

        Output: SchoolRoute. Without a home location only the school is set; if OneMap fails the straight-line
            distance is still given and `note` says the route is unavailable.
        Errors: NotFoundError if the school does not exist, is inactive or has no location.
        """
        school_point = db.session.execute(
            select(func.ST_Y(func.geometry(School.location)), func.ST_X(func.geometry(School.location))).where(
                School.school_id == school_id, School.is_active.is_(True), School.location.is_not(None)
            )
        ).first()
        if school_point is None:
            raise NotFoundError("School location not available.", {"school_id": str(school_id)})
        route = SchoolRoute(school={"lat": school_point[0], "lng": school_point[1]})

        home_point = db.session.execute(
            select(
                func.ST_Y(func.geometry(UserAccount.home_location)),
                func.ST_X(func.geometry(UserAccount.home_location)),
                func.ST_Distance(
                    UserAccount.home_location,
                    select(School.location).where(School.school_id == school_id).scalar_subquery(),
                ),
            ).where(UserAccount.user_id == user_id, UserAccount.home_location.is_not(None))
        ).first()
        if home_point is None:
            route.note = "Home location not set"
            return route
        route.home = {"lat": home_point[0], "lng": home_point[1]}
        route.straight_line_km = round(home_point[2] / 1000.0, 2)

        try:
            detail = self.onemap_gateway.get_route_detail(
                (home_point[0], home_point[1]), (school_point[0], school_point[1])
            )
        except DomainError as exc:
            current_app.logger.warning("OneMap route for school %s failed: %s", school_id, exc)
            route.note = "OneMap route unavailable"
            return route
        if detail is None:
            route.note = "OneMap found no route"
            return route
        route.distance_km = round(detail["distance_m"] / 1000.0, 2)
        route.duration_min = round(detail["duration_s"] / 60.0, 1)
        route.path = detail["path"]
        return route

    def retrieve_school_details(self, school_id: uuid.UUID) -> SchoolDetails:
        """Class diagram: retrieveSchoolDetails(schoolID). Load the school, subjects, CCAs and affiliations.

        Output: SchoolDetails; empty lists are shown as "None" or "Not available" by the UI (UC06 alt flow 1).
        Errors: NotFoundError if the school does not exist or is inactive (UC06 alt flow 2).
        """
        school = db.session.get(School, school_id)
        if school is None or not school.is_active:
            raise NotFoundError("School not found.", {"school_id": str(school_id)})
        return SchoolDetails(
            school=school,
            subjects=self.load_subjects([school_id]).get(school_id, []),
            ccas=self.load_ccas([school_id]).get(school_id, []),
            affiliations=self.load_affiliations([school_id]).get(school_id, []),
        )

    # Batch loaders, also used by the comparison (one query each for 2–5 schools, NFR 3.3.3).

    @staticmethod
    def load_subjects(school_ids: list[uuid.UUID]) -> dict[uuid.UUID, list[Subject]]:
        """Subjects per school, special programmes first, then by level and name."""
        rows = db.session.execute(
            select(SchoolSubject.school_id, Subject)
            .join(Subject, Subject.subject_id == SchoolSubject.subject_id)
            .where(SchoolSubject.school_id.in_(school_ids))
            .order_by(Subject.is_special_programme.desc(), Subject.level, Subject.subject_name)
        )
        result: dict[uuid.UUID, list[Subject]] = {}
        for school_id, subject in rows:
            result.setdefault(school_id, []).append(subject)
        return result

    @staticmethod
    def load_ccas(school_ids: list[uuid.UUID]) -> dict[uuid.UUID, list[Cca]]:
        """CCAs per school, by category then name."""
        rows = db.session.execute(
            select(SchoolCca.school_id, Cca)
            .join(Cca, Cca.cca_id == SchoolCca.cca_id)
            .where(SchoolCca.school_id.in_(school_ids))
            .order_by(Cca.category, Cca.cca_name)
        )
        result: dict[uuid.UUID, list[Cca]] = {}
        for school_id, cca in rows:
            result.setdefault(school_id, []).append(cca)
        return result

    @staticmethod
    def load_affiliations(school_ids: list[uuid.UUID]) -> dict[uuid.UUID, list[Affiliation]]:
        """Affiliations where the school is the feeder or the receiving school."""
        rows = db.session.scalars(
            select(Affiliation).where(
                or_(Affiliation.feeder_school_id.in_(school_ids), Affiliation.receiving_school_id.in_(school_ids))
            )
        )
        result: dict[uuid.UUID, list[Affiliation]] = {}
        wanted = set(school_ids)
        for affiliation in rows:
            for school_id in {affiliation.feeder_school_id, affiliation.receiving_school_id} & wanted:
                result.setdefault(school_id, []).append(affiliation)
        return result
