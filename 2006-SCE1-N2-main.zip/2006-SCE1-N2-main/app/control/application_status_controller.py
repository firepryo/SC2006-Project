"""Class diagram: ApplicationStatusController «control» (UC10; M6 Applications, ARC-02 §3.10 State)."""
import uuid
from datetime import date, datetime
from zoneinfo import ZoneInfo

from app.control.access_control import require_application_owner
from app.control.application_controller import attach_school, touch
from app.errors import ConflictError
from app.extensions import db
from app.models import Application, ApplicationStatus

SINGAPORE = ZoneInfo("Asia/Singapore")


def singapore_today() -> date:
    """Today's date in Singapore, where every date the user sees is meant (UC10 step 4, UC11)."""
    return datetime.now(SINGAPORE).date()


class ApplicationStatusController:
    """Moves an application through its status state machine."""

    # UC10 alt flow 3: the only allowed transitions
    ALLOWED_TRANSITIONS: dict[ApplicationStatus, frozenset[ApplicationStatus]] = {
        ApplicationStatus.Draft: frozenset({ApplicationStatus.Submitted}),
        ApplicationStatus.Submitted: frozenset({ApplicationStatus.UnderReview}),
        ApplicationStatus.UnderReview: frozenset({ApplicationStatus.Offered, ApplicationStatus.Rejected}),
        ApplicationStatus.Offered: frozenset({ApplicationStatus.Accepted}),
        ApplicationStatus.Rejected: frozenset(),
        ApplicationStatus.Accepted: frozenset(),
    }

    def get_application_status(self, user_id: uuid.UUID, application_id: uuid.UUID) -> ApplicationStatus:
        """Class diagram: getApplicationStatus(applicationID). Errors: NotFoundError (UC10 step 1)."""
        return require_application_owner(user_id, application_id).status

    def update_application_status(
        self, user_id: uuid.UUID, application_id: uuid.UUID, new_status: ApplicationStatus
    ) -> Application:
        """Class diagram: updateApplicationStatus(applicationID, status). Save a valid transition (UC10 steps 3–5).

        Output: the updated Application; date_submitted is set when entering Submitted (UC10 step 4).
        Errors: NotFoundError; ConflictError for a transition not in ALLOWED_TRANSITIONS (UC10 alt flow 3).
        """
        application = require_application_owner(user_id, application_id)
        current = application.status
        if not self._validate_status_transition(current, new_status):
            allowed = sorted(status.value for status in self.ALLOWED_TRANSITIONS[current])
            raise ConflictError(
                f"An application cannot move from {current.value} to {new_status.value}.",
                {"current_status": current.value, "requested_status": new_status.value, "allowed": allowed},
            )

        application.status = new_status
        if new_status is ApplicationStatus.Submitted:
            # Keeps the CHECK (status = 'Draft' OR date_submitted IS NOT NULL) true from here on.
            application.date_submitted = singapore_today()
        touch(application)
        db.session.commit()
        return attach_school(application)

    def _validate_status_transition(self, current: ApplicationStatus, next_status: ApplicationStatus) -> bool:
        """Class diagram: validateStatusTransition(current, next). True if next_status is allowed from current."""
        return next_status in self.ALLOWED_TRANSITIONS.get(current, frozenset())
