"""Class diagram: StudentProfileController «control» (UC03; M2 Student profiles, ARC-02 §3.4)."""
import uuid
from dataclasses import dataclass, field

from sqlalchemy import delete, exists, func, select

from app.control.access_control import require_profile_owner
from app.errors import ConflictError, ValidationError
from app.extensions import db
from app.models import (
    Application,
    Cca,
    EducationLevel,
    Shortlist,
    ShortlistEntry,
    StudentPreferredCca,
    StudentPreferredSubject,
    StudentProfile,
    Subject,
)

MAX_NAME_LENGTH = 100  # student_profile.name is varchar(100)
MAX_YEAR = {EducationLevel.Primary: 6, EducationLevel.Secondary: 5, EducationLevel.JuniorCollege: 2}


@dataclass
class ProfileInput:
    """Fields the user enters on the profile form (UC03 step 2, DATA-01 student_profile)."""

    current_level: EducationLevel
    current_year: int
    name: str | None = None
    preferred_subject_ids: list[uuid.UUID] = field(default_factory=list)
    preferred_cca_ids: list[uuid.UUID] = field(default_factory=list)


class StudentProfileController:
    """Create, edit and remove the user's student profiles.

    Returned profiles carry preferred_subject_ids and preferred_cca_ids as plain attributes for the response schema.
    """

    def list_profiles(self, user_id: uuid.UUID) -> list[StudentProfile]:
        """Display the user's profiles (UC03 step 1). Output: profiles with their preferences, oldest first."""
        profiles = list(
            db.session.scalars(
                select(StudentProfile).where(StudentProfile.user_id == user_id).order_by(StudentProfile.created_at)
            )
        )
        return [self._with_preferences(profile) for profile in profiles]

    def get_profile(self, user_id: uuid.UUID, student_id: uuid.UUID) -> StudentProfile:
        """Return one owned profile. Errors: NotFoundError (ARC-02 §3.9.3)."""
        return self._with_preferences(require_profile_owner(user_id, student_id))

    def create_profile(self, user_id: uuid.UUID, data: ProfileInput) -> StudentProfile:
        """Class diagram: createProfile(profile). Save a new profile and an empty shortlist (UC03 steps 2–4).

        Errors: ValidationError for missing level, year outside the level's range, or unknown subject/CCA ids.
        """
        self._validate_profile(data)
        profile = StudentProfile(
            user_id=user_id,
            name=(data.name or "").strip() or None,
            current_level=data.current_level,
            current_year=data.current_year,
        )
        db.session.add(profile)
        db.session.flush()
        self._replace_preferences(profile.student_id, data)
        db.session.add(Shortlist(student_id=profile.student_id))
        db.session.commit()
        return self._with_preferences(profile)

    def edit_profile(self, user_id: uuid.UUID, student_id: uuid.UUID, data: ProfileInput) -> StudentProfile:
        """Class diagram: editProfile(profile). Replace the profile's fields and preferences (UC03 alt flow 1).

        Errors: NotFoundError, ValidationError.
        """
        profile = require_profile_owner(user_id, student_id)
        self._validate_profile(data)
        profile.name = (data.name or "").strip() or None
        profile.current_level = data.current_level
        profile.current_year = data.current_year
        self._replace_preferences(student_id, data)
        db.session.commit()
        return self._with_preferences(profile)

    def remove_profile(self, user_id: uuid.UUID, student_id: uuid.UUID) -> None:
        """Class diagram: removeProfile(studentID). Remove a profile and its empty shortlists (UC03 alt flow 2).

        Errors: NotFoundError; ConflictError if applications or a non-empty shortlist reference it.
        """
        profile = require_profile_owner(user_id, student_id)
        has_applications = db.session.scalar(select(exists().where(Application.student_id == student_id)))
        has_entries = db.session.scalar(
            select(
                exists().where(
                    ShortlistEntry.shortlist_id == Shortlist.shortlist_id, Shortlist.student_id == student_id
                )
            )
        )
        if has_applications or has_entries:
            raise ConflictError(
                "This profile still has shortlisted schools or applications. Remove them first.",
                {"applications": bool(has_applications), "shortlist_entries": bool(has_entries)},
            )
        db.session.delete(profile)  # cascades to preferences and the empty shortlist (DATA-01 §3.5)
        db.session.commit()

    def _validate_profile(self, data: ProfileInput) -> None:
        """Class diagram: validateProfile(). Errors: ValidationError with per-field details (FR 3.7)."""
        errors: dict[str, str] = {}
        if data.current_level is None:
            errors["current_level"] = "required"
        elif not 1 <= (data.current_year or 0) <= MAX_YEAR[data.current_level]:
            errors["current_year"] = f"must be between 1 and {MAX_YEAR[data.current_level]}"
        if data.name and len(data.name.strip()) > MAX_NAME_LENGTH:
            errors["name"] = f"at most {MAX_NAME_LENGTH} characters"
        subject_ids, cca_ids = set(data.preferred_subject_ids), set(data.preferred_cca_ids)
        if subject_ids and db.session.scalar(
            select(func.count()).select_from(Subject).where(Subject.subject_id.in_(subject_ids))
        ) != len(subject_ids):
            errors["preferred_subject_ids"] = "unknown subject"
        if cca_ids and db.session.scalar(
            select(func.count()).select_from(Cca).where(Cca.cca_id.in_(cca_ids))
        ) != len(cca_ids):
            errors["preferred_cca_ids"] = "unknown CCA"
        if errors:
            raise ValidationError("Some profile details are missing or invalid.", errors)

    @staticmethod
    def _replace_preferences(student_id: uuid.UUID, data: ProfileInput) -> None:
        db.session.execute(delete(StudentPreferredSubject).where(StudentPreferredSubject.student_id == student_id))
        db.session.execute(delete(StudentPreferredCca).where(StudentPreferredCca.student_id == student_id))
        for subject_id in set(data.preferred_subject_ids):
            db.session.add(StudentPreferredSubject(student_id=student_id, subject_id=subject_id))
        for cca_id in set(data.preferred_cca_ids):
            db.session.add(StudentPreferredCca(student_id=student_id, cca_id=cca_id))
        db.session.flush()

    @staticmethod
    def _with_preferences(profile: StudentProfile) -> StudentProfile:
        profile.preferred_subject_ids = list(
            db.session.scalars(
                select(StudentPreferredSubject.subject_id).where(StudentPreferredSubject.student_id == profile.student_id)
            )
        )
        profile.preferred_cca_ids = list(
            db.session.scalars(
                select(StudentPreferredCca.cca_id).where(StudentPreferredCca.student_id == profile.student_id)
            )
        )
        return profile
