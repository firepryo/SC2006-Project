"""Class diagram: ApplicationDeadlineController «control» (UC13; M6 Applications, ARC-02 §3.4)."""
import uuid
from datetime import date, datetime

from app.control.access_control import require_application_owner
from app.control.application_controller import attach_school, touch
from app.errors import ValidationError
from app.extensions import db
from app.models import Application


class ApplicationDeadlineController:
    """Set, change or clear an application's deadline; UC11 reads it."""

    def get_deadline(self, user_id: uuid.UUID, application_id: uuid.UUID) -> date | None:
        """Class diagram: getDeadline(applicationID). Output: the deadline or None (UC13 step 1). Errors: NotFoundError."""
        return require_application_owner(user_id, application_id).deadline

    def set_deadline(self, user_id: uuid.UUID, application_id: uuid.UUID, deadline: date) -> Application:
        """Class diagram: setDeadline(applicationID, date). Save the deadline (UC13 steps 2–4).

        A past date is stored but never reminded (UC13 alt flow 2).
        Errors: NotFoundError; ValidationError for an invalid date.
        """
        application = require_application_owner(user_id, application_id)
        if not self._validate_deadline(deadline):
            raise ValidationError("The deadline must be a calendar date.", {"deadline": str(deadline)})
        application.deadline = deadline
        touch(application)
        db.session.commit()
        return attach_school(application)

    def clear_deadline(self, user_id: uuid.UUID, application_id: uuid.UUID) -> Application:
        """Class diagram: clearDeadline(applicationID). Set deadline to NULL (UC13 alt flow 1). Errors: NotFoundError."""
        application = require_application_owner(user_id, application_id)
        application.deadline = None
        touch(application)
        db.session.commit()
        return attach_school(application)

    def _validate_deadline(self, deadline: date) -> bool:
        """Class diagram: validateDeadline(date). True for a real calendar date (UC13 step 3).

        The route's DeadlineSchema already rejects text that is not a date (e.g. 2026-02-30) with 400;
        this guards direct callers. A datetime is not a calendar date, so it is refused too.
        """
        return isinstance(deadline, date) and not isinstance(deadline, datetime)
