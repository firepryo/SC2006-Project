"""Comparison criteria as strategies, one per comparison_criterion row (UC07a–d, ARC-02 §3.10 Strategy)."""
import math
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

from app.errors import ExternalServiceError
from app.gateway import OneMapGateway
from app.models import Affiliation, Cca, School, Subject

Coordinates = tuple[float, float]  # (latitude, longitude)


@dataclass
class ComparisonContext:
    """What the criteria may personalise against, plus each school's pre-loaded data (one query per kind).

    Empty preferences mean "Preferences not set" (UC07b/c alt flow 1).
    """

    home_coordinates: Coordinates | None = None  # from user_account.home_location (UC07a)
    preferred_subject_ids: set[uuid.UUID] = field(default_factory=set)
    preferred_cca_ids: set[uuid.UUID] = field(default_factory=set)
    school_coordinates: dict[uuid.UUID, Coordinates] = field(default_factory=dict)
    school_subjects: dict[uuid.UUID, list[Subject]] = field(default_factory=dict)
    school_ccas: dict[uuid.UUID, list[Cca]] = field(default_factory=dict)
    school_affiliations: dict[uuid.UUID, list[Affiliation]] = field(default_factory=dict)
    school_names: dict[uuid.UUID, str] = field(default_factory=dict)  # for naming affiliated schools
    affiliation_data_available: bool = False  # False while no affiliation source is loaded


@dataclass
class CriterionResult:
    """One cell of the comparison table. available=False is shown as "Not available" (FR 7.8)."""

    criterion_id: int
    value: Any
    available: bool = True
    note: str | None = None  # e.g. "Preferences not set", "No preference match", "None"


class ComparisonCriterionStrategy(ABC):
    """Strategy interface. criterion_id matches the seeded comparison_criterion row (DATA-01 §3.6)."""

    criterion_id: int
    criterion_name: str

    @abstractmethod
    def evaluate(self, school: School, context: ComparisonContext) -> CriterionResult:
        """Compute this criterion for one school.

        Inputs: a school; the comparison context with that school's data pre-loaded.
        Output: a CriterionResult; never raises for missing data, returns available=False instead.
        """

    def _unavailable(self, note: str) -> CriterionResult:
        return CriterionResult(self.criterion_id, None, available=False, note=note)


def straight_line_km(a: Coordinates, b: Coordinates) -> float:
    """Great-circle (haversine) distance in km; the fallback when no travel route is available."""
    lat1, lon1, lat2, lon2 = map(math.radians, (*a, *b))
    h = math.sin((lat2 - lat1) / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin((lon2 - lon1) / 2) ** 2
    return 6371.0 * 2 * math.asin(math.sqrt(h))


def _unique_names(items: list, attribute: str) -> list[str]:
    """Names in their given order without repeats (a subject exists once per level)."""
    seen: dict[str, None] = {}
    for item in items:
        seen.setdefault(getattr(item, attribute), None)
    return list(seen)


class DistanceCriterion(ComparisonCriterionStrategy):
    """UC07a Compare Distance: OneMap travel distance and time from home to school (user decision 2026-11-06).

    Falls back to straight-line distance, with a note, if OneMap has no route or is unavailable.
    """

    criterion_id = 1
    criterion_name = "Distance"

    def __init__(self, onemap_gateway: OneMapGateway | None = None):
        self.onemap_gateway = onemap_gateway or OneMapGateway()

    def evaluate(self, school: School, context: ComparisonContext) -> CriterionResult:
        if context.home_coordinates is None:
            return self._unavailable("Home location not set")
        school_coordinates = context.school_coordinates.get(school.school_id)
        if school_coordinates is None:
            return self._unavailable("School location not available")
        try:
            route = self.onemap_gateway.get_travel_route(context.home_coordinates, school_coordinates)
        except ExternalServiceError:
            route = None
        if route is not None:
            metres, seconds = route
            value = {
                "distance_km": round(metres / 1000, 1),
                "travel_time_min": round(seconds / 60),
                "method": f"travel ({OneMapGateway.ROUTE_TYPE})",
            }
            return CriterionResult(self.criterion_id, value)
        value = {
            "distance_km": round(straight_line_km(context.home_coordinates, school_coordinates), 1),
            "travel_time_min": None,
            "method": "straight line",
        }
        return CriterionResult(self.criterion_id, value, note="Straight-line distance: travel route unavailable")


class SubjectMatchCriterion(ComparisonCriterionStrategy):
    """UC07b Compare Subjects & Special Programmes: offerings and matches with preferred subjects."""

    criterion_id = 2
    criterion_name = "Subject Match"

    def evaluate(self, school: School, context: ComparisonContext) -> CriterionResult:
        subjects = context.school_subjects.get(school.school_id, [])
        if not subjects:
            return self._unavailable("Not available")
        matched = [s for s in subjects if s.subject_id in context.preferred_subject_ids]
        value = {
            "offered": _unique_names(subjects, "subject_name"),
            "special_programmes": _unique_names([s for s in subjects if s.is_special_programme], "subject_name"),
            "matched": _unique_names(matched, "subject_name"),
        }
        note = None
        if not context.preferred_subject_ids:
            note = "Preferences not set"  # UC07b alt flow 1
        elif not matched:
            note = "No preference match"  # UC07b alt flow 2
        return CriterionResult(self.criterion_id, value, note=note)


class CcaMatchCriterion(ComparisonCriterionStrategy):
    """UC07c Compare CCAs: offerings and matches with preferred CCAs."""

    criterion_id = 3
    criterion_name = "CCA Match"

    def evaluate(self, school: School, context: ComparisonContext) -> CriterionResult:
        ccas = context.school_ccas.get(school.school_id, [])
        if not ccas:
            return self._unavailable("Not available")
        matched = [c for c in ccas if c.cca_id in context.preferred_cca_ids]
        value = {
            "count": len(ccas),
            "offered": _unique_names(ccas, "cca_name"),
            "matched": _unique_names(matched, "cca_name"),
        }
        note = None
        if not context.preferred_cca_ids:
            note = "Preferences not set"  # UC07c alt flow 1
        elif not matched:
            note = "No preference match"  # UC07c alt flow 2
        return CriterionResult(self.criterion_id, value, note=note)


class AffiliationCriterion(ComparisonCriterionStrategy):
    """UC07d Compare Affiliations: affiliated schools and priority descriptions."""

    criterion_id = 4
    criterion_name = "Affiliation"

    def evaluate(self, school: School, context: ComparisonContext) -> CriterionResult:
        if not context.affiliation_data_available:
            return self._unavailable("Affiliation data not available")  # no source loaded yet
        affiliations = context.school_affiliations.get(school.school_id, [])
        value = []
        for affiliation in affiliations:
            is_feeder = affiliation.feeder_school_id == school.school_id
            other_id = affiliation.receiving_school_id if is_feeder else affiliation.feeder_school_id
            value.append(
                {
                    "school_id": str(other_id),
                    "school_name": context.school_names.get(other_id),
                    "relationship": "feeds into" if is_feeder else "receives from",
                    "priority_description": affiliation.priority_description,
                }
            )
        return CriterionResult(self.criterion_id, value, note=None if value else "None")
