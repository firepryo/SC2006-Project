"""Class diagram: NotificationPreferenceController «control» (UC14; M1 Accounts, ARC-02 §3.4)."""
import uuid

from app.errors import NotFoundError
from app.extensions import db
from app.models import UserAccount


class NotificationPreferenceController:
    """Reads and saves user_account.notification_opt_in (FR 11.2)."""

    def get_preference(self, user_id: uuid.UUID) -> bool:
        """Class diagram: getPreference(userID). Output: current notification_opt_in (UC14 step 1)."""
        return self._account(user_id).notification_opt_in

    def update_preference(self, user_id: uuid.UUID, opt_in: bool) -> bool:
        """Class diagram: updatePreference(userID, optIn). Save the setting (UC14 steps 2–4).

        Output: the saved value. Saving the value it already has is a no-op (UC14 alt flow 1).
        Errors: none of its own; a failed commit leaves the previous value (UC14 alt flow 2).
        """
        account = self._account(user_id)
        if account.notification_opt_in != opt_in:
            account.notification_opt_in = opt_in
            db.session.commit()
        return account.notification_opt_in

    @staticmethod
    def _account(user_id: uuid.UUID) -> UserAccount:
        account = db.session.get(UserAccount, user_id)
        if account is None:
            raise NotFoundError("Account not found.")
        return account
