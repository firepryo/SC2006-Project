"""marshmallow schemas for every endpoint, applied by flask-smorest at the boundary (ARC-02 §3.6, §3.7.1, §4.1).

Request schemas (client -> server) are used with @<bp>.arguments; response schemas (server -> client) with
@<bp>.response. Field names follow DATA-01 and match frontend/src/api/types.ts. Length and format rules are
fixed in the API- documents. Secrets (password, password_hash, failed_login_count, locked_until) never appear
in a response schema (ARC-02 §3.9.4).
"""
from marshmallow import Schema, fields

from app.models import ApplicationStatus, CcaCategory, EducationLevel, SchoolType


# ---------------------------------------------------------------- requests (client -> server)


class RegisterSchema(Schema):
    """POST /api/auth/register (UC01 step 1)."""

    name = fields.String(required=True)
    email = fields.Email(required=True)
    password = fields.String(required=True, load_only=True)
    preferred_postal_code = fields.String(load_default=None)
    notification_opt_in = fields.Boolean(load_default=True)


class LoginSchema(Schema):
    """POST /api/auth/login (UC02)."""

    email = fields.Email(required=True)
    password = fields.String(required=True, load_only=True)


class HomeLocationSchema(Schema):
    """PATCH /api/users/me (UC07a alt flow 1)."""

    preferred_postal_code = fields.String(required=True)


class NotificationPreferenceSchema(Schema):
    """PUT /api/users/me/notification-preference (UC14); also the GET and PUT response."""

    notification_opt_in = fields.Boolean(required=True)


class ProfileSchema(Schema):
    """POST and PUT /api/profiles (UC03 step 2)."""

    name = fields.String(load_default=None)
    current_level = fields.Enum(EducationLevel, required=True)
    current_year = fields.Integer(required=True)
    preferred_subject_ids = fields.List(fields.UUID(), load_default=list)
    preferred_cca_ids = fields.List(fields.UUID(), load_default=list)


class SearchQuerySchema(Schema):
    """GET /api/schools query string (UC04, UC05)."""

    q = fields.String(load_default=None)
    level = fields.Enum(EducationLevel, load_default=None)
    zone = fields.String(load_default=None)
    planning_area = fields.String(load_default=None)
    subject_id = fields.UUID(load_default=None)
    cca_id = fields.UUID(load_default=None)


class CompareSchema(Schema):
    """POST /api/schools/compare (UC07 step 1)."""

    school_ids = fields.List(fields.UUID(), required=True)
    student_id = fields.UUID(load_default=None)


class ShortlistAddSchema(Schema):
    """POST /api/profiles/<student_id>/shortlist/entries (UC08 step 2)."""

    school_id = fields.UUID(required=True)


class ApplicationListQuerySchema(Schema):
    """GET /api/applications query string (UC09, DM-60)."""

    student_id = fields.UUID(load_default=None)


class ApplicationCreateSchema(Schema):
    """POST /api/applications (UC09 steps 1–3)."""

    student_id = fields.UUID(required=True)
    school_id = fields.UUID(required=True)
    notes = fields.String(load_default=None)


class ApplicationUpdateSchema(Schema):
    """PATCH /api/applications/<id> (UC09 alt flow 1)."""

    notes = fields.String(required=True, allow_none=True)


class StatusUpdateSchema(Schema):
    """PATCH /api/applications/<id>/status (UC10 step 2)."""

    status = fields.Enum(ApplicationStatus, required=True)


class DeadlineSchema(Schema):
    """PUT /api/applications/<id>/deadline (UC13 step 2)."""

    deadline = fields.Date(required=True)


# ---------------------------------------------------------------- responses (server -> client)


class UserAccountSchema(Schema):
    """The logged-in account (types.ts UserAccount). Dumped from a UserAccount row."""

    user_id = fields.UUID()
    name = fields.String()
    email = fields.Email()
    preferred_postal_code = fields.String(allow_none=True)
    notification_opt_in = fields.Boolean()


class SubjectSchema(Schema):
    """types.ts Subject. Dumped from a Subject row."""

    subject_id = fields.UUID()
    subject_name = fields.String()
    level = fields.Enum(EducationLevel)
    is_special_programme = fields.Boolean()


class CcaSchema(Schema):
    """types.ts Cca. Dumped from a Cca row."""

    cca_id = fields.UUID()
    cca_name = fields.String()
    category = fields.Enum(CcaCategory)


class StudentProfileSchema(Schema):
    """types.ts StudentProfile. The controller supplies preferred_subject_ids and preferred_cca_ids."""

    student_id = fields.UUID()
    name = fields.String(allow_none=True)
    current_level = fields.Enum(EducationLevel)
    current_year = fields.Integer()
    preferred_subject_ids = fields.List(fields.UUID())
    preferred_cca_ids = fields.List(fields.UUID())


class SchoolSummarySchema(Schema):
    """types.ts SchoolSummary: one search result or comparison column. Dumped from a School row."""

    school_id = fields.UUID()
    name = fields.String()
    type = fields.Enum(SchoolType)
    address = fields.String()
    zone = fields.String(allow_none=True)
    planning_area = fields.String(allow_none=True)
    # Search results only: straight-line km from the user's home, null without a home location.
    distance_km = fields.Float(allow_none=True)


class LatLngSchema(Schema):
    """A point on the map."""

    lat = fields.Float()
    lng = fields.Float()


class SchoolRouteSchema(Schema):
    """GET /api/schools/<id>/route: school and home on the OneMap map, with the road route between them."""

    school = fields.Nested(LatLngSchema)
    home = fields.Nested(LatLngSchema, allow_none=True)
    distance_km = fields.Float(allow_none=True)
    duration_min = fields.Float(allow_none=True)
    straight_line_km = fields.Float(allow_none=True)
    path = fields.List(fields.List(fields.Float()))
    route_type = fields.String()
    note = fields.String(allow_none=True)


class AffiliationSchema(Schema):
    """types.ts Affiliation. Dumped from an Affiliation row."""

    affiliation_id = fields.UUID()
    feeder_school_id = fields.UUID()
    receiving_school_id = fields.UUID()
    priority_description = fields.String(allow_none=True)


class SchoolDetailsSchema(Schema):
    """types.ts SchoolDetails, flattened from the controller's SchoolDetails(school, subjects, ccas, affiliations)."""

    school_id = fields.UUID(attribute="school.school_id")
    name = fields.String(attribute="school.name")
    type = fields.Enum(SchoolType, attribute="school.type")
    address = fields.String(attribute="school.address")
    zone = fields.String(attribute="school.zone", allow_none=True)
    planning_area = fields.String(attribute="school.planning_area", allow_none=True)
    postal_code = fields.String(attribute="school.postal_code", allow_none=True)
    website = fields.String(attribute="school.website", allow_none=True)
    telephone = fields.String(attribute="school.telephone", allow_none=True)
    email = fields.String(attribute="school.email", allow_none=True)
    description = fields.String(attribute="school.description", allow_none=True)
    subjects = fields.List(fields.Nested(SubjectSchema))
    ccas = fields.List(fields.Nested(CcaSchema))
    affiliations = fields.List(fields.Nested(AffiliationSchema))


class CriterionResultSchema(Schema):
    """types.ts CriterionResult: one comparison cell; available=False is shown as "Not available" (FR 7.8)."""

    criterion_id = fields.Integer()
    value = fields.Raw(allow_none=True)
    available = fields.Boolean()
    note = fields.String(allow_none=True)


class ComparisonResultSchema(Schema):
    """types.ts ComparisonResult. Dumped from the controller's ComparisonResult."""

    schools = fields.List(fields.Nested(SchoolSummarySchema))
    rows = fields.Dict(keys=fields.Integer(), values=fields.List(fields.Nested(CriterionResultSchema)))
    personalised = fields.Boolean()


class ShortlistEntrySchema(Schema):
    """types.ts ShortlistEntry. The controller supplies the entry's school."""

    entry_id = fields.UUID()
    school = fields.Nested(SchoolSummarySchema)
    date_added = fields.Date()
    rank = fields.Integer(allow_none=True)


class ShortlistSchema(Schema):
    """types.ts Shortlist. The controller supplies the entries."""

    shortlist_id = fields.UUID()
    name = fields.String()
    notes = fields.String(allow_none=True)
    entries = fields.List(fields.Nested(ShortlistEntrySchema))


class ApplicationSchema(Schema):
    """types.ts Application. The controller supplies the application's school."""

    application_id = fields.UUID()
    student_id = fields.UUID()
    school = fields.Nested(SchoolSummarySchema)
    status = fields.Enum(ApplicationStatus)
    date_submitted = fields.Date(allow_none=True)
    deadline = fields.Date(allow_none=True)
    notes = fields.String(allow_none=True)
    updated_at = fields.DateTime()


class NotificationSchema(Schema):
    """types.ts Notification. Dumped from a DeadlineReminder row."""

    reminder_id = fields.UUID()
    application_id = fields.UUID()
    remind_for_deadline = fields.Date()
    sent_at = fields.DateTime()
    is_read = fields.Boolean()  # deadline_reminder.is_read (DATA-01 v1.1, ARC-02 Q1)


class DataFreshnessSchema(Schema):
    """GET /api/data-freshness: time of the last successful school sync (ARC-02 §3.7.5)."""

    last_successful_sync = fields.DateTime(allow_none=True)


class ErrorSchema(Schema):
    """Every error body (ARC-02 §4.2); used by errors.register_error_handlers."""

    error = fields.String()
    message = fields.String()
    details = fields.Dict()
