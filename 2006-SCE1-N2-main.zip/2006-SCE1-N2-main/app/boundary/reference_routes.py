"""API boundary for the subject and CCA pickers (UC03 step 2, UC05 step 1; ARC-02 §4.1)."""
from flask.views import MethodView
from flask_jwt_extended import jwt_required
from flask_smorest import Blueprint

from app.boundary.schemas import CcaSchema, DataFreshnessSchema, SubjectSchema
from app.control import SchoolDataSyncController, SchoolSearchController

reference_bp = Blueprint("reference", __name__)

school_search_controller = SchoolSearchController()
school_data_sync_controller = SchoolDataSyncController()


@reference_bp.route("/subjects")
class SubjectListAPI(MethodView):
    """/subjects"""

    @jwt_required()
    @reference_bp.response(200, SubjectSchema(many=True))
    def get(self):
        """200 with every subject (id, subject_name, level, is_special_programme)."""
        return school_search_controller.list_subjects()


@reference_bp.route("/ccas")
class CcaListAPI(MethodView):
    """/ccas"""

    @jwt_required()
    @reference_bp.response(200, CcaSchema(many=True))
    def get(self):
        """200 with every CCA (id, cca_name, category)."""
        return school_search_controller.list_ccas()


@reference_bp.route("/data-freshness")
class DataFreshnessAPI(MethodView):
    """/data-freshness"""

    @jwt_required()
    @reference_bp.response(200, DataFreshnessSchema)
    def get(self):
        """UC04/UC06/UC07 freshness notice. 200 with {"last_successful_sync": <timestamp or null>}."""
        return {"last_successful_sync": school_data_sync_controller.get_last_successful_sync()}
