"""API boundary for RegistrationUI and LoginUI (UC01, UC02, UC07a; M1 Accounts, ARC-02 §4.1)."""
from flask import jsonify
from flask.views import MethodView
from flask_jwt_extended import create_access_token, jwt_required, set_access_cookies, unset_jwt_cookies
from flask_smorest import Blueprint

from app.boundary.schemas import HomeLocationSchema, LoginSchema, RegisterSchema, UserAccountSchema
from app.control import LoginController, RegistrationController
from app.control.access_control import current_user_id

auth_bp = Blueprint("auth", __name__)

registration_controller = RegistrationController()
login_controller = LoginController()


@auth_bp.route("/auth/register")
class RegisterAPI(MethodView):
    """/auth/register (public)."""

    @auth_bp.arguments(RegisterSchema)
    @auth_bp.response(201, UserAccountSchema)
    def post(self, account_data):
        """UC01. 201 with the account (no secrets, ARC-02 §3.9.4); 400; 409 duplicate email."""
        return registration_controller.register_account(**account_data)


@auth_bp.route("/auth/login")
class LoginAPI(MethodView):
    """/auth/login (public)."""

    @auth_bp.arguments(LoginSchema)
    @auth_bp.response(200, UserAccountSchema)
    def post(self, credentials):
        """UC02. 200 with the account and set the JWT cookie; 401 invalid_credentials; 423 account_locked."""
        account = login_controller.login(credentials["email"], credentials["password"])
        response = jsonify(UserAccountSchema().dump(account))
        # JWT identity is str(user_id); access_control.current_user_id() reads it back (ARC-02 §3.9.2).
        set_access_cookies(response, create_access_token(identity=str(account.user_id)))
        return response


@auth_bp.route("/auth/logout")
class LogoutAPI(MethodView):
    """/auth/logout"""

    @jwt_required()
    @auth_bp.response(204)
    def post(self):
        """UC02 postcondition. 204 and clear the JWT cookie (ARC-02 §3.9.2)."""
        login_controller.logout(current_user_id())
        response = jsonify({})
        response.status_code = 204
        unset_jwt_cookies(response)
        return response


@auth_bp.route("/auth/me")
class CurrentUserAPI(MethodView):
    """/auth/me"""

    @jwt_required()
    @auth_bp.response(200, UserAccountSchema)
    def get(self):
        """Who is logged in; used by the SPA on start-up. 200 with the account; 401 session_expired."""
        return login_controller.get_current_user(current_user_id())


@auth_bp.route("/users/me")
class UserAccountAPI(MethodView):
    """/users/me"""

    @jwt_required()
    @auth_bp.arguments(HomeLocationSchema)
    @auth_bp.response(200, UserAccountSchema)
    def patch(self, location_data):
        """UC07a alt flow 1. 200 with the account; 400; 503 if OneMap is down. An empty code clears it."""
        return registration_controller.update_home_location(current_user_id(), location_data["preferred_postal_code"])
