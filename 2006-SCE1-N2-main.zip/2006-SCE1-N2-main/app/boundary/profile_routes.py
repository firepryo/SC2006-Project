"""API boundary for StudentProfileUI (UC03; M2 Student profiles, ARC-02 §4.1)."""
from flask.views import MethodView
from flask_jwt_extended import jwt_required
from flask_smorest import Blueprint

from app.boundary.schemas import ProfileSchema, StudentProfileSchema
from app.control import StudentProfileController
from app.control.access_control import current_user_id
from app.control.student_profile_controller import ProfileInput

profile_bp = Blueprint("profiles", __name__)

student_profile_controller = StudentProfileController()


@profile_bp.route("/profiles")
class ProfileListAPI(MethodView):
    """/profiles"""

    @jwt_required()
    @profile_bp.response(200, StudentProfileSchema(many=True))
    def get(self):
        """UC03 step 1. 200 with the user's profiles."""
        return student_profile_controller.list_profiles(current_user_id())

    @jwt_required()
    @profile_bp.arguments(ProfileSchema)
    @profile_bp.response(201, StudentProfileSchema)
    def post(self, profile_data):
        """UC03 steps 2–4. 201; 400."""
        return student_profile_controller.create_profile(current_user_id(), ProfileInput(**profile_data))


@profile_bp.route("/profiles/<uuid:student_id>")
class ProfileAPI(MethodView):
    """/profiles/<student_id>"""

    @jwt_required()
    @profile_bp.response(200, StudentProfileSchema)
    def get(self, student_id):
        """UC03 alt flow 1. 200; 404."""
        return student_profile_controller.get_profile(current_user_id(), student_id)

    @jwt_required()
    @profile_bp.arguments(ProfileSchema)
    @profile_bp.response(200, StudentProfileSchema)
    def put(self, profile_data, student_id):
        """UC03 alt flow 1. 200; 400; 404."""
        return student_profile_controller.edit_profile(current_user_id(), student_id, ProfileInput(**profile_data))

    @jwt_required()
    @profile_bp.response(204)
    def delete(self, student_id):
        """UC03 alt flow 2. 204; 404; 409 if applications or a non-empty shortlist reference it."""
        student_profile_controller.remove_profile(current_user_id(), student_id)
