"""«boundary» API blueprints, one per resource group, all mounted under /api (ARC-02 §3.3, §4.1).

Each blueprint is a flask_smorest.Blueprint; every URL is a MethodView class with @<bp>.route above it.
"""
from flask import Flask

from app.extensions import api
from app.boundary.application_routes import application_bp
from app.boundary.auth_routes import auth_bp
from app.boundary.notification_routes import notification_bp
from app.boundary.profile_routes import profile_bp
from app.boundary.reference_routes import reference_bp
from app.boundary.school_routes import school_bp
from app.boundary.shortlist_routes import shortlist_bp

BLUEPRINTS = [auth_bp, profile_bp, reference_bp, school_bp, shortlist_bp, application_bp, notification_bp]
API_PREFIX = "/api"


def register_blueprints(app: Flask) -> None:
    """Attach flask-smorest's Api to the app and mount every blueprint in BLUEPRINTS under API_PREFIX.

    Inputs: the Flask app, with API_TITLE, API_VERSION and OPENAPI_VERSION already in its config.
    Output: none.
    Errors: flask_smorest.exceptions.MissingAPIParameterError if one of those settings is missing.
    """
    api.init_app(app)
    for bp in BLUEPRINTS:
        api.register_blueprint(bp, url_prefix=API_PREFIX)
