"""API boundary for NotificationUI and NotificationPreferencesUI (UC11, UC14; M1, M7, ARC-02 §4.1)."""
from flask.views import MethodView
from flask_jwt_extended import jwt_required
from flask_smorest import Blueprint

from app.boundary.schemas import NotificationPreferenceSchema, NotificationSchema
from app.control import NotificationPreferenceController, ReminderController
from app.control.access_control import current_user_id

notification_bp = Blueprint("notifications", __name__)

reminder_controller = ReminderController()
notification_preference_controller = NotificationPreferenceController()


@notification_bp.route("/notifications")
class NotificationListAPI(MethodView):
    """/notifications"""

    @jwt_required()
    @notification_bp.response(200, NotificationSchema(many=True))
    def get(self):
        """UC11 step 4. 200 with stored reminders, each linking to its application."""
        return reminder_controller.list_notifications(current_user_id())


@notification_bp.route("/notifications/<uuid:reminder_id>/read")
class NotificationReadAPI(MethodView):
    """/notifications/<reminder_id>/read"""

    @jwt_required()
    @notification_bp.response(200, NotificationSchema)
    def patch(self, reminder_id):
        """Notification.markAsRead(). No body. 200 with the reminder (is_read true); 404 for a foreign or unknown id."""
        return reminder_controller.mark_as_read(current_user_id(), reminder_id)


@notification_bp.route("/users/me/notification-preference")
class NotificationPreferenceAPI(MethodView):
    """/users/me/notification-preference"""

    @jwt_required()
    @notification_bp.response(200, NotificationPreferenceSchema)
    def get(self):
        """UC14 step 1. 200 with {"notification_opt_in": bool}."""
        return {"notification_opt_in": notification_preference_controller.get_preference(current_user_id())}

    @jwt_required()
    @notification_bp.arguments(NotificationPreferenceSchema)
    @notification_bp.response(200, NotificationPreferenceSchema)
    def put(self, preference_data):
        """UC14 steps 2–4. 200 with the saved value."""
        saved = notification_preference_controller.update_preference(
            current_user_id(), preference_data["notification_opt_in"]
        )
        return {"notification_opt_in": saved}
