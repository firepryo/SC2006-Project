"""API boundary for SchoolSearchUI, SchoolDetailsUI and SchoolComparisonUI (UC04–UC07; M3, M4, ARC-02 §4.1)."""
import uuid

from flask.views import MethodView
from flask_jwt_extended import get_jwt_identity, jwt_required
from flask_smorest import Blueprint

from app.boundary.schemas import (
    CompareSchema,
    ComparisonResultSchema,
    SchoolDetailsSchema,
    SchoolRouteSchema,
    SchoolSummarySchema,
    SearchQuerySchema,
)
from app.control import SchoolComparisonController, SchoolDetailsController, SchoolSearchController
from app.control.school_search_controller import SearchCriteria

school_bp = Blueprint("schools", __name__)

school_search_controller = SchoolSearchController()
school_details_controller = SchoolDetailsController()
school_comparison_controller = SchoolComparisonController()


def current_user_id() -> uuid.UUID:
    """The logged-in user's id. The JWT identity is str(user_id), set at login (ARC-02 §3.9.2)."""
    return uuid.UUID(str(get_jwt_identity()))


@school_bp.route("/schools")
class SchoolListAPI(MethodView):
    """/schools"""

    @jwt_required()
    @school_bp.arguments(SearchQuerySchema, location="query")
    @school_bp.response(200, SchoolSummarySchema(many=True))
    def get(self, search_args):
        """UC04, UC05. 200 with a list (may be empty); 400 for invalid filters."""
        return school_search_controller.search_schools(SearchCriteria(**search_args), current_user_id())


@school_bp.route("/schools/<uuid:school_id>")
class SchoolAPI(MethodView):
    """/schools/<school_id>"""

    @jwt_required()
    @school_bp.response(200, SchoolDetailsSchema)
    def get(self, school_id):
        """UC06. 200 with school, subjects, CCAs, affiliations; 404."""
        return school_details_controller.retrieve_school_details(school_id)


@school_bp.route("/schools/<uuid:school_id>/route")
class SchoolRouteAPI(MethodView):
    """/schools/<school_id>/route"""

    @jwt_required()
    @school_bp.response(200, SchoolRouteSchema)
    def get(self, school_id):
        """School and home coordinates with the OneMap road route; 404 if the school has no location."""
        return school_details_controller.retrieve_school_route(current_user_id(), school_id)


@school_bp.route("/schools/compare")
class SchoolCompareAPI(MethodView):
    """/schools/compare"""

    @jwt_required()
    @school_bp.arguments(CompareSchema)
    @school_bp.response(200, ComparisonResultSchema)
    def post(self, compare_data):
        """UC07, UC07a–d. 200 with one column per school; 400 bad count; 404."""
        return school_comparison_controller.compare_schools(
            current_user_id(), compare_data["school_ids"], compare_data.get("student_id")
        )
