"""API boundary for ApplicationUI, ApplicationStatusUI and ApplicationDeadlineUI (UC09, UC10, UC13; M6, ARC-02 §4.1)."""
from flask.views import MethodView
from flask_jwt_extended import jwt_required
from flask_smorest import Blueprint

from app.boundary.schemas import (
    ApplicationCreateSchema,
    ApplicationListQuerySchema,
    ApplicationSchema,
    ApplicationUpdateSchema,
    DeadlineSchema,
    StatusUpdateSchema,
)
from app.control import ApplicationController, ApplicationDeadlineController, ApplicationStatusController
from app.control.access_control import current_user_id

application_bp = Blueprint("applications", __name__)

application_controller = ApplicationController()
application_status_controller = ApplicationStatusController()
application_deadline_controller = ApplicationDeadlineController()


@application_bp.route("/applications")
class ApplicationListAPI(MethodView):
    """/applications"""

    @jwt_required()
    @application_bp.arguments(ApplicationListQuerySchema, location="query")
    @application_bp.response(200, ApplicationSchema(many=True))
    def get(self, query_args):
        """UC09, DM-60. 200 with a list; 404 for a foreign profile."""
        return application_controller.list_applications(current_user_id(), query_args.get("student_id"))

    @jwt_required()
    @application_bp.arguments(ApplicationCreateSchema)
    @application_bp.response(201, ApplicationSchema)
    def post(self, application_data):
        """UC09 steps 1–5. 201 with status Draft; 404; 409 duplicate."""
        return application_controller.create_application(
            current_user_id(),
            application_data["student_id"],
            application_data["school_id"],
            application_data.get("notes"),
        )


@application_bp.route("/applications/<uuid:application_id>")
class ApplicationAPI(MethodView):
    """/applications/<application_id>"""

    @jwt_required()
    @application_bp.response(200, ApplicationSchema)
    def get(self, application_id):
        """UC09 alt flow 1, UC10 step 1. 200 with the application including status and deadline; 404."""
        return application_controller.get_application(current_user_id(), application_id)

    @jwt_required()
    @application_bp.arguments(ApplicationUpdateSchema)
    @application_bp.response(200, ApplicationSchema)
    def patch(self, update_data, application_id):
        """UC09 alt flow 1. 200; 404."""
        return application_controller.update_application(current_user_id(), application_id, update_data["notes"])


@application_bp.route("/applications/<uuid:application_id>/status")
class ApplicationStatusAPI(MethodView):
    """/applications/<application_id>/status"""

    @jwt_required()
    @application_bp.arguments(StatusUpdateSchema)
    @application_bp.response(200, ApplicationSchema)
    def patch(self, status_data, application_id):
        """UC10 steps 2–5. 200; 404; 409 invalid transition."""
        return application_status_controller.update_application_status(
            current_user_id(), application_id, status_data["status"]
        )


@application_bp.route("/applications/<uuid:application_id>/deadline")
class ApplicationDeadlineAPI(MethodView):
    """/applications/<application_id>/deadline"""

    @jwt_required()
    @application_bp.arguments(DeadlineSchema)
    @application_bp.response(200, ApplicationSchema)
    def put(self, deadline_data, application_id):
        """UC13 steps 2–4. 200; 400; 404."""
        return application_deadline_controller.set_deadline(current_user_id(), application_id, deadline_data["deadline"])

    @jwt_required()
    @application_bp.response(200, ApplicationSchema)
    def delete(self, application_id):
        """UC13 alt flow 1. 200 with deadline null; 404."""
        return application_deadline_controller.clear_deadline(current_user_id(), application_id)
