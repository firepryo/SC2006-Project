"""API boundary for ShortlistUI (UC08; M5 Shortlist, ARC-02 §4.1)."""
from flask.views import MethodView
from flask_jwt_extended import jwt_required
from flask_smorest import Blueprint

from app.boundary.school_routes import current_user_id
from app.boundary.schemas import ShortlistAddSchema, ShortlistEntrySchema, ShortlistSchema
from app.control import ShortlistController

shortlist_bp = Blueprint("shortlist", __name__)

shortlist_controller = ShortlistController()


@shortlist_bp.route("/profiles/<uuid:student_id>/shortlist")
class ShortlistAPI(MethodView):
    """/profiles/<student_id>/shortlist"""

    @jwt_required()
    @shortlist_bp.response(200, ShortlistSchema)
    def get(self, student_id):
        """UC08 step 1. 200 with the shortlist and its entries; 404."""
        return shortlist_controller.get_shortlist(current_user_id(), student_id)


@shortlist_bp.route("/profiles/<uuid:student_id>/shortlist/entries")
class ShortlistEntryListAPI(MethodView):
    """/profiles/<student_id>/shortlist/entries"""

    @jwt_required()
    @shortlist_bp.arguments(ShortlistAddSchema)
    @shortlist_bp.response(201, ShortlistEntrySchema)
    def post(self, entry_data, student_id):
        """UC08 steps 2–5. 201 with the entry; 404; 409 already shortlisted."""
        return shortlist_controller.add_school_to_shortlist(current_user_id(), student_id, entry_data["school_id"])


@shortlist_bp.route("/profiles/<uuid:student_id>/shortlist/entries/<uuid:entry_id>")
class ShortlistEntryAPI(MethodView):
    """/profiles/<student_id>/shortlist/entries/<entry_id>"""

    @jwt_required()
    @shortlist_bp.response(204)
    def delete(self, student_id, entry_id):
        """UC08 alt flow 1. 204; 404."""
        shortlist_controller.remove_school_from_shortlist(current_user_id(), student_id, entry_id)
