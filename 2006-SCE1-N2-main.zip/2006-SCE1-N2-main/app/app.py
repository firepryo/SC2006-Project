"""Application factory and configuration: the start-up class (ARC-02 §3.10 Application Factory).

Settings, database, migrations and JWT login are wired in one place (DATA-01 §3.7, ADR-005, ARC-02 §3.9.2).
Secrets and URLs come from the environment, loaded from app/.env, never from code (ARC-02 §3.8).
"""
import os
from datetime import timedelta
from pathlib import Path

from dotenv import load_dotenv
from flask import Flask, Response, current_app
from flask_jwt_extended import create_access_token, get_jwt, get_jwt_identity, set_access_cookies

from app.extensions import db, jwt, migrate

# Variables already set in the environment win over .env (e.g. on a server).
load_dotenv(Path(__file__).with_name(".env"))


def refresh_jwt_cookie(response: Response) -> Response:
    """after_request hook: give every authenticated response a fresh 30-minute cookie (ARC-02 §3.9.2, NFR 3.5.2).

    So the session ends 30 minutes after the last request, not 30 minutes after login.
    Inputs: the response about to be sent.
    Output: the same response, with a new access cookie when the request carried a valid JWT.
    """
    try:
        claims = get_jwt()  # raises RuntimeError unless jwt_required() verified a token on this request
        identity = get_jwt_identity()
    except RuntimeError:
        # Not a jwt_required() request (register, login, school search before login): nothing to refresh.
        return response
    if identity is None:
        return response
    # A route that already set or cleared the cookie (login, logout) wins; refreshing here would undo a logout.
    cookie_name = current_app.config["JWT_ACCESS_COOKIE_NAME"]
    if any(header.startswith(f"{cookie_name}=") for header in response.headers.getlist("Set-Cookie")):
        return response
    # Keep the session's CSRF value: a new one on every response would make the X-CSRF-TOKEN header a
    # client already holds (or sends on an overlapping request) stale, and that request would get 401.
    keep_csrf = {"csrf": claims["csrf"]} if "csrf" in claims else None
    set_access_cookies(response, create_access_token(identity=identity, additional_claims=keep_csrf))
    return response


def create_app() -> Flask:
    """Create the Flask app, load its settings and wire every layer to it (DATA-01 §3.7, ADR-005, ARC-02 §3.3).

    Inputs: none; settings come from the environment and app/.env.
    Output: the configured Flask app, with every DATA-01 model registered on db.metadata.
    Errors: RuntimeError if DATABASE_URL or JWT_SECRET_KEY is not set.
    """
    flask_app = Flask(__name__)
    # flask_app.config is a flask.Config, a dict subclass; keys must match Flask's names exactly.
    # DATA-01 §1: PostgreSQL with citext and postgis,
    # e.g. postgresql+psycopg://user:password@localhost:5432/school_comparison
    flask_app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
    flask_app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    # Sessions: JWT in an HttpOnly cookie, 30 minutes from the last request (ARC-02 §3.9.2, NFR 3.5.2)
    flask_app.config["JWT_SECRET_KEY"] = os.environ.get("JWT_SECRET_KEY")
    flask_app.config["JWT_TOKEN_LOCATION"] = ["cookies"]
    flask_app.config["JWT_ACCESS_TOKEN_EXPIRES"] = timedelta(minutes=30)
    flask_app.config["JWT_COOKIE_SECURE"] = os.environ.get("JWT_COOKIE_SECURE", "true").lower() == "true"
    flask_app.config["JWT_COOKIE_SAMESITE"] = "Lax"
    flask_app.config["JWT_COOKIE_CSRF_PROTECT"] = True

    # flask-smorest: required by Api.init_app; used for the generated OpenAPI description (ARC-02 §4.1)
    flask_app.config["API_TITLE"] = "School Comparison API"
    flask_app.config["API_VERSION"] = "v1"
    flask_app.config["OPENAPI_VERSION"] = "3.0.3"

    # External systems (ARC-02 §3.1)
    flask_app.config["DATA_GOV_SG_API_KEY"] = os.environ.get("DATA_GOV_SG_API_KEY")
    flask_app.config["ONEMAP_API_TOKEN"] = os.environ.get("ONEMAP_API_TOKEN")

    # Background jobs (ARC-02 §3.7.4, §3.7.5)
    flask_app.config["SCHEDULER_TIMEZONE"] = "Asia/Singapore"
    flask_app.config["SCHEDULER_ENABLED"] = os.environ.get("SCHEDULER_ENABLED", "false").lower() == "true"

    for key, env_var in (("SQLALCHEMY_DATABASE_URI", "DATABASE_URL"), ("JWT_SECRET_KEY", "JWT_SECRET_KEY")):
        if not flask_app.config.get(key):
            raise RuntimeError(f"{env_var} is not set; add it to app/.env (template: app/.env.example).")

    # Auth: JWT in an HttpOnly cookie with CSRF protection, 30 minutes (cookie flags above).
    db.init_app(flask_app)
    # Migrations live in app/migrations/, whatever folder the flask command is run from (ADR-005).
    migrate.init_app(flask_app, db, directory=str(Path(__file__).with_name("migrations")))
    jwt.init_app(flask_app)

    # Register all 16 tables so Flask-Migrate sees them.
    import app.models  # noqa: F401

    # Sliding 30-minute session: a fresh cookie on every authenticated response (ARC-02 §3.9.2).
    flask_app.after_request(refresh_jwt_cookie)

    # Every API route under /api, as flask-smorest MethodView classes (ARC-02 §3.12, §4.1).
    from app.boundary import register_blueprints

    register_blueprints(flask_app)

    # After register_blueprints: replaces flask-smorest's error body with the §4.2 format (ARC-02 §5).
    from app.errors import register_error_handlers

    register_error_handlers(flask_app)

    # Server-only entry points and background jobs (ARC-02 §3.7.4, §3.7.5, §4.1).
    from app.jobs.cli import register_cli
    from app.jobs.scheduler import register_jobs

    register_cli(flask_app)
    register_jobs(flask_app)
    return flask_app
