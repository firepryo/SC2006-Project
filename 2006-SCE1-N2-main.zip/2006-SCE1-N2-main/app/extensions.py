"""Flask extension instances, shared by the models, controllers and create_app (DATA-01 §3.7, ARC-02 §3.10 Singleton)."""
from apscheduler.schedulers.background import BackgroundScheduler
from flask_jwt_extended import JWTManager
from flask_migrate import Migrate
from flask_smorest import Api
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()
migrate = Migrate()
jwt = JWTManager()  # ARC-02 §3.9.2
api = Api()  # flask-smorest: registers the boundary blueprints (ARC-02 §4.1)
scheduler = BackgroundScheduler(timezone="Asia/Singapore")  # ARC-02 §3.7.4, §3.7.5
