"""The backend package. The application factory create_app() lives in app/app.py (ARC-02 §3.10)."""
