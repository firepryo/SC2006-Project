# Postman tests for API-01

`collection/User API test/User API test.postman_collection.json` (Postman Collection v2.1) has test cases for all 30 endpoints in API-01 v0.1, plus `GET /schools/{id}/route`. It covers every documented status code: success, 400, 401, 404 (missing and other user's records), 409 and 423.

## Before running

1. Start the stack: `docker compose -f app/docker-compose.yml up -d --build`. Compose sets `JWT_COOKIE_SECURE=false`; with `true`, Postman does not send the cookie over http and every request gets 401.
2. Load the school catalogue once: `docker compose -f app/docker-compose.yml run --rm api flask --app "app.app:create_app()" sync-schools`.
3. Run all folders in order, with either of these:
   - **Postman app:** **Import** the JSON file, then **Run collection**.
   - **Postman API + Postman CLI:** upload the file once, then run it by its collection ID:
     ```bash
     curl -X POST "https://api.getpostman.com/collections?workspace=<workspace-id>" -H "X-Api-Key: $POSTMAN_API_KEY" -H "Content-Type: application/json" --data "{\"collection\": $(cat "app/postman/collection/User API test/User API test.postman_collection.json")}"
     postman login --with-api-key "$POSTMAN_API_KEY"
     postman collection run <collection-uid>
     ```
   - **Newman (no upload needed):** `npx newman run "app/postman/collection/User API test/User API test.postman_collection.json"`

   Each run registers new users (`postman.*.<timestamp>@example.com`), so it can be run again and again. The API must be reachable from wherever the run happens: Postman's cloud runner cannot reach `localhost`, so use the app, Postman CLI or Newman on your own machine.

## How it works

- Login saves the `csrf_access_token` cookie. A collection-level script then sends it as `X-CSRF-TOKEN` on every POST, PUT, PATCH and DELETE (flask-jwt-extended CSRF protection).
- User B creates a profile and an application first, so user A's requests can check that other users' records return 404.
- Requests marked "no cookie" have cookies switched off, to test 401.
- A collection-level test checks that every error has the `{error, message, details?}` body.

## Mark-as-read (folder 08)

Reminders are only created by the daily job. Folder 07 ends by setting a deadline 3 days ahead. To test `PATCH /notifications/{id}/read`:

1. Run `docker exec sce1-api flask --app "app.app:create_app()" check-deadlines`.
2. Run folder 08 again.

If there is no reminder, the two mark-as-read requests are skipped (`pm.execution.skipRequest`, which needs Postman 10.19 or later).

## Results that depend on the environment

- `PATCH /users/me` with a valid postal code accepts 200, or 503 if OneMap is down or its token has expired.
- `GET /schools/{id}/route` accepts 200, 404 or 503.
