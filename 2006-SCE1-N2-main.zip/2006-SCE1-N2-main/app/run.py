"""Start-up script: builds the app with create_app() and runs the development server.

Run from the repository root (the folder that contains app/), not from inside app/:
    python -m app.run
Inside app/, "import app" would find app.py instead of this package.

Production runs the same factory under Gunicorn: `gunicorn "app.app:create_app()"` (ARC-02 §3.6).
Flask CLI (migrations, sync-schools, check-deadlines): `flask --app "app.app:create_app()" <command>`.
"""
from app.app import create_app

app = create_app()

if __name__ == "__main__":
    app.run(debug=True)
